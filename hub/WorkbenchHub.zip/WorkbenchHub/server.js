// Workbench Hub: the home server on the rig. One folder on one drive holds everything (Work,
// designs, music, videos, saves and settings), and every device running Workbench syncs with it
// over Tailscale. It also sends phone notifications, hands the AI (Ollama) to every device, and
// updates itself from the Workbench site. Plain Node.js, no packages to install.
//
//   node server.js                      start the Hub
//   node server.js --init-owner NAME PIN    create the owner (the installer does this)
//   node server.js --reset-pin NAME PIN     set a new PIN for someone who forgot theirs
"use strict";
const http = require("http"),
  fs = require("fs"),
  fsp = fs.promises,
  path = require("path"),
  crypto = require("crypto"),
  zlib = require("zlib"),
  os = require("os"),
  push = require("./push.js"),
  { readTags } = require("./tags.js"),
  { __wbReminders } = require("./reminders.js");

const VERSION = "1.38.1";
const HOME = process.env.WB_HUB_HOME || path.join(__dirname, "..");
const CONF = process.env.WB_HUB_CONFIG || path.join(HOME, "hub.json");
const APP = "https://tonystarkofficial1111-web.github.io";

// ---- settings ----------------------------------------------------------------------------------
const DEF = {
  port: 8770,
  host: "127.0.0.1",
  root: path.join(os.homedir(), "Workbench Hub"),
  name: os.hostname(),
  origins: [APP],
  ollama: "http://127.0.0.1:11434",
  aiModel: "",
  lang: "",
  update: APP + "/Workbench/hub/",
  autoUpdate: true,
  // more music or video folders, for example a second drive later:
  // [{ "path": "E:\\Music", "kind": "music", "everyone": false }]
  libraries: [],
  // a second copy of work.json every day, for example on a second drive later: "E:\\Backups"
  backupDir: "",
};
const readJson = (f, d) => {
  try {
    return JSON.parse(fs.readFileSync(f, "utf8").replace(/^\uFEFF/, ""));
  } catch {
    return d;
  }
};
function writeJson(f, v) {
  fs.mkdirSync(path.dirname(f), { recursive: !0 });
  const t = f + "." + process.pid + ".tmp";
  fs.writeFileSync(t, JSON.stringify(v, null, 1));
  fs.renameSync(t, f);
}
const C = Object.assign({}, DEF, readJson(CONF, {}));
const hubf = (n) => path.join(C.root, ".hub", n);
const WORK = () => path.join(C.root, "Work");
const sha = (b) => crypto.createHash("sha256").update(b).digest("hex");
const id36 = () => Date.now().toString(36) + crypto.randomBytes(4).toString("hex");

// ---- log ---------------------------------------------------------------------------------------
const LOG = path.join(HOME, "logs", "hub.log");
function log(...a) {
  const line = new Date().toISOString() + " " + a.join(" ");
  console.log(line);
  try {
    fs.mkdirSync(path.dirname(LOG), { recursive: !0 });
    if (fs.existsSync(LOG) && fs.statSync(LOG).size > 2e6) fs.renameSync(LOG, LOG + ".old");
    fs.appendFileSync(LOG, line + "\n");
  } catch {}
}

// ---- people and devices ------------------------------------------------------------------------
let U = { users: [] },
  DV = { devices: [] },
  VAPID = null,
  dvT = 0;
const saveUsers = () => writeJson(hubf("users.json"), U);
const saveDevices = () => (clearTimeout(dvT), writeJson(hubf("devices.json"), DV));
const saveDevicesSoon = () => (clearTimeout(dvT), (dvT = setTimeout(saveDevices, 3000)));
const pinHash = (pin, salt) => crypto.scryptSync(String(pin), salt, 32).toString("hex");
const safeName = (s) =>
  String(s || "")
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "")
    .replace(/^[.\s]+|[.\s]+$/g, "")
    .slice(0, 60);
const userDir = (u, kind) => path.join(C.root, "Users", u.dir, kind || "");
const canWork = (u) => !!u && (u.role === "owner" || !!u.work);
const canBrowse = (u) => !!u && (u.role === "owner" || !!u.browser);
const pub = (u) => ({ id: u.id, name: u.name, role: u.role, work: canWork(u), browser: canBrowse(u) });
function addUser(name, pin, role, work) {
  name = String(name || "").trim();
  if (!name || !/^\d{4,12}$/.test(String(pin))) throw new Error("A name and a PIN of 4 to 12 digits are needed.");
  if (U.users.some((u) => u.name.toLowerCase() === name.toLowerCase())) throw new Error("Someone called " + name + " is already on the Hub.");
  let dir = safeName(name) || "User",
    n = 2;
  while (U.users.some((u) => u.dir.toLowerCase() === dir.toLowerCase())) dir = safeName(name) + " " + n++;
  const salt = crypto.randomBytes(16).toString("hex"),
    u = { id: id36(), name, dir, role, work: role === "owner" || !!work, salt, hash: pinHash(pin, salt), created: Date.now() };
  U.users.push(u);
  for (const k of ["Music", "Videos", "Saves"]) fs.mkdirSync(userDir(u, k), { recursive: !0 });
  saveUsers();
  return u;
}
function setPin(u, pin) {
  if (!/^\d{4,12}$/.test(String(pin))) throw new Error("Use a PIN of 4 to 12 digits.");
  u.salt = crypto.randomBytes(16).toString("hex");
  u.hash = pinHash(pin, u.salt);
  saveUsers();
}

function setup() {
  for (const d of [".hub/cache", ".hub/backups", "Work", "Users", "Shared/Music", "Shared/Videos"]) fs.mkdirSync(path.join(C.root, d), { recursive: !0 });
  U = readJson(hubf("users.json"), { users: [] });
  DV = readJson(hubf("devices.json"), { devices: [] });
  VAPID = readJson(hubf("vapid.json"), null);
  if (!VAPID) writeJson(hubf("vapid.json"), (VAPID = push.makeVapid()));
  if (!fs.existsSync(CONF)) writeJson(CONF, C);
}

// ---- HTTP helpers ------------------------------------------------------------------------------
function json(res, code, obj) {
  if (res.headersSent) return res.end();
  const b = Buffer.from(typeof obj === "string" ? obj : JSON.stringify(obj));
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Content-Length": b.length, "Cache-Control": "no-store" });
  res.end(b);
}
const fail = (res, code, msg) => json(res, code, { error: msg });
function body(req, limit) {
  return new Promise((ok, bad) => {
    const parts = [];
    let n = 0;
    req.on("data", (c) => {
      n += c.length;
      if (n > (limit || 64e6)) (bad(new Error("Too big")), req.destroy());
      else parts.push(c);
    });
    req.on("end", () => ok(Buffer.concat(parts)));
    req.on("error", bad);
  });
}
async function jsonBody(req, limit) {
  const b = await body(req, limit);
  try {
    return b.length ? JSON.parse(b.toString("utf8")) : {};
  } catch {
    throw Object.assign(new Error("That wasn't valid data."), { code: 400 });
  }
}
function allowOrigin(o) {
  if (!o) return "";
  if (o === "null" || (C.origins || []).includes(o)) return o;
  if (/^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(o)) return o;
  if (/^https:\/\/[a-z0-9-]+(\.[a-z0-9-]+)*\.ts\.net$/i.test(o)) return o;
  return "";
}
function cors(req, res) {
  const o = allowOrigin(req.headers.origin);
  res.setHeader("Vary", "Origin");
  if (!o) return;
  res.setHeader("Access-Control-Allow-Origin", o);
  res.setHeader("Access-Control-Expose-Headers", "ETag, Content-Range, Accept-Ranges, Content-Length, X-Rev");
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", req.headers["access-control-request-headers"] || "Authorization, Content-Type, Range");
    res.setHeader("Access-Control-Max-Age", "600");
    if (req.headers["access-control-request-private-network"]) res.setHeader("Access-Control-Allow-Private-Network", "true");
  }
}
// a path inside base, or null if it tries to leave it
function inside(base, rel) {
  rel = String(rel || "").replace(/\\/g, "/");
  if (!rel || rel.includes("\0") || /(^|\/)\.\.(\/|$)/.test(rel) || /^[a-z]:/i.test(rel) || rel.startsWith("/") || /:/.test(rel)) return null;
  const full = path.resolve(base, rel),
    r = path.relative(base, full);
  return r && !r.startsWith("..") && !path.isAbsolute(r) ? full : null;
}
const TYPES = { mp3: "audio/mpeg", m4a: "audio/mp4", aac: "audio/aac", flac: "audio/flac", wav: "audio/wav", ogg: "audio/ogg", oga: "audio/ogg", opus: "audio/ogg", weba: "audio/webm", aif: "audio/aiff", aiff: "audio/aiff", mp4: "video/mp4", m4v: "video/mp4", webm: "video/webm", mov: "video/quicktime", mkv: "video/x-matroska", ogv: "video/ogg", psd: "image/vnd.adobe.photoshop", psb: "image/vnd.adobe.photoshop", pdf: "application/pdf", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", svg: "image/svg+xml", gif: "image/gif", tif: "image/tiff", tiff: "image/tiff", json: "application/json", txt: "text/plain; charset=utf-8" };
const typeOf = (f) => TYPES[path.extname(f).slice(1).toLowerCase()] || "application/octet-stream";
function sendFile(req, res, file, download) {
  let st;
  try {
    st = fs.statSync(file);
  } catch {
    return fail(res, 404, "That file isn't on the rig.");
  }
  if (!st.isFile()) return fail(res, 404, "That file isn't on the rig.");
  const size = st.size;
  res.setHeader("Accept-Ranges", "bytes");
  res.setHeader("Content-Type", typeOf(file));
  res.setHeader("ETag", '"' + size.toString(36) + "-" + Math.floor(st.mtimeMs).toString(36) + '"');
  res.setHeader("Last-Modified", st.mtime.toUTCString());
  res.setHeader("Cache-Control", "private, no-cache");
  if (download) res.setHeader("Content-Disposition", "attachment; filename*=UTF-8''" + encodeURIComponent(path.basename(file)));
  let start = 0,
    end = size - 1,
    code = 200;
  const m = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || "").trim());
  if (m && size) {
    if (m[1] === "") start = Math.max(0, size - +m[2]);
    else ((start = +m[1]), m[2] !== "" && (end = Math.min(+m[2], size - 1)));
    if (start > end || start >= size) {
      res.writeHead(416, { "Content-Range": "bytes */" + size });
      return res.end();
    }
    code = 206;
    res.setHeader("Content-Range", "bytes " + start + "-" + end + "/" + size);
  }
  res.setHeader("Content-Length", size ? end - start + 1 : 0);
  res.writeHead(code);
  if (req.method === "HEAD" || !size) return res.end();
  const s = fs.createReadStream(file, { start, end });
  s.on("error", () => res.destroy());
  res.on("close", () => s.destroy());
  s.pipe(res);
}
// a file upload, streamed straight to disk (any size), then put in place
async function receive(req, dest) {
  await fsp.mkdir(path.dirname(dest), { recursive: !0 });
  const tmp = dest + ".part";
  await new Promise((ok, bad) => {
    const w = fs.createWriteStream(tmp);
    req.pipe(w);
    w.on("finish", ok);
    w.on("error", bad);
    req.on("aborted", () => (w.destroy(), bad(new Error("The upload stopped."))));
  });
  await fsp.rename(tmp, dest);
  return (await fsp.stat(dest)).size;
}

// ---- sign in -----------------------------------------------------------------------------------
const tries = new Map();
function auth(req, url) {
  const h = String(req.headers.authorization || ""),
    tok = h.startsWith("Bearer ") ? h.slice(7).trim() : url.searchParams.get("t") || "";
  if (!tok) return null;
  const th = sha(tok),
    d = DV.devices.find((x) => x.tokenHash === th),
    u = d && U.users.find((x) => x.id === d.user);
  if (!u) return null;
  if (Date.now() - (d.seen || 0) > 60000) ((d.seen = Date.now()), saveDevicesSoon());
  return { user: u, device: d };
}
function login(b) {
  const name = String(b.name || "").trim(),
    key = name.toLowerCase(),
    t = tries.get(key) || { n: 0, until: 0 };
  if (t.until > Date.now()) throw Object.assign(new Error("Too many wrong PINs. Try again in " + Math.ceil((t.until - Date.now()) / 60000) + " minutes."), { code: 429 });
  const u = U.users.find((x) => x.name.toLowerCase() === key);
  if (!u || pinHash(String(b.pin || ""), u.salt) !== u.hash) {
    t.n++;
    if (t.n >= 5) ((t.until = Date.now() + (t.n >= 10 ? 60 : 15) * 60000), t.n >= 10 && (t.n = 5));
    tries.set(key, t);
    throw Object.assign(new Error(u ? "That PIN isn't right." : "Nobody called " + (name || "that") + " is on this Hub. Ask the owner to add you."), { code: 401 });
  }
  tries.delete(key);
  const token = crypto.randomBytes(32).toString("base64url"),
    d = { id: id36(), user: u.id, name: String(b.device || "Device").slice(0, 60), tokenHash: sha(token), created: Date.now(), seen: Date.now(), push: null, notify: !0 };
  DV.devices.push(d);
  saveDevices();
  log("Signed in:", u.name, "on", d.name);
  try {
    pubEvent("device", u.name + " signed in", "on " + d.name);
  } catch {}
  return { token, user: pub(u), device: { id: d.id, name: d.name } };
}

// ---- live updates (Server-Sent Events) ---------------------------------------------------------
const live = new Set();
function broadcast(ev, filter) {
  const line = "data: " + JSON.stringify(ev) + "\n\n";
  for (const c of live) if (!filter || filter(c)) c.res.write(line);
}
setInterval(() => {
  for (const c of live) c.res.write(": ping\n\n");
}, 25000).unref();

// ---- the testers' chat (1.13) -------------------------------------------------------------------
// One group chat for everyone with a Hub account, kept on the rig (.hub/chat.json, the last 1,000
// messages). Text only, 500 characters, one message every 3 seconds each, rude words starred out.
// The owner can remove any message and pause anyone's chat; people can remove their own.
const CHAT = readJson(hubf("chat.json"), { msgs: [], muted: [] });
CHAT.msgs ||= [];
CHAT.muted ||= [];
let chatT = null;
const saveChat = () => (clearTimeout(chatT), (chatT = setTimeout(() => writeJson(hubf("chat.json"), CHAT), 600)));
const chatLast = new Map();
const CHAT_RUDE = /\b(f+u+c+k+\w*|sh+i+t+\w*|bitch\w*|cunt\w*|n+i+g+g+\w*|fag\w*|retard\w*|whore\w*|slut\w*|pussy\w*|asshole\w*|bastard\w*)/gi;
const chatClean = (t) => String(t || "").replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, "").replace(/\n{3,}/g, "\n\n").trim().slice(0, 500).replace(CHAT_RUDE, (w) => w[0] + "*".repeat(Math.max(2, w.length - 1)));
// (1.14) a removed message is gone completely: nothing about who wrote it, only that it left
const chatView = (m) => (m.del ? { id: m.id, at: m.at, edit: m.edit, del: !0 } : { id: m.id, at: m.at, uid: m.uid, name: m.name, owner: !!m.owner, pub: !!m.pub, text: m.text });
// ---- 1.14.0: testers without a Hub account ------------------------------------------------------------
// Anyone who opens the website can join the chat with a name. Their account lives in this browser (a secret
// token; only a scrambled copy is kept here). No links, one message every 20 seconds, and the owner can pause
// or remove anyone. To stop one person from making many accounts, the address a join comes from is kept as a
// one-way scramble (a keyed HMAC-SHA256, the key kept in its own private file) for 24 hours only, then forgotten: two accounts per address.
CHAT.pub ||= [];
CHAT.ips ||= {};
delete CHAT.salt;
// The secret code that scrambles addresses lives only in its own file inside the Hub's private folder
// (.hub/chat.key), never in the chat data, never sent anywhere. Without it the scrambled values can't be
// turned back into addresses, even by someone who gets a copy of chat.json.
let CHAT_KEY = "";
try {
  CHAT_KEY = fs.readFileSync(hubf("chat.key"), "utf8").trim();
} catch {}
if (CHAT_KEY.length < 32) {
  CHAT_KEY = crypto.randomBytes(32).toString("hex");
  try {
    fs.writeFileSync(hubf("chat.key"), CHAT_KEY, { mode: 0o600 });
  } catch (e) {
    log("chat key:", e.message);
  }
}
const CHAT_IP_MAX = 2,
  CHAT_SLOW = 20000,
  CHAT_LINK = /(https?:\/\/|www\.|\b[a-z0-9-]+\.(com|net|org|io|gg|co|me|ly|app|dev|xyz|tv|ru|cn|info|link|site|online|shop|store|ink|us|uk|de|fr|za)\b|\bdiscord\.|\bt\.me\b)/i;
const chatIpOf = (req) => String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim();
// an IPv6 address is cut to its first half (the part a household shares) so changing the end doesn't dodge the limit
const chatIpNet = (ip) => (ip.includes(":") && !ip.includes(".") ? ip.split(":").slice(0, 4).join(":") : ip.replace(/^::ffff:/, ""));
const chatIpHash = (req) => crypto.createHmac("sha256", CHAT_KEY).update(chatIpNet(chatIpOf(req))).digest("hex").slice(0, 32);
function chatIpPrune() {
  const cut = Date.now() - 864e5;
  for (const k of Object.keys(CHAT.ips)) {
    CHAT.ips[k] = CHAT.ips[k].filter((t) => t > cut);
    CHAT.ips[k].length || delete CHAT.ips[k];
  }
}
const chatTomb = () => {
  const cut = Date.now() - 864e5;
  CHAT.msgs = CHAT.msgs.filter((m) => !m.del || (m.edit || 0) > cut);
};
const chatJoinHits = [];
async function chatPubRoute(req, res, act) {
  const b = await jsonBody(req, 4000),
    now = Date.now();
  if (act === "join") {
    chatIpPrune();
    while (chatJoinHits.length && now - chatJoinHits[0] > 36e5) chatJoinHits.shift();
    if (chatJoinHits.length >= 40 || CHAT.pub.length >= 3000) return fail(res, 429, "The chat can't take new people right now. Try again later.");
    const name = String(b.name || "").replace(/\s+/g, " ").trim();
    if (!/^[A-Za-z0-9][A-Za-z0-9 _-]{1,19}$/.test(name)) return fail(res, 400, "Pick a name of 2 to 20 letters, numbers, spaces, - or _.");
    if (chatClean(name) !== name || CHAT_LINK.test(name)) return fail(res, 400, "Pick a different name.");
    const low = name.toLowerCase();
    if (CHAT.pub.some((a) => a.name.toLowerCase() === low) || U.users.some((x) => String(x.name || "").toLowerCase() === low)) return fail(res, 409, "That name is taken. Pick another.");
    const ih = chatIpHash(req);
    if ((CHAT.ips[ih] || []).length >= CHAT_IP_MAX) return fail(res, 429, "Two accounts have already been made from this connection today. Use one of them, or try again tomorrow.");
    const token = crypto.randomBytes(24).toString("base64url"),
      a = { id: id36(), name, th: sha(token), at: now, muted: !1 };
    CHAT.pub.push(a);
    (CHAT.ips[ih] ||= []).push(now);
    chatJoinHits.push(now);
    saveChat();
    log("Chat: new tester", name);
    return json(res, 200, { id: a.id, token, name });
  }
  const a = CHAT.pub.find((x) => x.id === String(b.id || ""));
  if (!a || a.th !== sha(String(b.t || ""))) return fail(res, 401, "This browser isn't signed in to the chat any more. Join again.");
  const uid = "p_" + a.id;
  if (act === "list") {
    if (now - (a.listAt || 0) < 1500) return fail(res, 429, "Slow down.");
    a.listAt = now;
    const since = +b.since || 0,
      list = CHAT.msgs.filter((m) => m.at > since || (m.edit || 0) > since).slice(-200);
    return json(res, 200, { msgs: list.map(chatView), me: { id: uid, name: a.name }, muted: !!a.muted, now });
  }
  if (act === "send") {
    if (a.muted) return fail(res, 403, "The owner has paused your chat for now.");
    const text = chatClean(b.text);
    if (!text) return fail(res, 400, "Write something first.");
    if (CHAT_LINK.test(text)) return fail(res, 400, "Links aren't allowed in the chat.");
    const left = Math.ceil((CHAT_SLOW - (now - (chatLast.get(uid) || 0))) / 1000);
    if (left > 0) return fail(res, 429, "One message every 20 seconds. Wait " + left + " more.");
    if (a.lastText === text && now - (a.lastAt || 0) < 3e5) return fail(res, 400, "You just said that.");
    chatLast.set(uid, now);
    a.lastText = text;
    a.lastAt = now;
    const m = { id: id36(), at: now, uid, name: a.name, pub: !0, text };
    CHAT.msgs.push(m);
    chatTomb();
    CHAT.msgs.length > 1000 && CHAT.msgs.splice(0, CHAT.msgs.length - 1000);
    saveChat();
    broadcast({ type: "chat", at: m.at });
    return json(res, 200, { msg: chatView(m) });
  }
  if (act === "del") {
    const m = CHAT.msgs.find((x) => x.id === String(b.msg || ""));
    if (!m || m.uid !== uid) return fail(res, 404, "That message is already gone.");
    ((m.del = !0), (m.text = ""), (m.name = ""), (m.uid = ""), (m.edit = now));
    saveChat();
    broadcast({ type: "chat", at: m.edit });
    return json(res, 200, { ok: !0 });
  }
  return fail(res, 404, "Not here.");
}

// ---- Work --------------------------------------------------------------------------------------
const workFile = () => path.join(WORK(), "work.json");
function readWorkText() {
  try {
    return fs.readFileSync(workFile(), "utf8");
  } catch {
    return "";
  }
}
const revOf = (t) => (t ? sha(t).slice(0, 16) : "");
function readWork() {
  const t = readWorkText();
  try {
    return t ? JSON.parse(t) : null;
  } catch {
    return null;
  }
}
function backupWork(text) {
  const day = new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
  for (const dir of [hubf("backups"), C.backupDir ? path.join(C.backupDir, "Workbench Hub backups") : ""].filter(Boolean))
    try {
      fs.mkdirSync(dir, { recursive: !0 });
      fs.writeFileSync(path.join(dir, "work-" + day + ".json"), text);
      const old = fs
        .readdirSync(dir)
        .filter((n) => /^work-\d{4}-\d\d-\d\d\.json$/.test(n))
        .sort()
        .reverse();
      for (const n of old.slice(90)) fs.unlinkSync(path.join(dir, n));
    } catch (e) {
      log("backup:", e.message);
    }
}

// ---- music and videos --------------------------------------------------------------------------
// Each person's own Music and Videos folders, the Shared ones, and folders the owner adds from
// anywhere on the rig (a big folder of everything, a second drive later). Those are read where
// they are: nothing is moved or copied. In a mixed folder ("auto") Workbench picks out what it
// needs by folder names and file types: songs from music-looking folders (or anything that is
// clearly a song), videos, and it skips photo folders, program folders and tiny sound effects.
const EXT = { music: /\.(mp3|m4a|aac|flac|wav|ogg|oga|opus|weba|aif|aiff)$/i, video: /\.(mp4|m4v|webm|mov|mkv|ogv)$/i };
const FOLDER = { music: "Music", video: "Videos" };
const SKIP_DIR = /^(\$recycle\.bin|system volume information|windows|program files( \(x86\))?|programdata|appdata|node_modules|\.git|\.hub|temp|tmp|cache|caches|steamapps|xboxgames|recovery|perflogs)$/i;
const PHOTO_DIR = /(^|[\s_.-])(photos?|pictures?|pics|imgs?|images?|camera|camera roll|dcim|screenshots?|wallpapers?|fotos?|im[aá]genes|selfies)($|[\s_.-])/i;
const MUSIC_DIR = /(^|[\s_.-])(music|songs?|audio|mp3s?|tracks?|beats?|albums?|playlists?|dj|m[uú]sica|canciones|mixes|remixes|instrumentals?)($|[\s_.-])/i;
const VIDEO_DIR = /(^|[\s_.-])(videos?|v[ií]deos|movies?|films?|clips?|shows?|series|pel[ií]culas|tv|anime|recordings?)($|[\s_.-])/i;
// what a folder looks like it holds, from its own name or the nearest parent with a telling name
function folderHint(names) {
  for (let i = names.length - 1; i >= 0; i--) {
    if (PHOTO_DIR.test(names[i])) return "photo";
    if (MUSIC_DIR.test(names[i])) return "music";
    if (VIDEO_DIR.test(names[i])) return "video";
  }
  return "";
}
// which list a file belongs in, in a mixed folder (or null to leave it out)
function autoKind(name, size, hint) {
  if (hint === "photo") return null;
  if (EXT.music.test(name)) return hint === "music" || size >= 1.2e6 ? "music" : null;
  if (EXT.video.test(name)) return size >= 1e6 ? "video" : null;
  return null;
}
let tagCache = null,
  tagT = 0;
const libCache = new Map();
const libId = (p) => sha(String(p).toLowerCase()).slice(0, 8);
function libraries() {
  let L = [].concat(C.libraries || []).filter((l) => l && l.path);
  for (const l of L) l.id = l.id || libId(l.path);
  return L;
}
// the folders a person sees for one kind (music or video)
function libsFor(u, kind) {
  const out = [
    { key: "u:" + u.id + ":" + kind, scope: "u", dir: userDir(u, FOLDER[kind]), mode: kind, label: "Mine" },
    { key: "s:" + kind, scope: "s", dir: path.join(C.root, "Shared", FOLDER[kind]), mode: kind, label: "Shared" },
  ];
  for (const l of libraries()) {
    const mode = l.kind === "music" || l.kind === "video" ? l.kind : "auto";
    if ((mode === kind || mode === "auto") && (l.everyone || u.role === "owner")) out.push({ key: "l:" + l.id, scope: "l" + l.id, dir: l.path, mode, label: l.label || path.basename(l.path) || l.path });
  }
  return out;
}
function libDir(u, scope, kind) {
  const l = libsFor(u, kind).find((x) => x.scope === scope);
  return l ? l.dir : null;
}
const mediaId = (kind, scope, rel) => Buffer.from(kind + "\n" + scope + "\n" + rel).toString("base64url");
function fromId(id) {
  const p = Buffer.from(String(id || ""), "base64url").toString("utf8").split("\n");
  return p.length === 3 && FOLDER[p[0]] ? { kind: p[0], scope: p[1], rel: p[2] } : null;
}
function tagsOf(file, st, name) {
  if (!tagCache) tagCache = readJson(hubf("cache/tags.json"), {});
  const k = file,
    c = tagCache[k];
  if (c && c.s === st.size && c.m === Math.floor(st.mtimeMs)) return c;
  const t = readTags(file, name);
  tagCache[k] = { s: st.size, m: Math.floor(st.mtimeMs), title: t.title, artist: t.artist, album: t.album, bpm: t.bpm, key: t.key };
  clearTimeout(tagT);
  tagT = setTimeout(() => writeJson(hubf("cache/tags.json"), tagCache), 2000);
  return tagCache[k];
}
// one walk through a folder collects its music and its videos
async function scanLib(L) {
  const out = { music: [], video: [] };
  const walk = async (dir, rel, names) => {
    let ents;
    try {
      ents = await fsp.readdir(dir, { withFileTypes: !0 });
    } catch {
      return;
    }
    const hint = L.mode === "auto" ? folderHint(names) : "";
    for (const e of ents) {
      if (e.name.startsWith(".") || e.name.startsWith("~$")) continue;
      const full = path.join(dir, e.name),
        r = rel ? rel + "/" + e.name : e.name;
      if (e.isDirectory()) {
        if (names.length >= 14 || SKIP_DIR.test(e.name) || (L.mode === "auto" && PHOTO_DIR.test(e.name))) continue;
        await walk(full, r, [...names, e.name]);
        continue;
      }
      if (e.name.endsWith(".part")) continue;
      const maybe = L.mode === "auto" ? EXT.music.test(e.name) || EXT.video.test(e.name) : EXT[L.mode].test(e.name);
      if (!maybe) continue;
      let st;
      try {
        st = await fsp.stat(full);
      } catch {
        continue;
      }
      const kind = L.mode === "auto" ? autoKind(e.name, st.size, hint) : L.mode;
      if (!kind) continue;
      const t = kind === "music" ? tagsOf(full, st, e.name) : { title: e.name.replace(/\.[^.]+$/, "") };
      out[kind].push({ id: mediaId(kind, L.scope, r), name: e.name, title: t.title, artist: t.artist || "", album: t.album || "", bpm: t.bpm || 0, key: t.key || "", size: st.size, mtime: Math.floor(st.mtimeMs), type: typeOf(e.name), scope: L.scope, where: L.label, folder: rel });
    }
  };
  await walk(L.dir, "", []);
  return out;
}
// a folder's list, from memory when it's recent (and refreshed in the background when older)
async function libItems(L, kind) {
  const c = libCache.get(L.key);
  if (c && Date.now() - c.t > 60000 && !c.busy)
    c.busy = scanLib(L)
      .then((items) => libCache.set(L.key, { t: Date.now(), items }))
      .catch(() => (c.busy = null));
  if (c) return c.items[kind] || [];
  const items = await scanLib(L);
  libCache.set(L.key, { t: Date.now(), items });
  return items[kind] || [];
}
const scanning = new Set();
const forget = (u, kind) => (libCache.delete("u:" + u.id + ":" + kind), libCache.delete("s:" + kind));
async function listMedia(u, kind) {
  const items = [];
  for (const L of libsFor(u, kind)) items.push(...(await libItems(L, kind)));
  return items.sort((a, b) => b.mtime - a.mtime);
}
// folders on the rig, for the owner picking one from another device
function drives() {
  if (process.platform !== "win32") return ["/"];
  const out = [];
  for (let c = 67; c <= 90; c++) {
    const d = String.fromCharCode(c) + ":\\";
    try {
      fs.statSync(d) && out.push(d);
    } catch {}
  }
  return out;
}
function browse(p) {
  if (!p) return { path: "", parent: null, dirs: drives().map((d) => ({ name: d, path: d })) };
  const full = path.resolve(p);
  let ents = [];
  try {
    ents = fs.readdirSync(full, { withFileTypes: !0 });
  } catch (e) {
    throw Object.assign(new Error("Can't open that folder on the rig."), { code: 400 });
  }
  const parent = path.dirname(full) === full ? "" : path.dirname(full);
  return {
    path: full,
    parent,
    dirs: ents
      .filter((e) => e.isDirectory() && !e.name.startsWith(".") && !e.name.startsWith("$") && !/^(system volume information|recovery|perflogs)$/i.test(e.name))
      .map((e) => ({ name: e.name, path: path.join(full, e.name) }))
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(0, 500),
  };
}

// ---- save from a link -----------------------------------------------------------------------------
// A link to a music or video file (one you bought, free or Creative Commons music, a file in your
// own Google Drive or Dropbox) is downloaded by the rig straight into your Music or Videos, so
// big files keep going while your devices are off. Streaming sites are not downloaded from.
const NO_RIP = /(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com|googlevideo\.com|spotify\.com|scdn\.co|soundcloud\.com|sndcdn\.com|music\.apple\.com|tidal\.com|deezer\.com|tiktok\.com|instagram\.com|facebook\.com|fbcdn\.net|twitch\.tv|netflix\.com|primevideo\.com|disneyplus\.com|hulu\.com|pandora\.com|audiomack\.com)$/i;
const TYPE_EXT = { "audio/mpeg": ".mp3", "audio/mp3": ".mp3", "audio/mp4": ".m4a", "audio/x-m4a": ".m4a", "audio/aac": ".aac", "audio/flac": ".flac", "audio/x-flac": ".flac", "audio/wav": ".wav", "audio/x-wav": ".wav", "audio/wave": ".wav", "audio/ogg": ".ogg", "audio/opus": ".opus", "audio/webm": ".weba", "video/mp4": ".mp4", "video/x-m4v": ".m4v", "video/webm": ".webm", "video/quicktime": ".mov", "video/x-matroska": ".mkv", "video/ogg": ".ogv" };
const jobs = new Map();
// share links that open a page turned into the file itself
function directLink(u) {
  const x = new URL(u);
  if (/(^|\.)dropbox\.com$/i.test(x.hostname)) (x.searchParams.delete("dl"), x.searchParams.set("dl", "1"));
  const g = /(^|\.)drive\.google\.com$/i.test(x.hostname) && (/\/file\/d\/([\w-]+)/.exec(x.pathname) || (x.searchParams.get("id") && [0, x.searchParams.get("id")]));
  if (g) return "https://drive.usercontent.google.com/download?id=" + g[1] + "&export=download&confirm=t";
  if (/(^|\.)1drv\.ms$|(^|\.)onedrive\.live\.com$/i.test(x.hostname) && !x.searchParams.has("download")) x.searchParams.set("download", "1");
  return x.toString();
}
async function safeHost(x) {
  if (!/^https?:$/.test(x.protocol)) throw new Error("Only http and https links can be saved.");
  if (NO_RIP.test(x.hostname)) throw new Error("Workbench doesn't download from streaming sites like " + x.hostname.replace(/^www\./, "") + ". Use a direct link to a file you own.");
  if (C.allowLocalFetch) return;
  const addrs = await require("dns").promises.lookup(x.hostname, { all: !0 }).catch(() => {
    throw new Error("Can't find " + x.hostname + ". Check the link.");
  });
  for (const a of addrs) if (/^(127\.|0\.|169\.254\.|::1$|fe80:|::ffff:127\.)/i.test(a.address)) throw new Error("That link points at the rig itself.");
}
function fileName(res, url, kind, type) {
  let n = "";
  const cd = res.headers.get("content-disposition") || "";
  const m = /filename\*=(?:UTF-8'')?([^;]+)/i.exec(cd) || /filename="?([^";]+)"?/i.exec(cd);
  if (m)
    try {
      n = decodeURIComponent(m[1].trim().replace(/^"|"$/g, ""));
    } catch {
      n = m[1];
    }
  if (!n)
    try {
      n = decodeURIComponent(new URL(url).pathname.split("/").filter(Boolean).pop() || "");
    } catch {}
  n = safeName(n) || (kind === "video" ? "Video" : "Song") + " " + new Date().toISOString().slice(0, 10);
  if (!EXT[kind].test(n)) n = n.replace(/\.[a-z0-9]{2,5}$/i, "") + (TYPE_EXT[type] || (kind === "video" ? ".mp4" : ".mp3"));
  return n;
}
async function runJob(job, u) {
  job.state = "downloading";
  const ctl = new AbortController();
  job.cancel = () => ctl.abort();
  let stall = setTimeout(() => ctl.abort(), 60000),
    tmp = "";
  try {
    let url = directLink(job.url),
      res = null;
    for (let hop = 0; hop < 8; hop++) {
      const x = new URL(url);
      await safeHost(x);
      res = await fetch(url, { redirect: "manual", signal: ctl.signal, headers: { "User-Agent": "WorkbenchHub/" + VERSION, Accept: "audio/*,video/*,*/*;q=0.5" } });
      if (res.status >= 300 && res.status < 400 && res.headers.get("location")) {
        url = new URL(res.headers.get("location"), url).toString();
        continue;
      }
      break;
    }
    if (!res || !res.ok) throw new Error("The link answered " + (res ? res.status : "nothing") + ".");
    const type = String(res.headers.get("content-type") || "").split(";")[0].trim().toLowerCase(),
      cd = /filename\*?=(?:UTF-8'')?"?([^";]+)/i.exec(res.headers.get("content-disposition") || ""),
      guess = (cd ? cd[1] : "") + " " + decodeURIComponent(new URL(url).pathname),
      kind = job.to || (/^audio\//.test(type) ? "music" : /^video\//.test(type) ? "video" : /\.(mp3|m4a|aac|flac|wav|ogg|oga|opus|weba|aif|aiff)\b/i.test(guess) ? "music" : /\.(mp4|m4v|webm|mov|mkv|ogv)\b/i.test(guess) ? "video" : "");
    if (/text\/html|application\/xhtml/.test(type)) throw new Error("That link opens a web page, not a file. Use the file's direct download link (it usually ends in .mp3 or .mp4).");
    if (!kind) throw new Error("That isn't a music or video file (it's " + (type || "something else") + ").");
    const name = fileName(res, url, kind, type),
      base = job.shared ? path.join(C.root, "Shared", FOLDER[kind]) : userDir(u, FOLDER[kind]);
    fs.mkdirSync(base, { recursive: !0 });
    let dest = path.join(base, name),
      n = 2;
    while (fs.existsSync(dest)) dest = path.join(base, name.replace(/(\.[^.]+)$/, " (" + n++ + ")$1"));
    Object.assign(job, { kind, name: path.basename(dest), total: +res.headers.get("content-length") || 0, got: 0 });
    tmp = dest + ".part";
    const ws = fs.createWriteStream(tmp);
    for await (const chunk of res.body) {
      clearTimeout(stall);
      stall = setTimeout(() => ctl.abort(), 60000);
      job.got += chunk.length;
      if (!ws.write(chunk)) await new Promise((r) => ws.once("drain", r));
    }
    await new Promise((ok, bad) => (ws.end(ok), ws.on("error", bad)));
    if (!job.got) throw new Error("The link gave an empty file.");
    fs.renameSync(tmp, dest);
    tmp = "";
    job.state = "done";
    job.mediaId = mediaId(kind, job.shared ? "s" : "u", path.basename(dest));
    forget(u, kind);
    log("Saved from a link:", job.name, "for", u.name);
  } catch (e) {
    job.state = "error";
    job.err = e.name === "AbortError" ? (job.cancelled ? "Stopped." : "The download stalled. Try again.") : e.message;
    tmp && fs.rmSync(tmp, { force: !0 });
  } finally {
    clearTimeout(stall);
    job.at = Date.now();
    delete job.cancel;
    broadcast({ type: "media", job: job.id, state: job.state }, (c) => c.user.id === u.id);
    nextJob(u);
  }
}
function nextJob(u) {
  const mine = [...jobs.values()].filter((j) => j.user === u.id);
  if (mine.filter((j) => j.state === "downloading").length >= 2) return;
  const q = mine.find((j) => j.state === "queued");
  q && runJob(q, u);
}
const jobView = (j) => ({ id: j.id, url: j.url, name: j.name, kind: j.kind, got: j.got, total: j.total, state: j.state, err: j.err, mediaId: j.mediaId || "", at: j.at });

// ---- notifications -----------------------------------------------------------------------------
const subject = () => (C.origins && C.origins[0]) || APP;
async function pushTo(d, msg) {
  if (!d.push) return 0;
  try {
    const code = await push.send(d.push, msg, VAPID, subject(), { topic: String(msg.tag || "").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 32) || undefined });
    if (code === 404 || code === 410) ((d.push = null), saveDevices(), log("Push: a device's notifications expired:", d.name));
    else if (code >= 400) log("Push to", d.name, "answered", code);
    return code;
  } catch (e) {
    log("Push to", d.name, "failed:", e.message);
    return 0;
  }
}
const target = (t) => (t.ord ? "ord:" + t.ord : t.co ? "co:" + t.co : "");
const localDay = () => new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
async function checkReminders() {
  const D = readWork();
  if (!D) return;
  const items = __wbReminders(D, Date.now()),
    N = readJson(hubf("notified.json"), { sent: {}, daily: "" }),
    to = DV.devices.filter((d) => d.push && d.notify !== !1 && canWork(U.users.find((u) => u.id === d.user)));
  if (to.length) {
    const fresh = items.filter((t) => t.p >= 50 && !N.sent[t.key]);
    const msgs =
      fresh.length > 3
        ? [{ title: fresh.length + " things need you", body: fresh.slice(0, 3).map((t) => t.text).join(" · ") + "…", tag: "wb-many", open: "bell" }]
        : fresh.map((t) => ({ title: t.text, body: t.sub || "", tag: t.key, open: target(t) }));
    for (const d of to) for (const m of msgs) await pushTo(d, m);
    for (const t of fresh) N.sent[t.key] = Date.now();
    // a morning round-up of everything on the list
    if (new Date().getHours() >= 8 && N.daily !== localDay() && items.length) {
      N.daily = localDay();
      for (const d of to) await pushTo(d, { title: "Today: " + items.length + " thing" + (items.length === 1 ? "" : "s") + " on your list", body: items.slice(0, 3).map((t) => t.text).join(" · "), tag: "wb-daily", open: "bell" });
    }
  }
  for (const k in N.sent) if (Date.now() - N.sent[k] > 45 * 864e5) delete N.sent[k];
  writeJson(hubf("notified.json"), N);
}

// ---- the AI (Ollama on this computer) ----------------------------------------------------------
async function ollama(p, init, ms) {
  const r = await fetch(C.ollama.replace(/\/+$/, "") + p, Object.assign({ signal: AbortSignal.timeout(ms || 180000) }, init || {}));
  if (!r.ok) throw new Error("Ollama answered " + r.status);
  return r.json();
}
async function pickModel() {
  if (C.aiModel) return C.aiModel;
  const t = await ollama("/api/tags", {}, 8000),
    names = (t.models || []).map((m) => m.name);
  return names.find((n) => /^llama3\.1/.test(n)) || names[0] || "";
}
function briefContext(D) {
  const live = (a) => (a || []).filter((r) => r && !r.del),
    co = (id) => live(D.companies).find((c) => c.id === id),
    lines = [];
  for (const o of live(D.orders).filter((o) => !["Done", "Cancelled", "Installed", "Paid"].includes(o.status)).slice(0, 30)) {
    const c = co(o.companyId),
      l = (o.log || [])[0];
    lines.push("- " + [o.no, c ? c.name : "no customer", o.status, o.want ? "wants: " + String(o.want).slice(0, 140) : "", o.due ? "due " + o.due : "", l ? "last update: " + String(l.text).slice(0, 100) : ""].filter(Boolean).join(" | "));
  }
  return lines.join("\n");
}
let digesting = null;
async function makeDigest() {
  if (digesting) return digesting;
  digesting = (async () => {
    const D = readWork();
    if (!D) return null;
    const items = __wbReminders(D, Date.now()),
      biz = (D.settings && D.settings.biz) || {},
      dg = { at: Date.now(), items: items.slice(0, 20).map((t) => ({ key: t.key, kind: t.kind, p: t.p, text: t.text, sub: t.sub, chip: t.chip, cls: t.cls, ord: t.ord, co: t.co })), text: "", model: "", err: "" };
    try {
      const model = await pickModel();
      if (model) {
        const r = await ollama("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model,
            stream: !1,
            keep_alive: "30m",
            options: { num_ctx: 8192, temperature: 0.3 },
            messages: [
              { role: "system", content: "You write the short hourly briefing for the owner of " + (biz.name || "a small vehicle graphics, decal and wrap shop") + ". Use only the facts given. Name customers and job numbers. One short paragraph of 3 to 5 sentences, no lists, no headings." + (C.lang ? " Write in " + C.lang + "." : "") },
              { role: "user", content: "Now: " + new Date().toString().slice(0, 21) + "\n\nTHE LIST (most important first):\n" + (items.length ? items.slice(0, 15).map((t) => "- " + t.text + (t.sub ? " (" + t.sub + ")" : "")).join("\n") : "- nothing waiting") + "\n\nOPEN JOBS:\n" + (briefContext(D) || "- none") + "\n\nWrite the briefing: what matters most right now and why." },
            ],
          }),
        });
        dg.text = String((r.message && r.message.content) || "")
          .replace(/<think>[\s\S]*?<\/think>/gi, "")
          .trim();
        dg.model = model;
      }
    } catch (e) {
      dg.err = "The AI on the rig didn't answer (" + e.message + ").";
    }
    writeJson(hubf("digest.json"), dg);
    broadcast({ type: "digest", at: dg.at }, (c) => canWork(c.user));
    return dg;
  })().finally(() => (digesting = null));
  return digesting;
}
function proxyOllama(req, res, url) {
  const t = new URL(C.ollama),
    q = new URLSearchParams(url.search);
  q.delete("t");
  const headers = Object.assign({}, req.headers);
  for (const h of ["origin", "referer", "authorization", "host", "cookie"]) delete headers[h];
  for (const h of Object.keys(headers)) if (/^sec-|^access-control-/i.test(h)) delete headers[h];
  const pr = http.request({ hostname: t.hostname, port: t.port || 80, method: req.method, path: (url.pathname.replace(/^\/ollama/, "") || "/") + (q.toString() ? "?" + q : ""), headers }, (r) => {
    const h = Object.assign({}, r.headers);
    for (const k of Object.keys(h)) if (/^access-control-/i.test(k)) delete h[k];
    res.writeHead(r.statusCode, h);
    r.pipe(res);
  });
  pr.on("error", () => fail(res, 502, "The AI isn't running on the rig. On the rig, open Ollama (it starts with Windows once installed), then try again."));
  req.pipe(pr);
}

// ---- updates -----------------------------------------------------------------------------------
const newer = (a, b) => {
  const x = String(a).split(".").map(Number),
    y = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  return !1;
};
// (now: asked for by the owner in Workbench, so it runs even with autoUpdate off and says what happened)
let updating = !1;
async function checkUpdate(now) {
  if ((!C.autoUpdate && now !== !0) || !C.update) return { ok: !1, error: "This Hub has no update address." };
  if (updating) return { ok: !0, updating: !0, latest: UPD.latest };
  updating = !0;
  try {
    const r = await fetch(C.update + "version.json?" + Date.now(), { cache: "no-store", signal: AbortSignal.timeout(20000) });
    if (!r.ok) throw new Error("The update address answered " + r.status);
    const v = await r.json();
    Object.assign(UPD, { checked: Date.now(), latest: String(v.version || ""), err: "" });
    if (!newer(v.version, VERSION)) return { ok: !0, updating: !1, latest: UPD.latest };
    const tmp = path.join(__dirname, ".update");
    fs.rmSync(tmp, { recursive: !0, force: !0 });
    fs.mkdirSync(tmp);
    for (const [name, hash] of Object.entries(v.files || {})) {
      if (!/^[\w.-]+$/.test(name)) throw new Error("bad file name " + name);
      const b = Buffer.from(await (await fetch(C.update + name, { cache: "no-store", signal: AbortSignal.timeout(60000) })).arrayBuffer());
      if (sha(b) !== hash) throw new Error(name + " didn't download correctly");
      fs.writeFileSync(path.join(tmp, name), b);
    }
    for (const name of Object.keys(v.files)) fs.copyFileSync(path.join(tmp, name), path.join(__dirname, name));
    fs.rmSync(tmp, { recursive: !0, force: !0 });
    log("Updated to", v.version, "- restarting");
    try {
      pubEvent("update", "Hub updated to " + v.version, "");
    } catch {}
    setTimeout(() => process.exit(3), 800);
    return { ok: !0, updating: !0, latest: UPD.latest };
  } catch (e) {
    Object.assign(UPD, { checked: Date.now(), err: e.message });
    log("Update check:", e.message);
    return { ok: !1, error: e.message };
  } finally {
    updating = !1;
  }
}

// ---- the status page (what you see opening the Hub's address in a browser) ---------------------
function statusPage(req, res) {
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]),
    work = readWorkText(),
    html =
      '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Workbench Hub</title><style>body{margin:0;background:#101114;color:#eef1f5;font:15px/1.5 system-ui,Segoe UI,sans-serif}main{max-width:640px;margin:8vh auto;padding:0 20px}h1{font-size:34px;margin:0 0 4px;letter-spacing:-.01em}.k{color:#9aa2ae;text-transform:uppercase;font-size:12px;letter-spacing:.16em}.ok{color:#7dffa8}ul{padding-left:18px}a{color:#7dffa8}code{background:#1d2026;padding:2px 6px}</style><main><div class="k">// Workbench Hub ' +
      VERSION +
      '</div><h1>Running <span class="ok">●</span></h1><p>This is your Workbench home server. Open Workbench on any of your devices and connect to this address: the menu at the top right → Hub.</p><ul><li>' +
      U.users.length +
      " people · " +
      DV.devices.length +
      " devices signed in</li><li>Work data: " +
      (work ? Math.round(work.length / 1024) + " KB" : "none yet") +
      '</li></ul><p><a href="' +
      APP +
      '/Workbench/">Open Workbench</a></p></main>';
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
  res.end(html);
}

// ---- the rig's health (the Rig tab in Workbench) -------------------------------------------------
// Only what's safe on a screen other people look at: no addresses, paths, drive letters, driver
// versions, programs on the graphics card or the private network (1.2.1).
const { execFile } = require("child_process");
const STARTED = Date.now();
const UPD = { checked: 0, latest: "", err: "" };
// run a program on the rig and give back what it printed, or "" if it isn't there
function runOut(cmds, args, ms) {
  return new Promise((done) => {
    const list = [].concat(cmds),
      next = (i) => {
        if (i >= list.length) return done("");
        execFile(list[i], args, { timeout: ms || 4000, windowsHide: !0, maxBuffer: 4e6 }, (e, out) => (e && !out ? next(i + 1) : done(String(out || ""))));
      };
    next(0);
  });
}
const WIN = process.platform === "win32";
const NVSMI = WIN ? ["nvidia-smi", "C:\\Windows\\System32\\nvidia-smi.exe", "C:\\Program Files\\NVIDIA Corporation\\NVSMI\\nvidia-smi.exe"] : ["nvidia-smi"];
const num = (s) => {
  const n = parseFloat(String(s).trim());
  return isFinite(n) ? n : null;
};
// how busy the processor is: the share of time not idle since the last look
let cpuPrev = null;
function cpuNow() {
  const t = os.cpus().map((c) => c.times),
    sum = t.reduce((a, x) => ((a.idle += x.idle), (a.all += x.user + x.nice + x.sys + x.idle + x.irq), a), { idle: 0, all: 0 });
  return sum;
}
async function cpuBusy() {
  let a = cpuPrev;
  if (!a || Date.now() - a.at > 30000) ((a = Object.assign(cpuNow(), { at: Date.now() })), await new Promise((z) => setTimeout(z, 400)));
  const b = Object.assign(cpuNow(), { at: Date.now() });
  if (b.at - a.at < 400) return cpuPrev.pct;
  const pct = b.all > a.all ? Math.max(0, Math.min(100, Math.round((100 * (1 - (b.idle - a.idle) / (b.all - a.all))) * 10) / 10)) : 0;
  cpuPrev = Object.assign(b, { pct });
  return pct;
}
// the graphics card, from NVIDIA's own tool (cached a couple of seconds)
const gpuC = { t: 0, v: null, p: null };
async function gpuInfo() {
  if (Date.now() - gpuC.t < 2500) return gpuC.v;
  if (gpuC.p) return gpuC.p;
  return (gpuC.p = (async () => {
    const out = await runOut(NVSMI, ["--query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total,power.draw,power.limit,fan.speed", "--format=csv,noheader,nounits"], 5000);
    let cards = out
      .split(/\r?\n/)
      .filter((l) => l.trim())
      .map((l) => {
        const f = l.split(",").map((x) => x.trim());
        return { name: f[0], temp: num(f[1]), busy: num(f[2]), memUsed: num(f[3]), memTotal: num(f[4]), power: num(f[5]), powerMax: num(f[6]), fan: num(f[7]) };
      });
    gpuC.v = cards.length ? cards : null;
    gpuC.t = Date.now();
    gpuC.p = null;
    return gpuC.v;
  })());
}
// the AI (Ollama): is it up, which models it has, which one sits in memory now
async function aiGet(p, ms) {
  try {
    const r = await fetch(C.ollama.replace(/\/+$/, "") + p, { signal: AbortSignal.timeout(ms || 1500) });
    return r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}
async function aiInfo() {
  const [v, tags, ps] = await Promise.all([aiGet("/api/version"), aiGet("/api/tags"), aiGet("/api/ps")]);
  if (!v && !tags) return { up: !1 };
  return {
    up: !0,
    version: (v && v.version) || "",
    models: ((tags && tags.models) || []).map((m) => ({ name: m.name, size: m.size, at: Date.parse(m.modified_at) || 0, params: (m.details && m.details.parameter_size) || "", quant: (m.details && m.details.quantization_level) || "" })),
    loaded: ((ps && ps.models) || []).map((m) => ({ name: m.name, size: m.size, vram: m.size_vram, until: Date.parse(m.expires_at) || 0 })),
    model: C.aiModel || "",
  };
}
async function aiKeep(model, load) {
  const r = await fetch(C.ollama.replace(/\/+$/, "") + "/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model, keep_alive: load ? "30m" : 0 }), signal: AbortSignal.timeout(load ? 120000 : 15000) }).catch(() => null);
  if (!r) throw Object.assign(new Error("The AI isn't running on the rig."), { code: 502 });
  if (!r.ok) throw Object.assign(new Error("The AI said no: " + ((await r.text().catch(() => "")) || r.status).slice(0, 200)), { code: 502 });
  await r.text().catch(() => "");
}
// is this request coming from the rig itself? (the Hub only listens on the rig; Tailscale says who
// is on the other end in X-Forwarded-For, and the rig's own addresses mean it's the rig)
function localAddrs() {
  const s = new Set(["127.0.0.1", "::1"]);
  for (const l of Object.values(os.networkInterfaces())) for (const a of l || []) s.add(String(a.address).replace(/^::ffff:/, "").replace(/%.*$/, ""));
  return s;
}
function fromRig(req) {
  // through the "use from anywhere" door it's never the rig, whatever the addresses say
  if (req.wbRemote) return !1;
  const L = localAddrs(),
    ra = String(req.socket.remoteAddress || "").replace(/^::ffff:/, "");
  if (!L.has(ra)) return !1;
  const xf = String(req.headers["x-forwarded-for"] || "")
    .split(",")
    .map((s) => s.trim().replace(/^::ffff:/, "").replace(/^\[|\]$/g, ""))
    .filter(Boolean);
  if (!xf.length) return !(req.headers["x-forwarded-host"] || req.headers["tailscale-user-login"]);
  return xf.every((ip) => L.has(ip));
}
// the owner on the rig itself, or on a phone the owner paired as a Rig Remote (1.5.0)
const rigCtl = (req, a) => a.user.role === "owner" && (fromRig(req) || !!(a.device && a.device.remote));
// the rig itself only (the keys, pairing codes and who may be a Rig Remote): never a phone, never the
// anywhere door. (1.6.0: a paired Rig Remote can change everything else the rig's own screen can.)
const rigAdmin = (req, a) => a.user.role === "owner" && fromRig(req);
const ctlNo = (res) => fail(res, 403, "Only on the rig, or on a phone you paired as a Rig Remote.");
const adminNo = (res) => fail(res, 403, "Only on the rig itself.");
function diskList() {
  const root = path.resolve(C.root).toLowerCase(),
    out = [];
  for (const d of drives())
    try {
      const s = fs.statfsSync(d);
      out.push({ free: s.bavail * s.bsize, size: s.blocks * s.bsize, hub: root.startsWith(d.toLowerCase()) && (d !== "/" || out.length === 0) });
    } catch {}
  return out;
}
function lastBackup() {
  let best = null;
  for (const dir of [hubf("backups"), C.backupDir ? path.join(C.backupDir, "Workbench Hub backups") : ""].filter(Boolean))
    try {
      for (const f of fs.readdirSync(dir))
        if (/^work-.*\.json$/.test(f)) {
          const st = fs.statSync(path.join(dir, f));
          if (!best || st.mtimeMs > best.at) best = { at: st.mtimeMs, name: f, size: st.size, second: dir !== hubf("backups") };
        }
    } catch {}
  return best;
}
// who uses the Hub: people, their devices, and who is here right now
function usage() {
  const now = Date.now(),
    on = new Set([...live].map((c) => c.device.id)),
    devs = DV.devices.map((d) => {
      const x = U.users.find((y) => y.id === d.user);
      return { id: d.id, name: d.name, user: x ? x.name : "?", seen: d.seen || 0, online: on.has(d.id), push: !!d.push, created: d.created || 0 };
    }),
    act = (ms) => new Set(devs.filter((d) => d.online || now - d.seen < ms).map((d) => d.user)).size;
  return {
    people: U.users.length,
    devices: devs.length,
    online: devs.filter((d) => d.online).length,
    peopleOnline: act(0),
    visitors: liveStats(),
    sessions: sesStats(),
    today: act(864e5),
    week: act(7 * 864e5),
    month: act(30 * 864e5),
    list: devs.sort((a, b) => b.online - a.online || b.seen - a.seen),
  };
}
async function systemInfo(req) {
  const [cpu, gpu, ai] = await Promise.all([cpuBusy(), gpuInfo(), aiInfo()]),
    c0 = os.cpus()[0] || {},
    mem = process.memoryUsage();
  const libs = libraries().map((l) => {
    const c = libCache.get("l:" + l.id);
    let exists = !1;
    try {
      exists = fs.statSync(l.path).isDirectory();
    } catch {}
    return { everyone: !!l.everyone, exists, music: c ? c.items.music.length : null, video: c ? c.items.video.length : null };
  });
  return {
    at: Date.now(),
    rig: fromRig(req),
    machine: { os: WIN ? "Windows " + os.release() : os.type() + " " + os.release(), arch: os.arch(), up: Math.round(os.uptime()) },
    cpu: { model: String(c0.model || "").replace(/\s+/g, " ").trim(), cores: os.cpus().length, busy: cpu, speed: c0.speed || 0 },
    ram: { total: os.totalmem(), free: os.freemem() },
    disks: diskList(),
    gpu,
    ai,
    usage: usage(),
    libraries: libs,
    backup: lastBackup(),
    jobs: [...jobs.values()].filter((j) => j.state === "downloading" || j.state === "queued").length,
    hub: { version: VERSION, up: Math.round((Date.now() - STARTED) / 1000), node: process.version, mem: mem.rss, autoUpdate: !!C.autoUpdate, update: { checked: UPD.checked, latest: UPD.latest, err: UPD.err || "" }, tray: !!process.env.WB_HUB_TRAY },
  };
}

// ---- Discover: what the website shows everyone (1.3.0) ------------------------------
// Companies, their applications and messages, live on the rig
// (.hub/public.json and the Public folder). "Publish" puts what's live and approved on the
// Workbench website through GitHub, so visitors see it even while the rig is off. A small public
// door, the inbox (its own port, shared to the internet with Tailscale Funnel), only takes company
// applications and messages to companies; nothing else on the rig is reachable through it.
const PUBDIR = () => path.join(C.root, "Public");
let P = null;
function pubLoad() {
  if (!P) {
    P = Object.assign({ companies: [], apps: [], msgs: [], published: { at: 0, commit: "", files: {} }, forms: null, responses: [], events: [], changedAt: 0, pledges: [], supporters: [] }, readJson(hubf("public.json"), {}));
    // 1.4.0: ready-made forms, and 1.3.0's applications become answers to the company sign-up form
    if (!Array.isArray(P.forms)) P.forms = formDefaults();
    // 1.36.0: Spotlight is gone: drop its artist, songs and sign-up form
    delete P.artist; delete P.tracks; delete P.radioEpoch;
    P.forms = P.forms.filter((f) => f.kind !== "artist");
    const cf = P.forms.find((f) => f.kind === "company");
    if (cf && P.apps.length) {
      for (const a of P.apps)
        P.responses.push({ id: a.id, form: cf.id, slug: cf.slug, title: cf.title, kind: "company", at: a.at, files: a.logo ? { logo: a.logo } : {}, status: "new", items: cf.fields.map((q) => ({ id: q.id, label: q.label, type: q.type, map: q.map, value: q.map === "logo" ? a.logo || "" : q.map === "instagram" || q.map === "tiktok" || q.map === "facebook" ? (a.socials || {})[q.map] || "" : a[q.map] || "" })) });
      P.apps = [];
    }
    // 1.5.0: a form is on the website only after Post. Forms that went up with an earlier publish
    // count as posted; if nothing was ever published, none are.
    if (!Array.isArray(P.trails)) P.trails = [];
    for (const c of P.companies) c.stamp = c.stamp || newStamp();
    if (!P.postModel) {
      P.postModel = 1;
      const pb = P.published || (P.published = { at: 0, commit: "", files: {} }),
        before = !!(pb.at && pb.forms > 0);
      pb.formU = pb.formU || {};
      for (const f of P.forms)
        if (before && f.open && (f.u || 0) <= pb.at) pb.formU[f.id] = f.u || f.at || 1;
        else if (!before) f.open = !1;
    }
    // 1.15.0: the company sign-up also asks about a promotion budget (for forms made before this version)
    for (const f of P.forms)
      if (f.kind === "company" && !f.fields.some((q) => q.map === "budget")) {
        const i = f.fields.findIndex((q) => q.map === "contact");
        f.fields.splice(i < 0 ? f.fields.length : i, 0, { id: id36().slice(-8) + Math.floor(Math.random() * 1e4), type: "select", label: BUDGET_Q.label, req: !1, map: "budget", help: BUDGET_Q.help, opts: BUDGET_Q.opts.slice() });
        f.u = Date.now();
      }
    writeJson(hubf("public.json"), P);
  }
  return P;
}
// every change remembers when it happened, so the Rig tab can say "not published yet"
const pubSave = () => ((P.changedAt = Date.now()), writeJson(hubf("public.json"), P));
const clip = (v, n) => String(v ?? "").replace(/[\u0000-\u001f]/g, " ").trim().slice(0, n);
const webUrl = (u) => (/^https?:\/\/[^\s<>"']+$/i.test(String(u || "").trim()) ? String(u).trim().slice(0, 300) : "");
const SOCIALS = ["instagram", "tiktok", "facebook", "youtube", "x", "whatsapp", "soundcloud", "spotify"];
function slugOf(s) {
  return (
    String(s || "")
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 40) || "company"
  );
}
function uniqueSlug(name, id) {
  let s = slugOf(name),
    n = 2,
    t = s;
  while (pubLoad().companies.some((c) => c.slug === t && c.id !== id)) t = s + "-" + n++;
  return t;
}
function socialsOf(b) {
  const o = {};
  for (const k of SOCIALS) b && b[k] && webUrl(b[k]) && (o[k] = webUrl(b[k]));
  return o;
}
function companyFields(c, b) {
  for (const [k, n] of [["category", 40], ["description", 1500], ["city", 80], ["address", 160], ["phone", 40], ["email", 120], ["deal", 200], ["code", 40]]) k in b && (c[k] = clip(b[k], n));
  "website" in b && (c.website = webUrl(b.website));
  "socials" in b && (c.socials = socialsOf(b.socials));
  return c;
}
function companySave(b) {
  const L = pubLoad().companies,
    old = b.id && L.find((x) => x.id === b.id),
    c = old || { id: id36(), at: Date.now(), live: !0, featured: !1 },
    name = clip(b.name, 80) || c.name;
  if (!name) throw Object.assign(new Error("A company needs a name."), { code: 400 });
  if (!old || name !== c.name) c.slug = uniqueSlug(name, c.id);
  c.name = name;
  c.stamp = c.stamp || newStamp();
  companyFields(c, b);
  "featured" in b && (c.featured = !!b.featured);
  "live" in b && (c.live = !!b.live);
  c.u = Date.now();
  old || L.push(c);
  pubSave();
  return c;
}
// a picture or a song saved under its own fingerprint, so publishing never sends one twice
const PUBTYPES = { png: "img", jpg: "img", jpeg: "img", webp: "img" };
async function pubFile(req, name, kind) {
  const ext = path.extname(String(name || "")).slice(1).toLowerCase();
  if (PUBTYPES[ext] !== "img") throw Object.assign(new Error("Send a PNG, JPG or WEBP picture."), { code: 400 });
  const max = 6e6;
  if (+req.headers["content-length"] > max) throw Object.assign(new Error("Pictures up to 6 MB."), { code: 400 });
  const tmp = path.join(PUBDIR(), ".in-" + id36());
  const size = await receive(req, tmp);
  if (size > max) throw (await fsp.rm(tmp, { force: !0 }), Object.assign(new Error("That file is too big."), { code: 400 }));
  const file = sha(fs.readFileSync(tmp)).slice(0, 16) + "." + (ext === "jpeg" ? "jpg" : ext);
  await fsp.rename(tmp, path.join(PUBDIR(), file));
  return file;
}
function pubFromB64(b64, mime) {
  const ext = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" }[mime];
  if (!ext || !b64) return "";
  const buf = Buffer.from(String(b64), "base64");
  if (!buf.length || buf.length > 1.5e6) return "";
  const file = sha(buf).slice(0, 16) + "." + ext;
  fs.mkdirSync(PUBDIR(), { recursive: !0 });
  fs.writeFileSync(path.join(PUBDIR(), file), buf);
  return file;
}
// tell the owner's devices
function pubNotify(title, body, kind, ref, acts) {
  pubEvent(kind || "note", title, body, ref);
  trayNote(title, body);
  const owners = new Set(U.users.filter((u) => u.role === "owner").map((u) => u.id)),
    open = ref && (kind === "form" || kind === "message" || kind === "remote") ? "rig:" + (kind === "form" ? "resp" : kind === "message" ? "msg" : "remote") + ":" + ref : "rig";
  for (const d of DV.devices) {
    if (!owners.has(d.user) || !d.push) continue;
    const m = { title, body, tag: "pub-" + (ref || "x"), open };
    // a paired Rig Remote gets buttons (Approve, Done…) that work without opening Workbench
    if (d.remote && acts && acts.length && d.via) {
      const k = crypto.randomBytes(18).toString("base64url");
      ACTS.set(k, { dev: d.id, kind, ref, acts: acts.map((x) => x[0]), exp: Date.now() + 3 * 864e5 });
      m.actions = acts.slice(0, 2).map(([action, t]) => ({ action, title: t }));
      m.act = { k, url: d.via };
    }
    pushTo(d, m);
  }
  broadcast({ type: "pub" }, (c) => c.user.role === "owner");
}
// one-time keys behind the buttons on a Rig Remote's notifications
const ACTS = new Map();
setInterval(() => {
  for (const [k, v] of ACTS) v.exp < Date.now() && ACTS.delete(k);
}, 3600000).unref();
function actDo(b) {
  const A = ACTS.get(String(b.k || "")),
    d = A && DV.devices.find((x) => x.id === A.dev);
  if (!A || A.exp < Date.now() || !d || !d.remote) throw Object.assign(new Error("That button has expired. Open Workbench to decide."), { code: 410 });
  const what = String(b.do || "");
  if (!A.acts.includes(what)) throw Object.assign(new Error("Not that one."), { code: 400 });
  ACTS.delete(String(b.k));
  const S = pubLoad();
  if (A.kind === "form") {
    const r = S.responses.find((x) => x.id === A.ref);
    if (!r) throw Object.assign(new Error("That answer is gone."), { code: 404 });
    let made = null;
    if (what === "approve") (r.kind === "company" && (made = responseToCompany(r)), (r.status = "approved"), pubEvent("company", made ? made.name + " is in Discover" : "Approved: " + r.title, made ? "Publish to put it on the website." : "", r.id));
    else r.status = what === "decline" ? "declined" : "done";
    r.decided = Date.now();
    writeJson(hubf("public.json"), S);
    broadcast({ type: "pub" }, (c) => c.user.role === "owner");
    log("Decided from a notification:", what, r.title);
    return { ok: !0, text: what === "approve" ? (made ? made.name + " is in Discover. Publish to put it on the website." : "Approved.") : what === "decline" ? "Turned down." : "Done." };
  }
  if (A.kind === "message") {
    S.msgs = S.msgs.filter((x) => x.id !== A.ref);
    writeJson(hubf("public.json"), S);
    broadcast({ type: "pub" }, (c) => c.user.role === "owner");
    return { ok: !0, text: "Marked as passed on." };
  }
  throw Object.assign(new Error("Not that one."), { code: 400 });
}
// ---- publishing to the website through GitHub
const ghTok = () => readJson(hubf("github.json"), {}).token || "";
async function gh(p, o) {
  const cfg = C.publish || {},
    r = await fetch((process.env.WB_GH_API || "https://api.github.com") + (p.startsWith("/repos") || p.startsWith("/user") ? p : "/repos/" + cfg.repo + p), {
      method: (o && o.method) || "GET",
      headers: { Authorization: "Bearer " + ((o && o.token) || ghTok()), Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "WorkbenchHub/" + VERSION, "Content-Type": "application/json" },
      body: o && o.body ? JSON.stringify(o.body) : void 0,
      signal: AbortSignal.timeout((o && o.ms) || 60000),
    });
  const t = await r.text();
  let j = null;
  try {
    j = JSON.parse(t);
  } catch {}
  if (!r.ok) throw Object.assign(new Error("GitHub said " + r.status + ": " + ((j && j.message) || t).slice(0, 160)), { code: 502, status: r.status, ghMsg: String((j && j.message) || "") });
  return j;
}
// what GitHub's "no" means, in plain words (null when it isn't about the key)
function ghPlain(e, repo) {
  const st = e && e.status,
    m = String((e && e.ghMsg) || ""),
    fix = "On github.com: your picture → Settings → Developer settings → Personal access tokens → Fine-grained tokens → the Workbench rig key → Edit. Under Repository access pick Only select repositories → " + (String(repo || "").split("/")[1] || "workbench") + ", and under Repository permissions set Contents to Read and write → Update. Then press Post again (the same key keeps working).";
  if (st === 401) return "GitHub says the key is wrong or has expired. Make a new key (Fine-grained tokens → Generate new token) and paste it here.";
  if (st === 403 && /rate limit/i.test(m)) return "";
  if (st === 403 || (st === 404 && /not found/i.test(m))) return "The key can look at the website's repository but can't change it. " + fix;
  return "";
}
async function pubSetup(b) {
  const repo = clip(b.repo, 120).replace(/^https?:\/\/github\.com\//i, "").replace(/\.git$|\/+$/g, ""),
    token = clip(b.token, 300);
  if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) throw Object.assign(new Error("The repository looks like owner/name, for example you/workbench."), { code: 400 });
  if (!token) throw Object.assign(new Error("Paste the GitHub key (token)."), { code: 400 });
  let info;
  try {
    info = await gh("/repos/" + repo, { token });
  } catch (e) {
    throw Object.assign(new Error(e.status === 404 ? "GitHub can't find " + repo + " with this key. Check the name, and that the key's Repository access includes it." : ghPlain(e, repo) || e.message), { code: 400 });
  }
  if (!info.permissions || !info.permissions.push) throw Object.assign(new Error("That key can't write to " + repo + ". Give it Contents: Read and write."), { code: 400 });
  // (that answer is about the account, not the key: make sure the key itself can write, with a
  // tiny file GitHub keeps nowhere visible)
  try {
    await gh("/repos/" + repo + "/git/blobs", { method: "POST", token, body: { content: Buffer.from("Workbench can publish here.\n").toString("base64"), encoding: "base64" } });
  } catch (e) {
    throw Object.assign(new Error(ghPlain(e, repo) || e.message), { code: 400 });
  }
  writeJson(hubf("github.json"), { token });
  C.publish = { repo, branch: clip(b.branch, 60) || info.default_branch || "main", dir: "public" };
  writeJson(CONF, C);
  log("Publishing set up for", repo);
  return { repo, branch: C.publish.branch };
}
function pubData() {
  const S = pubLoad(),
    m = (f) => (f ? "media/" + f : ""),
    live = S.companies.filter((c) => c.live !== !1);
  return {
    v: 1,
    at: Date.now(),
    inbox: C.inbox && C.inboxUrl ? C.inboxUrl : "",
    google: (C.google && C.google.clientId) || "",
    trails: (S.trails || []).filter((t) => t.on !== !1 && t.stops.length >= 2).map((t) => ({ id: t.id, title: t.title, desc: t.desc || "", reward: t.reward || "", stops: t.stops.filter((x) => live.some((c) => c.slug === x)) })),
    support: S.support && (S.support.email || (S.support.links || []).length || S.support.cost) ? { email: S.support.email || "", links: S.support.links || [], cost: S.support.cost || "", costNote: S.support.costNote || "" } : null,
    supporters: (S.supporters || []).filter((x) => x.on !== !1).sort((a, b) => b.amount - a.amount || a.at - b.at).slice(0, 100).map((x) => ({ n: x.anon ? "Anonymous" : x.name, a: x.amount })),
    today: S.dayCo && live.some((c) => c.slug === S.dayCo.slug) ? S.dayCo : null,
    // (1.34.0) the company of the week: the paid or chosen booking for this week, else nothing (the website then takes turns)
    // (1.35.0) nobody paid for this week: the owner's own choice fills it, so paying is what puts anyone else there
    week: (() => {
      const b = weekNow(S);
      if (b && live.some((c) => c.slug === b.slug)) return { slug: b.slug, from: b.from, until: weekEnd(b.from) };
      const d = S.defaultCo && live.find((c) => c.slug === S.defaultCo), mo = monOf(Date.now());
      return d ? { slug: d.slug, from: mo, until: weekEnd(mo), def: !0 } : null;
    })(),
    prices: bizPrices(S),
    // (1.36.0) the ad of the week: only a paid booking whose ad the owner approved
    ad: (() => {
      const b = adNow(S), c = b && live.find((x) => x.slug === b.slug);
      return c && c.ad && c.ad.title ? { slug: c.slug, name: c.name, from: b.from, until: weekEnd(b.from), title: c.ad.title, text: c.ad.text || "", btn: c.ad.btn || "Visit", link: c.ad.link, img: m(c.ad.img) } : null;
    })(),
    stats: Object.fromEntries(live.map((c) => [c.slug, trfSum("co", c.slug, 30)]).filter((x) => x[1] >= 5)),
    forms: (S.forms || []).filter((f) => f.open).map((f) => ({ slug: f.slug, title: f.title, desc: f.desc || "", kind: f.kind, fields: f.fields.map((q) => ({ id: q.id, type: q.type, label: q.label, help: q.help, req: q.req, opts: q.opts })) })),
    companies: live.map((c) => ({ id: c.id, slug: c.slug, sh2: stampHash(c.slug, c.stamp), posts: (c.posts || []).slice(0, 5).map((x) => ({ at: x.at, text: x.text })), name: c.name, category: c.category || "", description: c.description || "", city: c.city || "", address: c.address || "", phone: c.phone || "", email: c.email || "", website: c.website || "", socials: c.socials || {}, deal: c.deal || "", code: c.code || "", featured: !!c.featured, logo: m(c.logo), gallery: (c.gallery || []).map(m), bg: m(c.bg), videos: (c.videos || []).map((v) => ({ id: v.id, title: v.title || "", sec: v.sec || 0, poster: m(v.poster) })) })),
  };
}
let publishing = null;
async function publish() {
  if (publishing) return publishing;
  return (publishing = publishRun()
    .then((r) => (C.publish && C.publish.keyErr && (delete C.publish.keyErr, writeJson(CONF, C)), r))
    .catch((e) => {
      // a key that can't change the repository: say how to fix it, and keep it on the Forms page
      const plain = ghPlain(e, C.publish && C.publish.repo);
      if (!plain) throw e;
      C.publish && ((C.publish.keyErr = plain), writeJson(CONF, C));
      log("Publish refused by GitHub:", e.message);
      throw Object.assign(new Error(plain), { code: 400 });
    })
    .finally(() => (publishing = null)));
}
function publishRun() {
  return (async () => {
    const cfg = C.publish;
    if (!cfg || !cfg.repo || !ghTok()) throw Object.assign(new Error("Set up publishing first (the GitHub key)."), { code: 400 });
    const S = pubLoad(),
      data = pubData(),
      dir = cfg.dir || "public",
      want = new Set();
    for (const c of data.companies) {
      c.logo && want.add(c.logo.slice(6));
      (c.gallery || []).forEach((g) => want.add(g.slice(6)));
      c.bg && want.add(c.bg.slice(6));
      (c.videos || []).forEach((v) => v.poster && want.add(v.poster.slice(6)));
    }
    data.ad && data.ad.img && want.add(data.ad.img.slice(6));
    const ref = await gh("/git/ref/heads/" + cfg.branch),
      base = ref.object.sha,
      commit = await gh("/git/commits/" + base),
      tree = [],
      sent = Object.assign({}, S.published.files);
    for (const f of want) {
      const p = dir + "/media/" + f;
      if (sent[p]) continue;
      const blob = await gh("/git/blobs", { method: "POST", body: { content: fs.readFileSync(path.join(PUBDIR(), f)).toString("base64"), encoding: "base64" }, ms: 600000 });
      tree.push({ path: p, mode: "100644", type: "blob", sha: blob.sha });
      sent[p] = blob.sha;
    }
    tree.push({ path: dir + "/data.json", mode: "100644", type: "blob", content: JSON.stringify(data) });
    const nt = await gh("/git/trees", { method: "POST", body: { base_tree: commit.tree.sha, tree } }),
      nc = await gh("/git/commits", { method: "POST", body: { message: "Workbench: publish Discover", tree: nt.sha, parents: [base] } });
    await gh("/git/refs/heads/" + cfg.branch, { method: "PATCH", body: { sha: nc.sha } });
    S.published = { at: Date.now(), commit: nc.sha, files: sent, companies: data.companies.length, forms: data.forms.length, formU: Object.fromEntries((S.forms || []).filter((f) => f.open).map((f) => [f.id, f.u || f.at || 1])) };
    delete S.inboxMoved;
    writeJson(hubf("public.json"), S);
    pubEvent("publish", "Published to the website", data.companies.length + " companies, " + data.forms.length + " forms");
    log("Published", data.companies.length, "companies");
    return S.published;
  })();
}
// ---- the public inbox (Tailscale Funnel → 127.0.0.1:8771)
function runAll(cmds, args, ms) {
  return new Promise((done) => {
    const list = [].concat(cmds),
      next = (i) => {
        if (i >= list.length) return done({ ok: !1, out: "Tailscale isn't installed or didn't answer." });
        execFile(list[i], args, { timeout: ms || 20000, windowsHide: !0 }, (e, out, err) => (e && e.code === "ENOENT" ? next(i + 1) : done({ ok: !e, out: (String(out || "") + "\n" + String(err || "")).trim() })));
      };
    next(0);
  });
}
const TSCLI = WIN ? ["tailscale", "C:\\Program Files\\Tailscale\\tailscale.exe"] : ["tailscale"];
async function inboxSet(on) {
  const port = C.inboxPort || 8771,
    r = await runAll(TSCLI, on ? ["funnel", "--bg", "--https=8443", "http://127.0.0.1:" + port] : ["funnel", "--https=8443", "off"]);
  let host = "";
  if (on) {
    try {
      host = String(JSON.parse((await runAll(TSCLI, ["status", "--json"], 8000)).out).Self.DNSName || "").replace(/\.$/, "");
    } catch {}
  }
  C.inbox = !!(on && r.ok);
  C.inboxUrl = C.inbox && host ? "https://" + host + ":8443" : "";
  writeJson(CONF, C);
  log("Inbox", C.inbox ? "on at " + C.inboxUrl : "off");
  return { on: C.inbox, url: C.inboxUrl, out: r.out.slice(0, 600) };
}
// ---- 1.9.0: keep the inbox alive (visitor counts, forms, messages all arrive through it) ----------------
// Every 10 minutes: does Tailscale still give this rig the address the website was told? Does the inbox
// answer from outside? If the Funnel was switched off (an update, a restart) it is switched on again.
// A moved address is picked up and the website is marked as needing a publish; an inbox that stays
// silent is shown on Rig Start. (Tests point WB_INBOX_SELF at the local inbox instead of the public one.)
const IBH = { at: 0, ok: null, msg: "" };
async function inboxProbe() {
  const base = process.env.WB_INBOX_SELF || C.inboxUrl;
  try {
    const r = await fetch(base.replace(/\/+$/, "") + "/ping", { signal: AbortSignal.timeout(7000), cache: "no-store" });
    return r.ok;
  } catch {
    return !1;
  }
}
async function inboxWatch() {
  if (!C.inbox) return void Object.assign(IBH, { at: Date.now(), ok: null, msg: "" });
  let host = "";
  try {
    host = String(JSON.parse((await runAll(TSCLI, ["status", "--json"], 8000)).out).Self.DNSName || "").replace(/\.$/, "");
  } catch {}
  const url = host ? "https://" + host + ":8443" : "";
  if (url && url !== C.inboxUrl) {
    log("Inbox address changed; the website needs a publish");
    C.inboxUrl = url;
    writeJson(CONF, C);
    const S = pubLoad();
    S.inboxMoved = !0;
    pubSave();
    pubEvent("publish", "The rig's address changed", "Publish so visitor counts and forms reach the rig again.");
  }
  let ok = await inboxProbe();
  if (!ok) {
    await runAll(TSCLI, ["funnel", "--bg", "--https=8443", "http://127.0.0.1:" + (C.inboxPort || 8771)]);
    ok = await inboxProbe();
  }
  const was = IBH.ok;
  Object.assign(IBH, { at: Date.now(), ok, msg: ok ? "" : "The inbox doesn't answer from the internet. Visitor counts and forms are paused. Check that Tailscale is running on the rig." });
  if (was !== !1 && !ok) pubEvent("note", "The inbox isn't answering", IBH.msg);
  if (was === !1 && ok) pubEvent("note", "The inbox is back", "Visitor counts and forms are coming through again.");
}
// ---- 1.12.0: Google accounts: people's progress kept on the rig ------------------------------------
// Someone signs in with Google on the website; Google proves who they are (a signed ID token the rig checks
// against Google's public keys) and the rig keeps their Workbench progress: profile, settings, scores and
// notes, never Block World worlds (those stay on their device). One file per person, 5 MB at most, plus the
// version before the last save. People are known by Google's permanent id, not their email.
const GCERTS = process.env.WB_GOOGLE_CERTS || "https://www.googleapis.com/oauth2/v3/certs";
const ACCT_MAX = 5e6; // the most a request may carry; what one person may keep is set below
// (1.16.0) storage stays small on purpose: saves are compressed on disk, one person keeps 1 MB by default (the owner
// can change it, up to 5 MB), and all accounts together stop at a total the owner sets (5 GB by default). When the
// total is reached people still sign in; their progress just stays on their own device until there is room.
const acctMaxEach = () => Math.max(50e3, Math.min(ACCT_MAX, +(C.google && C.google.maxEach) || 1e6));
const acctMaxTotal = () => Math.max(50e6, +(C.google && C.google.maxTotal) || 5e9);
const acctUsed = () => acctIndex().list.reduce((a, x) => a + (x.disk || x.size || 0) + (x.prevDisk || 0), 0);
function acctRead(f, dflt) {
  try {
    const b = fs.readFileSync(f);
    return JSON.parse((b[0] === 0x1f && b[1] === 0x8b ? zlib.gunzipSync(b) : b).toString("utf8"));
  } catch {
    return dflt;
  }
}
function acctWrite(f, o) {
  const z = zlib.gzipSync(Buffer.from(JSON.stringify(o), "utf8"), { level: 9 });
  fs.mkdirSync(path.dirname(f), { recursive: !0 });
  fs.writeFileSync(f, z);
  return z.length;
}
let acctWarnAt = 0,
  acctFullAt = 0;
let gKeys = { at: 0, keys: [] };
async function googleKeys(force) {
  if (!force && Date.now() - gKeys.at < 3600000 && gKeys.keys.length) return gKeys.keys;
  let r;
  try {
    r = await fetch(GCERTS, { signal: AbortSignal.timeout(8000) });
  } catch {}
  if (!r || !r.ok) throw Object.assign(new Error("Google didn't answer. Try again in a minute."), { code: 502 });
  gKeys = { at: Date.now(), keys: (await r.json()).keys || [] };
  return gKeys.keys;
}
const b64u = (s) => Buffer.from(String(s).replace(/-/g, "+").replace(/_/g, "/"), "base64");
async function googleVerify(tok) {
  const id = C.google && C.google.clientId,
    no = (m) => Object.assign(new Error(m || "That sign-in didn't work. Try again."), { code: 401 });
  if (!id) throw Object.assign(new Error("Google sign-in isn't switched on for this rig yet."), { code: 400 });
  const parts = String(tok || "").split(".");
  if (parts.length !== 3 || String(tok).length > 4096) throw no();
  let h, p;
  try {
    h = JSON.parse(b64u(parts[0]).toString("utf8"));
    p = JSON.parse(b64u(parts[1]).toString("utf8"));
  } catch {
    throw no();
  }
  if (h.alg !== "RS256" || !h.kid) throw no();
  let k = (await googleKeys()).find((x) => x.kid === h.kid);
  k || (k = (await googleKeys(!0)).find((x) => x.kid === h.kid));
  if (!k) throw no();
  let ok = !1;
  try {
    ok = crypto.verify("RSA-SHA256", Buffer.from(parts[0] + "." + parts[1]), crypto.createPublicKey({ key: k, format: "jwk" }), b64u(parts[2]));
  } catch {}
  if (!ok) throw no();
  if (!["accounts.google.com", "https://accounts.google.com"].includes(p.iss) || p.aud !== id || !(p.exp * 1000 > Date.now() - 60000) || !p.sub) throw no("That sign-in has run out or isn't for this site. Try again.");
  if (p.email_verified === !1) throw no("That Google account's email isn't verified yet.");
  return { sub: String(p.sub), email: clip(p.email, 200), name: clip(p.name || p.given_name || "", 80) };
}
const acctId = (sub) => sha("google:" + sub).slice(0, 32);
const acctFile = (id, prev) => path.join(hubf("accounts"), id + (prev ? ".prev" : "") + ".json");
// (1.16.0) the list of accounts is kept in memory and written to disk a moment after a change, so thousands of
// people saving does not mean reading and writing the whole list each time
let ACCT_I = null,
  acctIT = null;
const acctIndex = () => (ACCT_I ||= readJson(hubf("accounts.json"), { list: [] }));
const acctIdxFlush = () => (clearTimeout(acctIT), (acctIT = null), ACCT_I && writeJson(hubf("accounts.json"), ACCT_I));
const acctIdxSave = () => acctIT || (acctIT = setTimeout(acctIdxFlush, 2500));
process.on("exit", () => acctIT && acctIdxFlush());
function acctKey() {
  if (!C.acctKey) ((C.acctKey = crypto.randomBytes(32).toString("hex")), writeJson(CONF, C));
  return C.acctKey;
}
const acctSig = (body) => crypto.createHmac("sha256", acctKey()).update(body).digest("base64url");
const acctTok = (id) => {
  const body = id + "." + (Date.now() + 60 * 864e5);
  return "a1." + body + "." + acctSig(body);
};
function acctCheck(t) {
  const m = /^a1\.([0-9a-f]{32})\.(\d{13})\.([A-Za-z0-9_-]{43})$/.exec(String(t || ""));
  if (!m || +m[2] < Date.now()) return null;
  const a = Buffer.from(acctSig(m[1] + "." + m[2])),
    b = Buffer.from(m[3]);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  return fs.existsSync(acctFile(m[1])) ? m[1] : null;
}
function acctIndexPut(A) {
  const I = acctIndex(),
    i = I.list.findIndex((x) => x.id === A.id),
    old = i < 0 ? {} : I.list[i],
    // (1.23.0) how many times someone signed in with Google, and the total time they had Workbench open while signed in
    e = { id: A.id, email: A.email, name: A.name, created: A.created, seen: A.seen, size: A.size || 0, disk: A.disk || 0, prevDisk: A.prevDisk || 0, signins: old.signins || 0, runSec: old.runSec || 0 };
  i < 0 ? I.list.push(e) : (I.list[i] = e);
  acctIdxSave();
}
function acctStat(id, fn) {
  const e = acctIndex().list.find((x) => x.id === id);
  if (e) (fn(e), acctIdxSave());
  return e;
}
const acctPingAt = new Map();
// Block World worlds never come here, even if a device sends them
const acctClean = (st) => Object.fromEntries(Object.entries(st || {}).filter(([k, v]) => typeof v === "string" && /^(wb[-_]|stark_)/.test(k) && !/world|^wb-bw/i.test(k)));
const acctView = (A) => ({ account: { email: A.email, name: A.name, created: A.created }, rev: A.rev || "", save: A.save || null, size: A.size || 0, limit: acctMaxEach() });
const acctHits = new Map();
function acctLimit(req, n) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim() + "|" + n,
    now = Date.now(),
    a = (acctHits.get(ip) || []).filter((t) => now - t < 3600000);
  if (a.length >= n) throw Object.assign(new Error("Too many in a short time. Try again later."), { code: 429 });
  a.push(now);
  acctHits.set(ip, a);
  acctHits.size > 5000 && acctHits.clear();
}
// ---- (1.34.0) business sign-in: a company's own page on Workbench ---------------------------------------------------------------
// A business signs in with the same Google sign-in as everyone, applies once (you approve it on the Rig tab), and then sees only its own
// numbers, edits its own card (every edit waits for your approval), and can ask for a week as company of the week (paid by check or by
// the arrangement you write; it counts once you mark it paid). Nothing here shows one business another's numbers.
const monOf = (t) => { const d = new Date(t); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return dayKey(d.getTime() + 1); };
const weekEnd = (from) => dayKey(new Date(from + "T12:00:00").getTime() + 6 * 864e5);
const weekNow = (S) => (S.weeks || []).find((w) => w.status === "paid" && w.from === monOf(Date.now()));
function bizWho(b) {
  const id = acctCheck(b && b.token);
  if (!id) throw Object.assign(new Error("Sign in with Google again."), { code: 401 });
  const A = acctRead(acctFile(id), null);
  if (!A || !A.email) throw Object.assign(new Error("Sign in with Google again."), { code: 401 });
  return { id, email: String(A.email).toLowerCase(), name: A.name || "" };
}
const bizCo = (S, email) => S.companies.find((c) => (c.owners || []).includes(email));
function bizClean(b) {
  const o = {};
  for (const [k, n] of [["name", 80], ["category", 40], ["description", 1500], ["city", 80], ["address", 160], ["phone", 40], ["email", 120], ["deal", 200], ["code", 40]]) k in b && (o[k] = clip(b[k], n).trim());
  "website" in b && (o.website = webUrl(b.website) || "");
  "socials" in b && (o.socials = socialsOf(b.socials));
  return o;
}
function trfOpens(days) {
  const T = trfLoad(), from = dayKey(Date.now() - (days - 1) * 864e5);
  let n = 0;
  for (const [k, d] of Object.entries(T.days)) k >= from && (n += d.open || 0);
  return n;
}
// (1.36.0) prices ($ per week, set by the owner) and the ad of the week
const bizPrices = (S) => ({ week: Math.max(0, Math.min(9999, +(S.prices && S.prices.week) || 5)), ad: Math.max(0, Math.min(9999, +(S.prices && S.prices.ad) || 15)) });
const adNow = (S) => (S.ads || []).find((w) => w.status === "paid" && w.from === monOf(Date.now()));
function bizWeeks(S, slug, list) {
  const out = [], now = Date.now();
  for (let i = 0; i < 10; i++) {
    const from = monOf(now + i * 7 * 864e5 + 3600e3),
      all = (list || S.weeks || []).filter((w) => w.from === from && w.status !== "no"),
      paid = all.find((w) => w.status === "paid"),
      mine = all.find((w) => w.slug === slug);
    out.push({ from, until: weekEnd(from), state: paid ? (paid.slug === slug ? "mine" : "taken") : mine ? "asked" : "free", ref: mine && mine.status === "new" ? mine.ref : "" });
  }
  return out;
}
// ---- (1.35.0) business media: pictures and a short loop (published with the site) and videos (kept on the rig, streamed from here) ----
// Videos are up to 300 MB and 20 minutes each, three per business, uploaded straight to the rig and played only when someone presses play.
// A file is only ever reachable by its long random name; the website learns the names of approved ones when it is published.
const BIZMEDIA = () => path.join(C.root, ".hub", "biz-media");
let bizStreams = 0;
function mp4Sec(f) {
  try {
    const fd = fs.openSync(f, "r"), st = fs.fstatSync(fd), b = Buffer.alloc(16);
    let pos = 0;
    while (pos + 8 <= st.size) {
      fs.readSync(fd, b, 0, 16, pos);
      let size = b.readUInt32BE(0), hdr = 8;
      const type = b.toString("latin1", 4, 8);
      if (size === 1) { size = Number(b.readBigUInt64BE(8)); hdr = 16; } else if (size === 0) size = st.size - pos;
      if (size < hdr) break;
      if (type === "moov") {
        const len = Math.min(size, 8e6), mb = Buffer.alloc(len);
        fs.readSync(fd, mb, 0, len, pos);
        const i = mb.indexOf("mvhd");
        fs.closeSync(fd);
        if (i < 0) return null;
        const v = mb[i + 4], p = i + 8 + (v === 1 ? 16 : 8), ts = mb.readUInt32BE(p), dur = v === 1 ? Number(mb.readBigUInt64BE(p + 4)) : mb.readUInt32BE(p + 4);
        return ts ? dur / ts : null;
      }
      pos += size;
    }
    fs.closeSync(fd);
  } catch {}
  return null;
}
async function receiveCap(req, dest, max) {
  await fsp.mkdir(path.dirname(dest), { recursive: !0 });
  const tmp = dest + ".part";
  let n = 0;
  await new Promise((ok, bad) => {
    const w = fs.createWriteStream(tmp);
    req.on("data", (c) => { n += c.length; if (n > max) { req.destroy(); w.destroy(); bad(Object.assign(new Error("That file is too big."), { code: 413 })); } });
    req.pipe(w);
    w.on("finish", ok);
    w.on("error", bad);
    req.on("aborted", () => (w.destroy(), bad(new Error("The upload stopped."))));
    req.on("error", bad);
  }).catch(async (e) => { await fsp.rm(tmp, { force: !0 }); throw e; });
  await fsp.rename(tmp, dest);
  return n;
}
async function bizUp(req, res, url) {
  acctLimit(req, 60);
  const who = bizWho({ token: url.searchParams.get("token") }), S = pubLoad(), co = bizCo(S, who.email);
  if (!co) return fail(res, 403, "This Google account isn't a business on Workbench.");
  const kind = url.searchParams.get("kind") === "bg" ? "bg" : "video", ct = String(req.headers["content-type"] || ""), ext = /webm/.test(ct) ? "webm" : /mp4|quicktime|m4v/.test(ct) ? "mp4" : "",
    max = kind === "bg" ? 3.2e6 : 300e6, len = +req.headers["content-length"];
  if (!ext) return fail(res, 400, "Send an MP4 or WebM video.");
  if (!(len > 0) || len > max) return fail(res, 413, kind === "bg" ? "The background loop can be up to 3 MB." : "Videos can be up to 300 MB.");
  const up = (S.bizUp = S.bizUp || {}), vids = Object.entries(up).filter(([, x]) => x.slug === co.slug && x.kind === "video" && !(co.videos || []).some((v) => v.id === x.id));
  if (kind === "video" && vids.length + (co.videos || []).length >= 6) return fail(res, 400, "Remove a video or send your changes for approval before uploading another.");
  const id = crypto.randomBytes(12).toString("hex"), tmpf = path.join(BIZMEDIA(), id + "." + ext);
  const size = await receiveCap(req, tmpf, max);
  const head = Buffer.alloc(12), fd = fs.openSync(tmpf, "r");
  fs.readSync(fd, head, 0, 12, 0);
  fs.closeSync(fd);
  const isMp4 = head.toString("latin1", 4, 8) === "ftyp", isWebm = head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3;
  if (!(ext === "mp4" ? isMp4 : isWebm)) { await fsp.rm(tmpf, { force: !0 }); return fail(res, 400, "That doesn't look like a " + ext.toUpperCase() + " video."); }
  const sec = ext === "mp4" ? mp4Sec(tmpf) : null;
  if (sec && sec > (kind === "bg" ? 9 : 1205)) { await fsp.rm(tmpf, { force: !0 }); return fail(res, 400, kind === "bg" ? "The background loop can be up to 8 seconds." : "Videos can be up to 20 minutes."); }
  if (kind === "bg") {
    const file = sha(fs.readFileSync(tmpf)).slice(0, 16) + "." + ext;
    fs.mkdirSync(PUBDIR(), { recursive: !0 });
    await fsp.rename(tmpf, path.join(PUBDIR(), file));
    up[file] = { slug: co.slug, kind: "bg", at: Date.now() };
    pubSave();
    return json(res, 200, { file });
  }
  up[id] = { slug: co.slug, kind: "video", at: Date.now(), ext, sec: sec ? Math.round(sec) : 0, size, id };
  pubSave();
  return json(res, 200, { id, sec: sec ? Math.round(sec) : 0, size });
}
// the pictures and loops by their file name, the videos by their id (with Range, so they can be played and skipped through)
function bizServe(req, res, url) {
  const name = url.pathname.split("/").pop(), vid = url.pathname.startsWith("/v/"), S = pubLoad();
  let f, type;
  if (vid) {
    if (!/^[0-9a-f]{24}$/.test(name)) return fail(res, 404, "Not here.");
    const v = (S.bizUp || {})[name] || S.companies.flatMap((c) => c.videos || []).find((x) => x.id === name);
    if (!v) return fail(res, 404, "Not here.");
    f = path.join(BIZMEDIA(), name + "." + (v.ext === "webm" ? "webm" : "mp4"));
    type = v.ext === "webm" ? "video/webm" : "video/mp4";
    if (bizStreams >= 8) return fail(res, 503, "Busy right now. Try again in a minute.");
  } else {
    const m = /^([0-9a-f]{16})\.(png|jpg|webp|mp4|webm)$/.exec(name);
    if (!m) return fail(res, 404, "Not here.");
    f = path.join(PUBDIR(), name);
    type = { png: "image/png", jpg: "image/jpeg", webp: "image/webp", mp4: "video/mp4", webm: "video/webm" }[m[2]];
  }
  let st;
  try { st = fs.statSync(f); } catch { return fail(res, 404, "Not here."); }
  const hd = { "Content-Type": type, "Accept-Ranges": "bytes", "Cache-Control": "public, max-age=86400" };
  let a = 0, z = st.size - 1;
  const r = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || "");
  if (r && (r[1] || r[2])) {
    if (r[1]) { a = +r[1]; r[2] && (z = Math.min(z, +r[2])); } else a = Math.max(0, st.size - +r[2]);
    if (a > z || a >= st.size) { res.writeHead(416, { "Content-Range": "bytes */" + st.size }); return res.end(); }
    res.writeHead(206, Object.assign(hd, { "Content-Range": "bytes " + a + "-" + z + "/" + st.size, "Content-Length": z - a + 1 }));
  } else res.writeHead(200, Object.assign(hd, { "Content-Length": st.size }));
  if (req.method === "HEAD") return res.end();
  vid && bizStreams++;
  const rs = fs.createReadStream(f, { start: a, end: z });
  let done = !1;
  const end = () => { if (!done) { done = !0; vid && bizStreams--; rs.destroy(); } };
  rs.pipe(res);
  res.on("close", end);
  rs.on("error", end);
  rs.on("end", end);
}
// (1.38.0) what a company's Business Workbench shows; also used for the owner's preview of it
function bizMeOf(S, co, email) {
  const ed = (S.bizEdits || []).find((x) => x.slug === co.slug) || null,
    sup = S.support || {};
  return {
        state: "company", email,
        company: { slug: co.slug, name: co.name, category: co.category || "", description: co.description || "", city: co.city || "", address: co.address || "", phone: co.phone || "", email: co.email || "", website: co.website || "", socials: co.socials || {}, deal: co.deal || "", code: co.code || "", logo: co.logo ? "media/" + co.logo : "", live: co.live !== !1 },
        edit: ed && { at: ed.at, fields: ed.fields, logo: !!ed.logo, media: ed.media || null },
        media: { gallery: co.gallery || [], bg: co.bg || "", videos: co.videos || [] },
        stats: { views7: trfSum("co", co.slug, 7), views30: trfSum("co", co.slug, 30), adViews30: trfSum("adv", co.slug, 30), adClicks30: trfSum("adc", co.slug, 30), msgs30: trfSum("msg", co.slug, 30), stamps30: trfSum("stamp", co.slug, 30), opens30: trfOpens(30) },
        weeks: bizWeeks(S, co.slug), weekInfo: sup.weekInfo || "", week: weekNow(S) && weekNow(S).slug === co.slug,
        ads: bizWeeks(S, co.slug, S.ads), ad: co.ad || null, adEdit: ed && ed.ad ? ed.ad : null, adNow: !!(adNow(S) && adNow(S).slug === co.slug), prices: bizPrices(S),
      };
}
async function bizRoute(req, res, what) {
  acctLimit(req, 240);
  const b = await jsonBody(req, 2.2e6), who = bizWho(b), S = pubLoad(), co = bizCo(S, who.email);
  if (what === "me") {
    if (co) return json(res, 200, bizMeOf(S, co, who.email));
    const app = S.responses.find((r) => r.ownerEmail === who.email && r.status === "new"),
      lk = (S.linkReqs || []).find((x) => x.email === who.email && x.status === "new");
    return json(res, 200, { state: app ? "pending" : lk ? "linkwait" : "none", email: who.email, name: who.name, at: app ? app.at : lk ? lk.at : 0, link: lk ? { name: lk.name, at: lk.at } : null });
  }
  if (what === "link") {
    // (1.37.0) "My business is already listed": linked at once when this Google email is the listing's own email, else the owner approves
    if (co) return fail(res, 400, "This Google account already has a business page.");
    const c2 = S.companies.find((x) => x.slug === String(b.slug || "") && x.live !== !1);
    if (!c2) return fail(res, 404, "Pick your business from the list.");
    if (c2.email && String(c2.email).toLowerCase().trim() === who.email) {
      c2.owners = [...new Set([...(c2.owners || []), who.email])].slice(0, 5);
      pubSave();
      pubEvent("company", c2.name + " linked a Google account", who.email + " signs in for " + c2.name + " (it is the email on the listing).", c2.id);
      return json(res, 200, { ok: !0, state: "company" });
    }
    S.linkReqs = (S.linkReqs || []).filter((x) => !(x.email === who.email && x.status === "new"));
    if (S.linkReqs.filter((x) => x.status === "new").length >= 200) return fail(res, 503, "Too many requests are waiting right now. Try again later.");
    S.linkReqs.unshift({ id: id36(), slug: c2.slug, name: c2.name, email: who.email, who: who.name, note: clip(b.note, 300).trim(), at: Date.now(), status: "new" });
    S.linkReqs.length > 400 && (S.linkReqs.length = 400);
    pubSave();
    pubEvent("form", "Link request: " + c2.name, who.email + " says they run " + c2.name + ". Approve it on Rig Start.", "biz");
    return json(res, 200, { ok: !0, state: "linkwait" });
  }
  if (what === "claim") {
    if (co) return fail(res, 400, "This Google account already has a business page.");
    const bad = (S.claimFails = S.claimFails || {}), now = Date.now(), f = bad[who.id] || { n: 0, at: now };
    if (now - f.at > 36e5) { f.n = 0; f.at = now; }
    if (f.n >= 8) return fail(res, 429, "Too many wrong codes. Try again in an hour, or ask the owner for a new one.");
    const code = String(b.code || "").toUpperCase().replace(/[^A-Z0-9]/g, ""), h = sha("claim:" + code),
      cl = code.length >= 8 && (S.claims || []).find((x) => x.h === h && !x.used && x.exp > now),
      c2 = cl && S.companies.find((x) => x.slug === cl.slug);
    if (!cl || !c2) { f.n++; bad[who.id] = f; pubSave(); return fail(res, 400, "That code isn't right, or it has run out. Ask the owner for a new one."); }
    c2.owners = [...new Set([...(c2.owners || []), who.email])].slice(0, 5);
    cl.used = now; cl.by = who.email;
    delete bad[who.id];
    pubSave();
    pubEvent("company", c2.name + " was claimed", who.email + " used the claim code and now signs in for " + c2.name + ".", c2.id);
    return json(res, 200, { ok: !0, state: "company" });
  }
  if (what === "apply") {
    if (co) return fail(res, 400, "This Google account already has a business page.");
    if (S.responses.some((r) => r.ownerEmail === who.email && r.status === "new")) return fail(res, 400, "Your application is already waiting for approval.");
    if (S.responses.filter((r) => r.status === "new" && r.ownerEmail).length >= 200) return fail(res, 503, "Too many applications are waiting right now. Try again later.");
    const f = bizClean(b.fields || {});
    if (!f.name) return fail(res, 400, "Write the business's name.");
    if (!f.category || !f.city) return fail(res, 400, "Write what kind of business it is and the city.");
    const lab = { name: "Business name", category: "Kind of business", description: "About", city: "City", address: "Address", phone: "Phone", email: "Contact email", website: "Website", deal: "Deal for Workbench visitors", code: "Deal code" }, files = {}, items = [];
    for (const k of Object.keys(lab)) f[k] && items.push({ id: k, label: lab[k], type: k === "description" ? "long" : "short", map: k === "description" ? "description" : k, value: f[k] });
    for (const [k, u] of Object.entries(f.socials || {})) items.push({ id: "s-" + k, label: k, type: "link", map: k, value: u });
    if (b.logo && b.logo.b64) { const file = pubFromB64(b.logo.b64, b.logo.type); file && ((files.logo = file), items.push({ id: "logo", label: "Logo", type: "image", map: "logo", value: file })); }
    S.responses.push({ id: id36(), form: "biz", slug: "company-sign-up", title: "Business application", kind: "company", at: Date.now(), items, files, status: "new", ownerEmail: who.email, ownerName: who.name });
    pubSave();
    pubEvent("form", "Business application: " + f.name, who.email + " asks for a business page. Check it on the Rig tab.", "biz");
    return json(res, 200, { ok: !0, state: "pending" });
  }
  if (!co) return fail(res, 403, "This Google account isn't a business on Workbench.");
  if (what === "save") {
    const f = bizClean(b.fields || {});
    if ("name" in f && !f.name) return fail(res, 400, "The business needs a name.");
    let logo = "";
    if (b.logo && b.logo.b64) { logo = pubFromB64(b.logo.b64, b.logo.type); if (!logo) return fail(res, 400, "Send a PNG, JPG or WEBP picture up to 1.5 MB."); }
    // (1.35.0) pictures, the short background loop and videos: only files this business already has or uploaded itself
    let media = null;
    if (b.media && typeof b.media === "object") {
      const up = S.bizUp || {}, mine = (file, kind) => (kind === "gallery" ? (co.gallery || []).includes(file) : file === co.bg) || (up[file] && up[file].slug === co.slug);
      media = {};
      if (Array.isArray(b.media.gallery)) {
        media.gallery = b.media.gallery.filter((g) => /^[0-9a-f]{16}\.(png|jpg|webp)$/.test(g) && mine(g, "gallery")).slice(0, 10);
      }
      if ("bg" in b.media) media.bg = /^[0-9a-f]{16}\.(mp4|webm)$/.test(b.media.bg || "") && mine(b.media.bg, "bg") ? b.media.bg : "";
      if (Array.isArray(b.media.videos)) {
        const have = (co.videos || []).reduce((o, v) => ((o[v.id] = v), o), {});
        media.videos = b.media.videos.slice(0, 3).map((v) => {
          const id = String((v && v.id) || ""), old = have[id], u = up[id];
          if (!/^[0-9a-f]{24}$/.test(id) || !(old || (u && u.slug === co.slug && u.kind === "video"))) return null;
          const poster = /^[0-9a-f]{16}\.(png|jpg|webp)$/.test((v && v.poster) || "") && (up[v.poster] && up[v.poster].slug === co.slug || (old && old.poster === v.poster)) ? v.poster : (old && old.poster) || "";
          return { id, title: clip(v.title, 80).trim() || (old && old.title) || "Video", sec: (old && old.sec) || (u && u.sec) || Math.min(1205, Math.max(0, Math.round(+v.sec || 0))), ext: (old && old.ext) || (u && u.ext) || "mp4", poster };
        }).filter(Boolean);
      }
    }
    const prevEd = (S.bizEdits || []).find((x) => x.slug === co.slug);
    S.bizEdits = (S.bizEdits || []).filter((x) => x.slug !== co.slug);
    S.bizEdits.push({ id: id36(), slug: co.slug, name: co.name, by: who.email, at: Date.now(), fields: f, logo, media, ad: prevEd && prevEd.ad });
    pubSave();
    pubEvent("form", "Edit to check: " + co.name, "The business changed its card. Check it on the Rig tab, then publish.", "biz");
    return json(res, 200, { ok: !0 });
  }
  if (what === "pic") {
    const up = (S.bizUp = S.bizUp || {});
    if (Object.values(up).filter((x) => x.slug === co.slug && x.kind === "pic").length >= 60) return fail(res, 400, "Too many pictures were uploaded. Send your changes for approval first.");
    const file = pubFromB64(b.b64, b.type);
    if (!file) return fail(res, 400, "Send a PNG, JPG or WEBP picture up to 1.5 MB.");
    up[file] = { slug: co.slug, kind: "pic", at: Date.now() };
    pubSave();
    return json(res, 200, { file });
  }
  if (what === "week" || what === "ad") {
    // one or several weeks at once (paying in advance): they share one reference code, and the owner marks them all paid together
    const key = what === "ad" ? "ads" : "weeks", list = (S[key] = S[key] || []), pr = bizPrices(S)[what === "ad" ? "ad" : "week"],
      asked = [...new Set((Array.isArray(b.weeks) ? b.weeks : [b.week]).map((x) => String(x || "")))].slice(0, 8), cal = bizWeeks(S, co.slug, list);
    if (!asked.length || !asked[0]) return fail(res, 400, "Pick a week.");
    if (what === "ad" && !(co.ad && co.ad.title)) return fail(res, 400, "Write your ad and send it for approval first. Then you can book a week for it.");
    for (const f of asked) {
      const wk = cal.find((w) => w.from === f);
      if (!wk) return fail(res, 400, "Pick one of the weeks shown.");
      if (wk.state === "taken") return fail(res, 400, "The week of " + f + " is already taken.");
      if (wk.state === "mine" || wk.state === "asked") return fail(res, 400, "You already asked for the week of " + f + ".");
    }
    let ref;
    do ref = (what === "ad" ? "A" : "W") + crypto.randomBytes(3).toString("hex").toUpperCase(); while (list.some((w) => w.ref === ref));
    const grp = id36();
    for (const f of asked) list.push({ id: id36(), slug: co.slug, name: co.name, from: f, at: Date.now(), ref, grp, price: pr, status: "new", by: who.email });
    pubSave();
    pubEvent("form", (what === "ad" ? "Ad asked for: " : "Company of the week asked for: ") + co.name, asked.length + " week" + (asked.length > 1 ? "s" : "") + " from " + asked[0] + " · $" + pr * asked.length + " · reference " + ref + ". Mark it paid on the Rig tab once the payment arrives.", "biz");
    return json(res, 200, { ok: !0, ref, total: pr * asked.length, weeks: bizWeeks(S, co.slug), ads: bizWeeks(S, co.slug, S.ads) });
  }
  if (what === "adsave") {
    // the ad itself (headline, short text, picture, button) waits for the owner's approval like every other edit
    const a2 = b.ad || {}, up = S.bizUp || {}, img = /^[0-9a-f]{16}\.(png|jpg|webp)$/.test(a2.img || "") && ((up[a2.img] && up[a2.img].slug === co.slug) || (co.ad && co.ad.img === a2.img)) ? a2.img : "",
      ad = { title: clip(a2.title, 60).trim(), text: clip(a2.text, 140).trim(), btn: clip(a2.btn, 20).trim() || "Visit", link: webUrl(a2.link), img };
    if (!ad.title) return fail(res, 400, "Write a headline for the ad.");
    if (!ad.link) return fail(res, 400, "Add the web address the button opens (it starts with https://).");
    S.bizEdits = S.bizEdits || [];
    let ed = S.bizEdits.find((x) => x.slug === co.slug);
    if (!ed) { ed = { id: id36(), slug: co.slug, name: co.name, by: who.email, at: Date.now(), fields: {}, logo: "", media: null }; S.bizEdits.push(ed); }
    ed.ad = ad; ed.at = Date.now();
    pubSave();
    pubEvent("form", "Ad to check: " + co.name, "The business wrote an ad. Check it on the Rig tab, then publish.", "biz");
    return json(res, 200, { ok: !0 });
  }
  return fail(res, 404, "Not here.");
}
async function acctRoute(req, res, what) {
  if (what === "google") {
    acctLimit(req, 40);
    const b = await jsonBody(req, 8000),
      g = await googleVerify(b.credential),
      id = acctId(g.sub);
    fs.mkdirSync(hubf("accounts"), { recursive: !0 });
    const A = acctRead(acctFile(id), null) || { id, sub: g.sub, created: Date.now(), rev: "", save: null, size: 0 };
    const isNew = !A.seen;
    Object.assign(A, { email: g.email, name: g.name, seen: Date.now() });
    A.disk = acctWrite(acctFile(id), A);
    acctIndexPut(A);
    acctStat(id, (e) => (e.signins = (e.signins || 0) + 1));
    isNew && pubEvent("note", "A new Workbench account", (g.name || "Someone") + " signed in with Google for the first time.");
    return json(res, 200, Object.assign({ token: acctTok(id) }, acctView(A)));
  }
  acctLimit(req, 600);
  const b = await jsonBody(req, ACCT_MAX * 1.3),
    id = acctCheck(b.token);
  if (!id) return fail(res, 401, "Sign in with Google again.");
  if (what === "ping") {
    // the app says "I have been open for about this many seconds since my last ping": added to the account's total time
    const now = Date.now(),
      s = Math.max(0, Math.min(120, Math.round(+b.s || 0)));
    if (now - (acctPingAt.get(id) || 0) < 20000) return json(res, 200, { ok: !0 });
    acctPingAt.set(id, now);
    acctPingAt.size > 5000 && acctPingAt.clear();
    acctStat(id, (e) => ((e.runSec = (e.runSec || 0) + s), (e.seen = now)));
    return json(res, 200, { ok: !0 });
  }
  const A = acctRead(acctFile(id), null);
  if (!A) return fail(res, 401, "Sign in with Google again.");
  if (what === "load") return ((A.seen = Date.now()), (A.disk = acctWrite(acctFile(id), A)), json(res, 200, acctView(A)));
  if (what === "save") {
    if ((b.base || "") !== (A.rev || "")) return json(res, 409, acctView(A));
    if (!b.save || typeof b.save.storage !== "object") return fail(res, 400, "That isn't Workbench progress.");
    const storage = acctClean(b.save.storage),
      text = JSON.stringify(storage);
    const each = acctMaxEach();
    if (text.length > each) return fail(res, 413, "Your progress is bigger than " + (each >= 1e6 ? Math.round(each / 1e5) / 10 + " MB" : Math.round(each / 1e3) + " KB") + ", so it can't be kept on the account. It stays on this device.");
    // the total: the room this person already has is theirs to reuse; a save that would not fit is kept on the device
    const mine = (A.disk || 0) + (A.prevDisk || 0),
      est = zlib.gzipSync(Buffer.from(text, "utf8")).length + 400,
      total = acctUsed() - mine + est * 2;
    if (total > acctMaxTotal()) {
      if (Date.now() - acctFullAt > 36e5) ((acctFullAt = Date.now()), pubEvent("note", "Account storage is full", "The accounts have reached the storage limit you set. People can still sign in; their progress stays on their own device. Raise the limit on the Rig tab (Web page, Google sign-in and accounts) when you have room."));
      return fail(res, 413, "Account storage is full right now, so your progress stays on this device for the moment.");
    }
    A.prevDisk = 0;
    if (A.save) A.prevDisk = acctWrite(acctFile(id, !0), { at: A.saved || 0, storage: A.save.storage });
    Object.assign(A, { save: { storage }, size: text.length, saved: Date.now(), seen: Date.now(), rev: sha(text + "|" + Date.now()).slice(0, 16) });
    A.disk = acctWrite(acctFile(id), A);
    acctIndexPut(A);
    if (acctUsed() > acctMaxTotal() * 0.8 && Date.now() - acctWarnAt > 864e5) ((acctWarnAt = Date.now()), pubEvent("note", "Account storage is 80% full", "The accounts use over 80% of the storage limit you set. Raise the limit on the Rig tab, or let the oldest unused accounts go."));
    return json(res, 200, { rev: A.rev, size: A.size, limit: each });
  }
  if (what === "delete") {
    for (const f of [acctFile(id), acctFile(id, !0)]) await fsp.rm(f, { force: !0 });
    const I = acctIndex();
    I.list = I.list.filter((x) => x.id !== id);
    acctIdxSave();
    return json(res, 200, { ok: !0 });
  }
  return fail(res, 404, "Not here.");
}
const inboxHits = new Map();
function inboxLimit(req) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    a = (inboxHits.get(ip) || []).filter((t) => now - t < 3600000);
  if (a.length >= 6) throw Object.assign(new Error("Too many in a short time. Try again in an hour."), { code: 429 });
  a.push(now);
  inboxHits.set(ip, a);
}
// ---- traffic (1.6.0): anonymous counts the website sends to the inbox: no addresses, no cookies ----
let TRF = null;
const trfLoad = () => (TRF = TRF || readJson(hubf("traffic.json"), { days: {} }));
const dayKey = (t) => new Date((t || Date.now()) - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
let trfT = 0;
function trfHit(kind, slug) {
  const T = trfLoad(),
    d = (T.days[dayKey()] = T.days[dayKey()] || { open: 0, ref: {}, form: {}, co: {}, sent: {}, msg: {}, stamp: {}, trail: {} });
  if (kind === "open") d.open++;
  // (1.17.0) also: which game was opened, clips saved, sign-ins and shares: anonymous counts, the kind and the name only
  else if (["ref", "form", "co", "sent", "msg", "stamp", "trail", "play", "clip", "signin", "share", "adv", "adc"].includes(kind) && /^[a-z0-9-]{1,60}$/.test(slug)) {
    const m = d[kind] || (d[kind] = {});
    if (Object.keys(m).length < 300 || m[slug]) m[slug] = (m[slug] || 0) + 1;
  } else return;
  const keep = Object.keys(T.days).sort().slice(-70);
  for (const k of Object.keys(T.days)) keep.includes(k) || delete T.days[k];
  clearTimeout(trfT);
  trfT = setTimeout(() => writeJson(hubf("traffic.json"), T), 4000);
}
// the last N days of one counter for one company or form
function trfSum(kind, slug, days) {
  const T = trfLoad(),
    from = dayKey(Date.now() - (days - 1) * 864e5);
  let n = 0;
  for (const [k, d] of Object.entries(T.days)) k >= from && (n += (d[kind] && d[kind][slug]) || 0);
  return n;
}
// ---- who is on the website right now (1.26.0) ------------------------------------------------------------------------
// Keyless and anonymous. A visitor's page tells the rig, every half minute while it is open and in view: a random code made for
// that one tab (not kept anywhere, gone when the tab closes), what they are doing (a game or page from a fixed list of names) and
// the Workbench version on their screen. The rig keeps that in memory only, drops a visitor after 75 seconds of silence, and
// learns nothing else: no address, no name, no cookie. The only thing written to disk is the day's highest number.
const LIVE = new Map(),
  liveHits = new Map();
function liveLimit(req) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    a = (liveHits.get(ip) || []).filter((t) => now - t < 3600000);
  if (a.length >= 400) return !1;
  a.push(now);
  liveHits.set(ip, a);
  liveHits.size > 5000 && liveHits.clear();
  return !0;
}
function liveBeat(req, b) {
  const id = String(b.i || "");
  if (!/^[a-z0-9]{8,24}$/.test(id)) return;
  if (b.bye) { const e0 = LIVE.get(id); e0 && sesEnd(e0); return void LIVE.delete(id); }
  if (!liveLimit(req)) return;
  const now = Date.now(),
    a = String(b.a || "").trim(),
    v = String(b.v || "");
  let e = LIVE.get(id);
  if (!e) {
    if (LIVE.size >= 3000) return;
    e = { first: now, since: now, cur: "" };
    LIVE.set(id, e);
  }
  // (1.30.0) the seconds spent on each part, for the day's totals when the visit ends
  e.prev && e.cur && ((e.acts = e.acts || {}), (e.acts[e.cur] = (e.acts[e.cur] || 0) + Math.min(60, (now - e.prev) / 1000)));
  e.prev = now;
  e.last = now;
  e.a = /^[A-Za-z0-9 :·&'-]{1,40}$/.test(a) ? a : "Browsing";
  e.pb = e.pb || 0;
  e.v = /^\d{1,2}\.\d{1,3}\.\d{1,3}$/.test(v) ? v : "";
  e.cur !== e.a && ((e.cur = e.a), (e.since = now));
  const T = trfLoad(),
    d = (T.days[dayKey()] = T.days[dayKey()] || { open: 0, ref: {}, form: {}, co: {}, sent: {}, msg: {}, stamp: {}, trail: {} });
  // (1.31.0) which hours of the day are busy: the seconds people were on (open and in view) added to the hour they fell in, and the
  // most people on at once in that hour. Nothing says who: only totals per hour of the day.
  {
    const hr = new Date(now).getHours(),
      s = (d.ses = d.ses || { n: 0, h: new Array(24).fill(0), d: [], a: {} });
    s.ah = s.ah || new Array(24).fill(0);
    s.pk = s.pk || new Array(24).fill(0);
    s.ah[hr] = (s.ah[hr] || 0) + (e.pb ? Math.min(60, (now - e.pb) / 1000) : 15);
    s.pk[hr] = Math.max(s.pk[hr] || 0, LIVE.size);
    e.pb = now;
    clearTimeout(trfT);
    trfT = setTimeout(() => writeJson(hubf("traffic.json"), T), 4000);
  }
  if (LIVE.size > (d.livePeak || 0)) {
    d.livePeak = LIVE.size;
    clearTimeout(trfT);
    trfT = setTimeout(() => writeJson(hubf("traffic.json"), T), 4000);
  }
}
// ---- (1.30.0) how long Workbench stays open, anonymously ---------------------------------------------------------------
// When a visit ends (the tab closes, or 75 seconds of silence) the rig adds it to that day's totals: the hour it began, how
// long it was open and in view, and the seconds spent in each part (a game, a page). The random code is never written down,
// and nothing else is kept: no address, no name, no device.
function sesEnd(e) {
  if (e.done) return;
  e.done = 1;
  const secs = Math.max(5, Math.round((e.last - e.first) / 1000) + 15),
    T = trfLoad(),
    k = dayKey(e.first),
    d = (T.days[k] = T.days[k] || { open: 0, ref: {}, form: {}, co: {}, sent: {}, msg: {}, stamp: {}, trail: {} }),
    s = (d.ses = d.ses || { n: 0, h: new Array(24).fill(0), d: [], a: {} }),
    hr = new Date(e.first).getHours();
  s.n++;
  s.h[hr] = (s.h[hr] || 0) + 1;
  // (1.31.0) how long visits that began in each hour lasted, for the average stay by hour
  s.hd = s.hd || new Array(24).fill(0);
  s.hd[hr] = (s.hd[hr] || 0) + secs;
  s.d.length < 1500 && s.d.push(secs);
  for (const [a, t] of Object.entries(e.acts || {})) if (Object.keys(s.a).length < 60 || s.a[a]) s.a[a] = Math.round((s.a[a] || 0) + t);
  clearTimeout(trfT);
  trfT = setTimeout(() => writeJson(hubf("traffic.json"), T), 4000);
}
function livePrune() {
  const now = Date.now();
  for (const [k, e] of LIVE) now - e.last > 75000 && (sesEnd(e), LIVE.delete(k));
}
setInterval(livePrune, 30000).unref();
function sesStats() {
  const T = trfLoad(),
    days = [],
    h7 = new Array(24).fill(0),
    busy = new Array(24).fill(0),
    peak = new Array(24).fill(0),
    hd7 = new Array(24).fill(0),
    durs = [],
    acts = {};
  for (let i = 13; i >= 0; i--) {
    const k = dayKey(Date.now() - i * 864e5),
      s = (T.days[k] && T.days[k].ses) || null,
      dd = s ? s.d.slice().sort((a, b) => a - b) : [];
    days.push({ day: k, n: s ? s.n : 0, avg: dd.length ? Math.round(dd.reduce((a, b) => a + b, 0) / dd.length) : 0, med: dd.length ? dd[dd.length >> 1] : 0, total: dd.reduce((a, b) => a + b, 0) });
    if (s && i < 7) {
      s.h.forEach((n, j) => (h7[j] += n || 0));
      (s.ah || []).forEach((n, j) => (busy[j] += n || 0));
      (s.pk || []).forEach((n, j) => (peak[j] = Math.max(peak[j], n || 0)));
      (s.hd || []).forEach((n, j) => (hd7[j] += n || 0));
      durs.push(...s.d);
      for (const [a, t] of Object.entries(s.a || {})) acts[a] = (acts[a] || 0) + t;
    }
  }
  durs.sort((a, b) => a - b);
  const buck = [60, 300, 900, 3600, Infinity].map((lim, i, A) => durs.filter((x) => x <= lim && x > (i ? A[i - 1] : 0)).length);
  return {
    days,
    hours: h7,
    busy: busy.map((n) => Math.round(n / 60)),
    peak,
    stay: h7.map((n, j) => (n ? Math.round(hd7[j] / n) : 0)),
    week: { n: durs.length, avg: durs.length ? Math.round(durs.reduce((a, b) => a + b, 0) / durs.length) : 0, med: durs.length ? durs[durs.length >> 1] : 0, longest: durs.length ? durs[durs.length - 1] : 0, total: durs.reduce((a, b) => a + b, 0), buckets: buck },
    acts: Object.entries(acts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([a, t]) => ({ a, t: Math.round(t) })),
  };
}
function liveStats() {
  const now = Date.now();
  livePrune();
  const by = {},
    ver = {},
    people = [];
  for (const e of LIVE.values()) {
    const g = (by[e.a] = by[e.a] || { a: e.a, n: 0 });
    g.n++;
    ver[e.v || "older"] = (ver[e.v || "older"] || 0) + 1;
    people.push({ a: e.a, secs: Math.round((now - e.first) / 1000), on: Math.round((now - e.since) / 1000) });
  }
  const d = trfLoad().days[dayKey()];
  return { now: LIVE.size, peak: Math.max((d && d.livePeak) || 0, LIVE.size), list: Object.values(by).sort((x, y) => y.n - x.n), versions: ver, people: people.sort((x, y) => y.secs - x.secs).slice(0, 40) };
}
const CODE_TRIES = new Map();
const hitHits = new Map();
function hitLimit(req) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    a = (hitHits.get(ip) || []).filter((t) => now - t < 3600000);
  if (a.length >= 120) return !1;
  a.push(now);
  hitHits.set(ip, a);
  hitHits.size > 5000 && hitHits.clear();
  return !0;
}
// ---- pairing codes (1.6.0): the rig shows a code, the device types it, and it's connected ----
const PAIR = new Map(),
  pairTries = new Map();
const PAIRABC = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
// 1.9.0: a stamp word is 8 letters/digits, and the website holds only a slow, salted scramble of it
// (PBKDF2, 50,000 rounds) so nobody can work the word out from the published file in any useful time.
// Words made before 1.9.0 are 5 long and keep working; only the scramble got stronger.
const newStamp = () => Array.from(crypto.randomBytes(8), (x) => PAIRABC[x % PAIRABC.length]).join("");
const stampMemo = new Map();
const stampHash = (slug, word) => {
  const k = slug + ":" + word;
  if (!stampMemo.has(k)) {
    stampMemo.size > 2000 && stampMemo.clear();
    stampMemo.set(k, crypto.pbkdf2Sync(String(word), "wb-stamp:" + slug, 50000, 16, "sha256").toString("hex"));
  }
  return stampMemo.get(k);
};
function pairNew(b) {
  const owner = U.users.find((x) => x.role === "owner"),
    u = !b.user || b.user === "me" ? owner : U.users.find((x) => x.id === b.user);
  if (!u) throw Object.assign(new Error("Nobody like that on the Hub."), { code: 404 });
  let code;
  do code = Array.from(crypto.randomBytes(6), (x) => PAIRABC[x % PAIRABC.length]).join("");
  while (PAIR.has(code));
  for (const [k, v] of PAIR) v.exp < Date.now() && PAIR.delete(k);
  [...PAIR].length >= 20 && PAIR.delete(PAIR.keys().next().value);
  const exp = Date.now() + 5 * 60000;
  PAIR.set(code, { user: u.id, name: clip(b.name, 40) || "New device", exp });
  log("Pairing code made for", u.name);
  return { code, exp, who: u.name };
}
function pairUse(req, b) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    t = (pairTries.get(ip) || []).filter((x) => now - x < 600000);
  if (t.length >= 8) throw Object.assign(new Error("Too many tries. Wait 10 minutes."), { code: 429 });
  const code = String(b.code || "").toUpperCase().replace(/[^A-Z0-9]/g, ""),
    P = PAIR.get(code);
  if (!P || P.exp < now) {
    t.push(now);
    pairTries.set(ip, t);
    throw Object.assign(new Error("That code isn't right, or it ran out. Ask for a new one on the rig."), { code: 400 });
  }
  PAIR.delete(code);
  const u = U.users.find((x) => x.id === P.user);
  if (!u) throw Object.assign(new Error("That person is gone."), { code: 400 });
  const R = remLoad(),
    dev = clip(b.device, 60) || P.name,
    key = { id: id36(), name: dev, key: "wbk_" + crypto.randomBytes(24).toString("base64url"), at: now, used: now, full: !0, paired: !0 },
    token = crypto.randomBytes(32).toString("base64url"),
    d = { id: id36(), user: u.id, name: dev, tokenHash: sha(token), created: now, seen: now, push: null, notify: !0, via: C.inboxUrl ? C.inboxUrl + "/k/" + key.key : "" };
  if (u.role === "owner") d.remote = { at: now, paired: !0 };
  R.keys.push(key);
  writeJson(hubf("remote.json"), R);
  DV.devices.push(d);
  saveDevices();
  log("Paired:", u.name, "on", dev);
  try {
    pubEvent("device", dev + " paired", u.role === "owner" ? "as a Rig Remote" : "as " + u.name);
  } catch {}
  return { key: key.key, url: C.inboxUrl ? C.inboxUrl + "/k/" + key.key : "", token, user: pub(u), device: { id: d.id, name: d.name }, name: C.name, remote: !!d.remote };
}
// ---- "use from anywhere" (1.5.0): the same Funnel address, plus a key made on the rig, in the path:
// https://rig.<tailnet>.ts.net:8443/k/<key>. The key alone lets a device chat with the AI (no
// Tailscale needed); a key that allows it also lets the device sign in with a name and PIN and use
// the Hub as usual. Without a valid key the door says nothing. It's never "the rig": the rig's own
// settings (folders, people, keys, publishing setup) stay on the rig.
let RMK = null;
const remLoad = () => (RMK = RMK || readJson(hubf("remote.json"), { keys: [] }));
const remBad = new Map(),
  remHits = new Map();
const safeEq = (a, b) => {
  const x = Buffer.from(String(a)),
    y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
function remoteView() {
  const R = remLoad(),
    base = C.inbox && C.inboxUrl ? C.inboxUrl : "",
    owners = new Set(U.users.filter((x) => x.role === "owner").map((x) => x.id));
  return {
    anywhere: { on: !!base, base, keys: R.keys.map((k) => ({ id: k.id, name: k.name, at: k.at, used: k.used || 0, full: !!k.full, url: base ? base + "/k/" + k.key : "" })) },
    remotes: DV.devices.filter((d) => owners.has(d.user) && (d.remote || d.pairReq)).map((d) => ({ id: d.id, name: d.name, seen: d.seen || 0, remote: !!d.remote, at: d.remote ? d.remote.at : 0, pairReq: d.pairReq || 0 })),
  };
}
async function remoteDoor(req, res, key, rest, url) {
  cors(req, res);
  if (req.method === "OPTIONS") return (res.writeHead(204), res.end());
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    bad = (remBad.get(ip) || []).filter((t) => now - t < 3600000);
  if (bad.length >= 20) return fail(res, 429, "Too many wrong keys. Try again in an hour.");
  const R = remLoad(),
    k = R.keys.find((x) => safeEq(x.key, key));
  if (!k) return (bad.push(now), remBad.set(ip, bad), fail(res, 404, "That key isn't on this Hub. It may have been removed on the rig."));
  const h = (remHits.get(k.id) || []).filter((t) => now - t < 60000);
  if (h.length >= 900) return fail(res, 429, "Slow down a little and try again.");
  h.push(now);
  remHits.set(k.id, h);
  now - (k.used || 0) > 60000 && ((k.used = now), writeJson(hubf("remote.json"), R));
  req.wbRemote = !0;
  req.wbKey = k;
  req.url = rest + url.search;
  if (rest === "/ollama" || rest.startsWith("/ollama/")) {
    // the AI, with the key alone: chatting, and the list of models
    if (!/^\/api\/(chat|generate|tags|show|version|ps)$/.test(rest.slice(7) || "/")) return fail(res, 404, "Not here.");
    return proxyOllama(req, res, new URL(req.url, "http://hub"));
  }
  if (rest === "/ping" || rest === "/api/ping") return json(res, 200, { ok: !0, hub: "Workbench Hub", version: VERSION, name: C.name, anywhere: !0, full: !!k.full, time: Date.now() });
  if (!k.full) return fail(res, 403, "This key is only for the AI. On the rig, make a key that can also sign in.");
  if (rest === "/" || rest === "/index.html") return fail(res, 404, "Not here.");
  return route(req, res);
}
async function inboxRoute(req, res) {
  const url = new URL(req.url, "http://inbox"),
    o = req.headers.origin && allowOrigin(req.headers.origin),
    RD = /^\/k\/(wbk_[A-Za-z0-9_-]{20,80})(\/.*)?$/.exec(url.pathname);
  if (RD) return remoteDoor(req, res, RD[1], RD[2] || "/", url);
  const GD = /^\/g\/(wbg_[A-Za-z0-9_-]{20,80})(\/.*)?$/.exec(url.pathname);
  if (GD) return guestDoor(req, res, GD[1], GD[2] || "/", url);
  const PD = /^\/p(\/state|\/join|\/browser\/[a-z]+)$/.exec(url.pathname);
  if (PD) return pubDoor(req, res, PD[1], url);
  res.setHeader("Vary", "Origin");
  if (o) (res.setHeader("Access-Control-Allow-Origin", o), res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS"), res.setHeader("Access-Control-Allow-Headers", "Content-Type"));
  if (req.method === "OPTIONS") return (res.writeHead(204), res.end());
  if (url.pathname === "/ping") return json(res, 200, { ok: !0 });
  if (req.method === "POST" && url.pathname === "/live") {
    liveBeat(req, await jsonBody(req, 600));
    return json(res, 200, { ok: !0 });
  }
  if (req.method === "POST" && url.pathname === "/hit") {
    const b = await jsonBody(req, 400);
    hitLimit(req) && trfHit(String(b.k || ""), String(b.s || ""));
    return json(res, 200, { ok: !0 });
  }
  if (req.method === "POST" && url.pathname === "/pair") return json(res, 200, pairUse(req, await jsonBody(req, 2000)));
  if (req.method === "POST" && /^\/acct\/(google|load|save|delete|ping)$/.test(url.pathname)) return acctRoute(req, res, url.pathname.slice(6));
  if (req.method === "POST" && /^\/biz\/(me|apply|claim|link|save|week|ad|adsave|pic)$/.test(url.pathname)) return bizRoute(req, res, url.pathname.slice(5));
  if (req.method === "POST" && url.pathname === "/biz/up") return bizUp(req, res, url);
  if (req.method === "GET" && /^\/(pm|v)\/[0-9a-z.]{16,40}$/.test(url.pathname)) return bizServe(req, res, url);
  if (req.method === "POST" && /^\/chat\/(join|list|send|del)$/.test(url.pathname)) return chatPubRoute(req, res, url.pathname.slice(6));
  if (req.method !== "POST" || !["/apply", "/message", "/form", "/support", "/idea"].includes(url.pathname)) return fail(res, 404, "Not here.");
  const b = await jsonBody(req, 2.2e6),
    S = pubLoad();
  if (b.website2) return json(res, 200, { ok: !0 });
  inboxLimit(req);
  if (url.pathname === "/idea") {
    // (1.37.0) "Want to recommend a game?": anyone, no sign-in; lands in the one inbox on Rig Start
    if ((S.ideas || []).filter((x) => x.status === "new").length >= 300) return fail(res, 503, "Too many ideas are waiting right now. Try again later.");
    const idea = { id: id36(), at: Date.now(), name: clip(b.name, 80).trim(), desc: clip(b.desc, 600).trim(), goal: clip(b.goal, 400).trim(), from: clip(b.from, 120).trim(), status: "new" };
    if (!idea.name) return fail(res, 400, "Give the game a name.");
    if (!idea.desc && !idea.goal) return fail(res, 400, "Say a little about it.");
    (S.ideas ||= []).unshift(idea);
    S.ideas.length > 400 && (S.ideas.length = 400);
    writeJson(hubf("public.json"), S);
    pubNotify("Game idea: " + idea.name, (idea.desc || idea.goal).slice(0, 140), "idea", idea.id, [["done", "Seen"]]);
    return json(res, 200, { ok: !0 });
  }
  if (url.pathname === "/support") {
    // someone says they want to support Workbench (or already did): kept as a pledge until the owner has checked the payment
    if ((S.pledges || []).filter((x) => x.status === "new").length >= 300) return fail(res, 503, "Too many are waiting right now. Try again later.");
    const amt = Math.round(Number(b.amount) * 100) / 100,
      nm = clip(b.name, 60).trim();
    if (!nm) return fail(res, 400, "Write the name to show.");
    if (!(amt > 0) || amt > 1e6) return fail(res, 400, "Write the amount as a number, like 20.");
    const AL = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
    let ref = "";
    do ref = "WB-" + Array.from({ length: 4 }, () => AL[Math.floor(Math.random() * AL.length)]).join("");
    while ((S.pledges || []).some((x) => x.ref === ref) || (S.supporters || []).some((x) => x.ref === ref));
    const pl = { id: id36(), at: Date.now(), ref, name: nm, amount: amt, anon: !!b.anon, contact: clip(b.contact, 160), note: clip(b.note, 400), status: "new" };
    (S.pledges ||= []).unshift(pl);
    S.pledges.length > 400 && (S.pledges.length = 400);
    writeJson(hubf("public.json"), S);
    log("Support pledge:", nm, amt, ref);
    trfHit("sent", "support");
    pubNotify("Supporter to check: " + (pl.anon ? "Anonymous" : nm), "Says " + amt + " · reference " + ref + ". Check your payments, then verify it on the Rig tab.", "support", pl.id, [["done", "Seen"]]);
    return json(res, 200, { ok: !0, ref });
  }
  if (url.pathname === "/form" || url.pathname === "/apply") {
    if (S.responses.filter((r) => r.status === "new").length >= 1000) return fail(res, 503, "Too many answers are waiting right now. Try again later.");
    let f, body = b;
    if (url.pathname === "/form") f = S.forms.find((x) => x.slug === clip(b.form, 60) && x.open);
    else f = null;
    // (1.37.0) a business is listed only through Company sign-in (a Google account), never through a plain form
    if (url.pathname === "/apply" || (f && f.kind === "company")) return fail(res, 400, "To list a business, use Company sign-in on Workbench (it needs a Google account).");
    if (url.pathname !== "/form") {
      // a 6.6 page's "List your company": the same answers, into the company sign-up form
      f = S.forms.find((x) => x.kind === "company" && x.open);
      const A = {},
        Fl = {};
      f &&
        f.fields.forEach((q) => {
          if (q.map === "logo") b.logo && (Fl[q.id] = { b64: b.logo, type: b.logoType });
          else if (["instagram", "tiktok", "facebook"].includes(q.map)) A[q.id] = (b.socials || {})[q.map] || "";
          else if (q.map) A[q.id] = b[q.map] || "";
        });
      body = { answers: A, files: Fl };
    }
    if (!f) return fail(res, 404, "That form isn't open.");
    const r = formAnswer(f, body);
    S.responses.unshift(r);
    S.responses.length > 2000 && (S.responses.length = 2000);
    writeJson(hubf("public.json"), S);
    const who = (r.items.find((x) => x.map === "name") || r.items.find((x) => x.type === "short" && x.value) || {}).value || "Someone";
    log("Form:", f.title, "·", who);
    trfHit("sent", f.slug);
    const bud = (r.items.find((x) => x.map === "budget") || {}).value;
    pubNotify(f.kind === "company" ? "New company sign-up" : "New answer: " + f.title, String(who) + (bud && !/^Basic/.test(bud) ? " · promotion budget: " + bud : ""), "form", r.id, f.kind === "company" ? [["approve", "Approve"], ["decline", "Turn down"]] : [["done", "Done"]]);
    return json(res, 200, { ok: !0 });
  }
  if (S.msgs.length >= 1000) return fail(res, 503, "Messages are full right now. Try again later.");
  const c = S.companies.find((x) => x.slug === clip(b.company, 60) && x.live !== !1),
    m = { id: id36(), at: Date.now(), company: c ? c.slug : "", companyName: c ? c.name : "", name: clip(b.name, 80), contact: clip(b.contact, 160), text: clip(b.text, 2000) };
  if (!c || !m.text || !m.contact) return fail(res, 400, "Write a message and a way to reach you.");
  S.msgs.push(m);
  writeJson(hubf("public.json"), S);
  log("Message for", c.name);
  trfHit("msg", c.slug);
  pubNotify("Message for " + c.name, (m.name ? m.name + ": " : "") + m.text.slice(0, 120), "message", m.id, [["done", "Passed on"]]);
  return json(res, 200, { ok: !0 });
}
// what the owner gets
function pubView(u) {
  const S = pubLoad();
  if (u.role === "owner")
    return Object.assign({}, S, {
      pairs: DV.devices.filter((d) => d.user === u.id && d.pairReq && !d.remote).map((d) => ({ id: d.id, name: d.name, at: d.pairReq })), publish: C.publish ? { repo: C.publish.repo, branch: C.publish.branch, key: !!ghTok(), keyErr: C.publish.keyErr || "" } : null, inbox: { on: !!C.inbox, url: C.inboxUrl || "", ok: IBH.ok, msg: IBH.msg, at: IBH.at, moved: !!S.inboxMoved }, owner: !0, dirty: (S.changedAt || 0) > ((S.published && S.published.at) || 0), events: (S.events || []).slice(0, 40), responses: (S.responses || []).slice(0, 300) });
  return { owner: !1 };
}

// ---- forms: Workbench's own Google Forms (1.4.0) ----------------------------------------------------
// The owner builds forms on the rig (short answer, paragraph, choices, checkboxes, dropdown, email,
// phone, date, number, link, picture). Open forms are published with Discover; people fill them in
// on the website, the answers come through the inbox, and the owner reads them on the Rig tab's
// front page. A company sign-up that's approved becomes its Discover page by itself.
const FTYPES = ["short", "long", "choice", "checks", "select", "email", "phone", "date", "number", "link", "image"];
const FMAPS = ["name", "category", "city", "address", "phone", "email", "website", "instagram", "tiktok", "facebook", "youtube", "whatsapp", "description", "deal", "code", "logo", "contact", "budget"];
const fld = (type, label, req, map, help, opts) => ({ id: id36().slice(-8) + Math.floor(Math.random() * 1e4), type, label, req: !!req, map: map || "", help: help || "", opts: opts || [] });
const BUDGET_Q = { label: "Your budget for promotion (optional, not shown)", help: "Free listing is always fine. Tap the i for what promotion means.", opts: ["Basic free listing only", "Under $50", "$50 to $200", "$200 or more", "Not sure yet, let's talk"] };
function formDefaults() {
  return [
    {
      id: id36(),
      slug: "company-sign-up",
      kind: "company",
      title: "List your company",
      desc: "Tell us about your business. Once it's approved it shows up in Discover, with its own link to send people.",
      open: !1,
      fields: [
        fld("short", "Company name", 1, "name"),
        fld("short", "What you do", 0, "category", "Food, signs, auto, beauty…"),
        fld("short", "City", 0, "city"),
        fld("short", "Address", 0, "address"),
        fld("phone", "Phone", 0, "phone"),
        fld("email", "Email", 0, "email"),
        fld("link", "Website", 0, "website"),
        fld("link", "Instagram", 0, "instagram"),
        fld("link", "TikTok", 0, "tiktok"),
        fld("link", "Facebook", 0, "facebook"),
        fld("long", "About your company", 0, "description"),
        fld("short", "A deal for people from Workbench (optional)", 0, "deal", "10% off your first order"),
        fld("image", "Logo", 0, "logo"),
        fld("select", BUDGET_Q.label, 0, "budget", BUDGET_Q.help, BUDGET_Q.opts),
        fld("short", "How we reach you (not shown)", 1, "contact", "Phone or email"),
      ],
    },
    { id: id36(), slug: "contact", kind: "contact", title: "Contact Workbench", desc: "Write to us. We'll get back to you.", open: !1, fields: [fld("short", "Your name"), fld("short", "How to reach you", 1, "", "Phone or email"), fld("long", "Message", 1)] },
  ];
}
function formSlug(title, id) {
  let s = slugOf(title).slice(0, 36) || "form",
    n = 2,
    t = s;
  while (pubLoad().forms.some((f) => f.slug === t && f.id !== id)) t = s + "-" + n++;
  return t;
}
function formSave(b) {
  const S = pubLoad(),
    old = b.id && S.forms.find((f) => f.id === b.id),
    f = old || { id: id36(), at: Date.now(), open: !1, kind: "custom" },
    title = clip(b.title, 120) || f.title;
  if (!title) throw Object.assign(new Error("A form needs a title."), { code: 400 });
  if (!old || (b.slug && b.slug !== f.slug)) f.slug = formSlug(b.slug || title, f.id);
  f.title = title;
  "desc" in b && (f.desc = clip(b.desc, 1000));
  "open" in b && (f.open = !!b.open);
  "kind" in b && (f.kind = ["company", "contact", "custom"].includes(b.kind) ? b.kind : "custom");
  if ("fields" in b) {
    const F = [].concat(b.fields || []).slice(0, 40);
    f.fields = F.map((x) => ({
      id: /^[\w-]{4,24}$/.test(String(x.id || "")) ? String(x.id) : id36().slice(-8) + Math.floor(Math.random() * 1e4),
      type: FTYPES.includes(x.type) ? x.type : "short",
      label: clip(x.label, 200) || "Question",
      help: clip(x.help, 200),
      req: !!x.req,
      map: f.kind === "company" && FMAPS.includes(x.map) ? x.map : "",
      opts: ["choice", "checks", "select"].includes(x.type) ? [...new Set([].concat(x.opts || []).map((o) => clip(o, 100)).filter(Boolean))].slice(0, 30) : [],
    }));
    if (!f.fields.length) throw Object.assign(new Error("Add at least one question."), { code: 400 });
  }
  f.u = Date.now();
  old || S.forms.push(f);
  pubSave();
  return f;
}
// one person's answers, checked against the form
function formAnswer(f, b) {
  const A = (b && b.answers) || {},
    Fl = (b && b.files) || {},
    items = [],
    files = {};
  for (const q of f.fields) {
    let v = A[q.id],
      bad = (m) => Object.assign(new Error((q.label || "A question") + ": " + m), { code: 400 });
    if (q.type === "image") {
      const x = Fl[q.id];
      if (x && x.b64) {
        const file = pubFromB64(x.b64, x.type);
        if (!file) throw bad("send a PNG, JPG or WEBP picture up to 1.5 MB.");
        files[q.id] = file;
        v = file;
      } else v = "";
    } else if (q.type === "checks") v = [].concat(v || []).map((o) => clip(o, 100)).filter((o) => q.opts.includes(o));
    else {
      v = clip(v, q.type === "long" ? 5000 : 300);
      if (v) {
        if (q.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw bad("that email doesn't look right.");
        if (q.type === "phone" && !/^[+\d(][\d\s().+-]{4,30}$/.test(v)) throw bad("that phone number doesn't look right.");
        if (q.type === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(v)) throw bad("pick a date.");
        if (q.type === "number" && !isFinite(+v)) throw bad("write a number.");
        if (q.type === "link") v = webUrl(/^https?:\/\//i.test(v) ? v : "https://" + v) || "";
        if ((q.type === "choice" || q.type === "select") && !q.opts.includes(v)) throw bad("pick one of the choices.");
      }
    }
    if (q.req && (!v || (Array.isArray(v) && !v.length))) throw bad("this one is needed.");
    items.push({ id: q.id, label: q.label, type: q.type, map: q.map || "", value: v });
  }
  return { id: id36(), form: f.id, slug: f.slug, title: f.title, kind: f.kind, at: Date.now(), items, files, status: "new" };
}
// an approved company sign-up becomes its Discover page
function responseToCompany(r) {
  const m = {};
  for (const it of r.items) it.map && it.value && (m[it.map] = it.value);
  const c = companySave({ name: m.name || r.items.find((x) => x.type === "short" && x.value)?.value || "New company", category: m.category, city: m.city, address: m.address, phone: m.phone, email: m.email, website: m.website, description: m.description, deal: m.deal, code: m.code, socials: { instagram: m.instagram, tiktok: m.tiktok, facebook: m.facebook, youtube: m.youtube, whatsapp: m.whatsapp } });
  m.logo && (c.logo = m.logo);
  c.contact = m.contact || "";
  c.from = "form";
  // (1.34.0) a business that applied while signed in with Google signs in to its page with that same Google account
  r.ownerEmail && (c.owners = [String(r.ownerEmail).toLowerCase()]);
  pubSave();
  return c;
}
// ---- the owner's feed of what happened, and the rig's own pop-ups
const trayQ = [];
let trayN = 0;
function pubEvent(kind, title, body, ref) {
  const S = pubLoad(),
    top = S.events[0];
  // the same thing again within the hour just moves to the top (a phone signing in twice, say)
  if (top && top.kind === kind && top.title === clip(title, 120) && Date.now() - top.at < 3600000 && kind !== "form" && kind !== "message") S.events.shift();
  S.events.unshift({ id: id36(), at: Date.now(), kind, title: clip(title, 120), body: clip(body, 300), ref: ref || "" });
  S.events.length > 300 && (S.events.length = 300);
  writeJson(hubf("public.json"), S);
}
function trayNote(title, body) {
  trayQ.push({ n: ++trayN, title: clip(title, 60), body: clip(body, 200) });
  trayQ.length > 50 && trayQ.shift();
}
// ---- a week of the rig's numbers, every 10 minutes, for the little graphs
let HIS = null;
// the website counter's running total (GoatCounter shows it when "Allow adding visitor counts" is on)
async function goatTotal() {
  if (!goatCode()) return null;
  try {
    const r = await fetch((process.env.WB_GOAT_URL || "https://" + goatCode() + ".goatcounter.com") + "/counter/TOTAL.json", { signal: AbortSignal.timeout(8000) });
    return r.ok ? parseInt(String((await r.json()).count || "").replace(/[^\d]/g, ""), 10) || 0 : null;
  } catch {
    return null;
  }
}
// ---- GoatCounter on Rig Start (1.20.0) -------------------------------------------------------------------------------
// With a read-only API key (GoatCounter → Settings → API, permission "Read statistics") the Hub asks GoatCounter for the
// last 30 days of visitors, the top pages, where people came from and which countries, and keeps the answer for five
// minutes. The key stays in hub.json on the rig; Workbench only ever sees the numbers. Without a key it still shows the
// public all-time counter. The answers are read leniently (GoatCounter has changed field names between versions), and
// whatever could not be read is reported by name instead of hiding the whole card.
const GOAT = { at: 0, busy: !1, data: null };
const goatCode = () => C.goatCode || C.countCode || "";
const goatBase = () => process.env.WB_GOAT_URL || "https://" + goatCode() + ".goatcounter.com";
// q: one set of parameters, or a list to try in turn: a 400 ("bad request") from GoatCounter means it didn't like one of
// them (a 404 is retried the same way, in case an option is what it did not find), so the next, plainer set is tried (down to none
// at all, which GoatCounter answers with its default last week)
async function goatApi(p, q) {
  const sets = Array.isArray(q) ? q : [q || {}];
  let last = null;
  for (let i = 0; i < sets.length; i++) {
    last = await goatCall(p, sets[i]);
    if ((last.status !== 400 && last.status !== 404) || i === sets.length - 1) break;
  }
  return goatResult(p, last);
}
async function goatCall(p, q) {
  const u = new URL(goatBase() + "/api/v0/" + p);
  for (const [k, v] of Object.entries(q || {})) u.searchParams.set(k, v);
  const r = await fetch(u, { headers: { Authorization: "Bearer " + C.goatToken, Accept: "application/json" }, signal: AbortSignal.timeout(15000) });
  return { status: r.status, ok: r.ok, text: await r.text().catch(() => ""), url: u };
}
async function goatResult(p, r) {
  const text = r.text,
    snip = text.replace(/\s+/g, " ").slice(0, 160);
  if (r.status === 401 || r.status === 403) throw new Error("GoatCounter refused the API key (it needs the “Read statistics” permission)" + (snip ? ". It said: " + snip : ""));
  if (r.status === 404) {
    // is there a site with that name at all? (the public counter answers for any real site)
    let exists = !1;
    try {
      exists = (await fetch(goatBase() + "/counter/TOTAL.json", { signal: AbortSignal.timeout(8000) })).status !== 404;
    } catch {}
    throw new Error(exists ? "the site “" + goatCode() + "” exists, but GoatCounter's API answered 404 (page not found) for " + p + ", even with the plainest request (" + r.url.pathname + (r.url.search || "") + "). GoatCounter may be having a problem, or the API key belongs to another site. Try again in a few minutes, and check the key under Settings → API on the right site" + (snip ? ". It said: " + snip.slice(0, 80) : "") : "GoatCounter doesn't know a site called “" + goatCode() + "”. Check the address you see your visitors at: the part before .goatcounter.com is the site code");
  }
  if (!r.ok) throw new Error("GoatCounter answered " + r.status + " for " + p + " (" + (r.url.search || "no options") + ")" + (snip ? ". It said: " + snip : ""));
  try {
    return { j: JSON.parse(text), raw: text };
  } catch {
    throw new Error("GoatCounter's answer wasn't JSON");
  }
}
const gcNum = (o, ...keys) => {
  for (const k of keys) if (o && o[k] != null && o[k] !== "" && !isNaN(+o[k])) return +o[k];
  return 0;
};
// a list of { name, count } from whatever shape came back
function gcRows(j, nameKeys) {
  const arr = Array.isArray(j) ? j : [j && j.stats, j && j.hits, j && j.refs, j && j.rows, j && j.data].find((x) => Array.isArray(x)) || [];
  return arr
    .map((r) => ({ name: String(nameKeys.map((k) => r && r[k]).find((x) => x != null && x !== "") ?? "").slice(0, 80), count: gcNum(r, "count", "count_unique", "visitors", "value", "total") }))
    .filter((r) => r.name)
    .slice(0, 6);
}
async function goatRefresh(force) {
  if (!goatCode() || !C.goatToken || GOAT.busy || (!force && Date.now() - GOAT.at < 300000)) return;
  GOAT.busy = !0;
  const day = (t) => new Date(t).toISOString().slice(0, 10),
    end = new Date(),
    start = new Date(end.getTime() - 29 * 864e5),
    iso = (d) => d.toISOString().replace(/\.\d+Z$/, "Z"),
    range = { start: day(start) + "T00:00:00Z", end: iso(end) },
    qs = [range, { start: range.start }, {}],
    out = { ok: !0, at: Date.now(), days: [], total: 0, pages: [], refs: [], places: [], browsers: [], errs: [], sample: "" };
  const step = async (name, fn) => {
    try {
      await fn();
    } catch (e) {
      out.errs.push(name + ": " + e.message);
    }
  };
  await step("visitors", async () => {
    const { j, raw } = await goatApi("stats/total", [Object.assign({ daily: "true" }, range), range, { start: range.start }, {}]);
    out.sample = raw.slice(0, 500);
    const rows = Array.isArray(j.stats) ? j.stats : [],
      by = {};
    for (const r of rows) {
      const d = String(r.day || r.date || "").slice(0, 10);
      if (!/^\d{4}-\d\d-\d\d$/.test(d)) continue;
      by[d] = (by[d] || 0) + (r.daily != null ? gcNum(r, "daily") : Array.isArray(r.hourly) ? r.hourly.reduce((a, b) => a + (+b || 0), 0) : gcNum(r, "count", "visitors"));
    }
    for (let i = 29; i >= 0; i--) {
      const d = day(end.getTime() - i * 864e5);
      out.days.push({ d, n: by[d] || 0 });
    }
    out.total = gcNum(j, "total", "total_unique", "count") || out.days.reduce((a, b) => a + b.n, 0);
  });
  await step("pages", async () => (out.pages = gcRows((await goatApi("stats/hits", [Object.assign({ limit: "5" }, range), range, { start: range.start }, {}])).j, ["path", "title", "name"])));
  await step("sources", async () => (out.refs = gcRows((await goatApi("stats/toprefs", qs)).j, ["name", "ref", "id"])));
  await step("countries", async () => (out.places = gcRows((await goatApi("stats/locations", qs)).j, ["name", "id", "country"])));
  out.ok = out.days.length > 0;
  GOAT.data = out;
  GOAT.at = Date.now();
  GOAT.busy = !1;
  out.errs.length && log("GoatCounter:", out.errs.join(" · "));
}
function goatView() {
  const d = GOAT.data;
  goatCode() && C.goatToken && Date.now() - GOAT.at >= 300000 && goatRefresh().catch(() => {});
  return { code: goatCode(), custom: !!C.goatCode, hasKey: !!C.goatToken, ready: !!d, busy: GOAT.busy, at: d ? d.at : 0, days: d ? d.days : [], total: d ? d.total : 0, pages: d ? d.pages : [], refs: d ? d.refs : [], places: d ? d.places : [], browsers: d ? d.browsers : [], errs: d ? d.errs : [] };
}
async function histSample() {
  HIS = HIS || readJson(hubf("history.json"), { points: [] });
  try {
    const [cpu, gpu] = await Promise.all([cpuBusy(), gpuInfo()]),
      disks = diskList(),
      hd = disks.find((d) => d.hub) || disks[0],
      g = gpu && gpu[0];
    const visits = await goatTotal();
    HIS.points.push({ t: Date.now(), cpu, ram: Math.round(1000 * (1 - os.freemem() / os.totalmem())) / 10, gpu: g ? g.busy : null, temp: g ? g.temp : null, free: hd ? hd.free : null, online: new Set([...live].map((c) => c.device.id)).size, visits });
    const cut = Date.now() - 7 * 864e5 - 9e5;
    HIS.points = HIS.points.filter((p) => p.t >= cut).slice(-1100);
    writeJson(hubf("history.json"), HIS);
  } catch (e) {
    log("History:", e.message);
  }
}

// ---- 1.11.0: which terms people agreed to, and the rule log (when did someone break something) ----------
// Every "I understand and agree" is kept: who, which device, which version of the terms and of Workbench, when.
// The rule log notes who broke what and when, with the terms version they had agreed to at that moment. The
// rig's browser adds an entry by itself when someone tries to reach a private address; the owner can add more.
let TM = null;
const termsLoad = () => (TM = TM || Object.assign({ acc: [], log: [] }, readJson(hubf("terms.json"), {})));
const termsSave = () => writeJson(hubf("terms.json"), TM);
function termsOf(userId, at) {
  let best = null;
  for (const a of termsLoad().acc) if (a.user === userId && a.at <= at && (!best || a.at > best.at)) best = a;
  return best;
}
function ruleLog(user, what, action, auto) {
  const T = termsLoad(),
    at = Date.now(),
    ac = user && user.id ? termsOf(user.id, at) : null;
  T.log.unshift({ id: id36(), at, user: (user && user.id) || "", name: (user && user.name) || "", what: clip(what, 400), action: ["none", "warned", "removed", "blocked", "ended"].includes(action) ? action : "none", auto: !!auto, terms: ac ? ac.terms : "", termsAt: ac ? ac.at : 0, app: ac ? ac.app : "" });
  T.log.length > 500 && (T.log.length = 500);
  termsSave();
}
// ---- the routes ---------------------------------------------------------------------------------
// ---- the rig's browser (1.8.0): one person at a time, only the public internet ----
let BRW = null;
try {
  BRW = require("./browser.js").create({
    log,
    exe: () => (C.browser && C.browser.exe) || "",
    max: () => (C.browser && C.browser.max) || 5,
    i2p: () => C.browser && C.browser.i2p,
    onVisit: (host, u) => {
      // only the host name is kept (not the page or what was typed): who, when, which site
      const L = readJson(hubf("browser-log.json"), { visits: [] });
      L.visits.unshift({ at: Date.now(), who: u.name, host });
      L.visits.length = Math.min(L.visits.length, 300);
      writeJson(hubf("browser-log.json"), L);
      brCount(host, u);
    },
    onStop: (u, why) => {
      try {
        pubEvent("browser", u.name + " closed the rig's browser", why);
      } catch {}
      // guests and visitors: the minutes used count against the day, and a cool-down starts
      try {
        if (/^[gp]:/.test(u.id)) {
          const t0 = brStartedAt.get(u.id) || Date.now(),
            mins = Math.max(1, Math.round((Date.now() - t0) / 60000)),
            L = brLimits(),
            cd = (u.id[0] === "p" ? L.pub.cooldown : L.guest.cooldown) | 0;
          brStartedAt.delete(u.id);
          cd > 0 && brCool.set(u.id, Date.now() + cd * 60000);
          if (u.id[0] === "p") {
            const X = pbuLoad().users[u.id.slice(2)];
            X && ((X.mins = { [brDayKey()]: ((X.mins || {})[brDayKey()] || 0) + mins }), pbuSave());
          }
        }
      } catch {}
    },
    onBlock: (u) => {
      try {
        ruleLog(u, "Tried to open a private address (the rig, the home network or the tailnet) in the rig's browser. It was refused.", "blocked", !0);
        pubEvent("browser", u.name + " tried to open a private address in the rig's browser", "It was refused, and it's in the rule log.");
      } catch {}
    },
  });
} catch (e) {
  log("The rig's browser isn't available:", e.message);
}
const brOn = () => !!(C.browser && C.browser.on);
// ---- the rig browser's numbers (1.18.0): sites opened and people, per day, for 30 days (names of sites only)
const brDay = (t) => new Date(t || Date.now()).toISOString().slice(0, 10);
function brCount(host, u) {
  try {
    const S = readJson(hubf("browser-stats.json"), { days: {} }),
      k = brDay(),
      d = (S.days[k] = S.days[k] || { sites: 0, people: [], hosts: [] });
    d.sites++;
    !d.people.includes(u.name) && d.people.length < 200 && d.people.push(u.name);
    host && !d.hosts.includes(host) && d.hosts.length < 500 && d.hosts.push(host);
    for (const x of Object.keys(S.days).sort().slice(0, -30)) delete S.days[x];
    writeJson(hubf("browser-stats.json"), S);
  } catch {}
}
function brStats() {
  const S = readJson(hubf("browser-stats.json"), { days: {} }),
    keys = Object.keys(S.days).sort(),
    week = keys.slice(-7),
    today = S.days[brDay()] || { sites: 0, people: [] },
    ppl = new Set(),
    all = BRW && BRW.all ? BRW.all() : [];
  week.forEach((k) => S.days[k].people.forEach((n) => ppl.add(n)));
  const days = [];
  for (let i = 6; i >= 0; i--) days.push((S.days[brDay(Date.now() - i * 864e5)] || { sites: 0 }).sites);
  const G = guestLoad().guests;
  return { on: brOn(), module: !!BRW, usingNow: all.map((x) => x.user.name).join(", "), inUse: all.length, max: BRW && BRW.state ? BRW.state(null).max : 5, sitesToday: today.sites, peopleToday: today.people.length, sitesWeek: days.reduce((a, b) => a + b, 0), peopleWeek: ppl.size, days, guests: G.filter((g) => !g.revoked && g.exp > Date.now()).length, pub: !!brLimits().pub.on, pubPeople: Object.keys(pbuLoad().users).length };
}
// ---- guest codes (1.18.0): someone with no Hub account gets the rig's browser and nothing else.
// The owner makes a code on the rig. It holds the public Funnel address and a secret key, scrambled into one
// string (never the rig's own address). It works only together with the person's Google sign-in on Workbench,
// binds to the first account that uses it, runs out after some days, and can be revoked at any moment.
let GST = null;
const guestLoad = () => (GST = GST || readJson(hubf("guests.json"), { guests: [] })),
  guestSave = () => writeJson(hubf("guests.json"), GST);
const GSESS = new Map(),
  guestBad = new Map();
function guestNew(b) {
  const base = C.inbox && C.inboxUrl ? C.inboxUrl : "";
  if (!base) throw Object.assign(new Error("Switch on “Use from anywhere” first: the code carries that public address."), { code: 409 });
  const days = Math.max(1, Math.min(60, Math.round(+b.days || 7))),
    key = "wbg_" + crypto.randomBytes(24).toString("base64url"),
    g = { id: id36(), name: clip(b.name, 40) || "Guest", kh: sha(key), at: Date.now(), exp: Date.now() + days * 864e5, last: 0, uses: 0, acct: "", acctName: "", ack: 0, revoked: 0 };
  guestLoad().guests.unshift(g);
  GST.guests.length = Math.min(GST.guests.length, 100);
  guestSave();
  log("Guest code made for", g.name);
  return { code: "WBG1-" + Buffer.from(JSON.stringify({ b: base, k: key })).toString("base64url"), guest: guestView(g) };
}
const guestView = (g) => ({ id: g.id, name: g.name, at: g.at, exp: g.exp, last: g.last, uses: g.uses, who: g.acctName || "", bound: !!g.acct, revoked: !!g.revoked, live: !g.revoked && g.exp > Date.now() });
// ---- limits for guests and the public (1.19.0) -----------------------------------------------------------
// Everyone who is not a signed-in Hub person (a guest-code holder, or a visitor in "free browsing for everyone")
// gets the browser under rules: a list of kinds of site that is never opened, no files in or out, a time cap,
// and (if the owner wants) only the sites on the owner's list. The owner can change all of it, and switch the
// public mode off at once.
const BRL_DEF = { guest: { minutes: 60, cooldown: 0, onlyListed: !1 }, pub: { on: !1, minutes: 30, cooldown: 30, daily: 90, onlyListed: !0 }, sites: [] };
function brLimits() {
  const c = (C.browser && C.browser.limits) || {};
  return {
    guest: Object.assign({}, BRL_DEF.guest, c.guest),
    pub: Object.assign({}, BRL_DEF.pub, c.pub),
    sites: Array.isArray(c.sites) ? c.sites.slice(0, 200) : [],
  };
}
const brSites = (L) => L.sites.map((x) => require("./browser.js").normHost(x)).filter(Boolean);
function brPolicy(u) {
  if (!u || u.role !== "guest") return null;
  const L = brLimits(),
    A = u.pub ? L.pub : L.guest;
  return { minutes: Math.max(1, Math.min(240, A.minutes | 0 || 30)), only: A.onlyListed ? brSites(L) : null };
}
let PBU = null;
const pbuLoad = () => (PBU = PBU || readJson(hubf("pub-browser.json"), { users: {} })),
  pbuSave = () => writeJson(hubf("pub-browser.json"), PBU);
const brDayKey = () => new Date().toISOString().slice(0, 10);
const brCool = new Map();
function brLimitsView() {
  const L = brLimits(),
    P = pbuLoad();
  return Object.assign(L, {
    users: Object.entries(P.users)
      .map(([id, x]) => ({ id, name: x.name, uses: x.uses || 0, last: x.last || 0, banned: !!x.banned, today: (x.mins && x.mins[brDayKey()]) || 0 }))
      .sort((a, b) => b.last - a.last)
      .slice(0, 40),
  });
}
// 1.28.0: a person can choose I2P for their own browser session (the owner can switch the choice off); the router has to be running
async function i2pChoice(b) {
  if (!b || !b.i2p) return { i2p: !1 };
  const B = require("./browser.js"),
    c = B.i2pCfg(C.browser && C.browser.i2p);
  if (!c.choice) throw Object.assign(new Error("The owner hasn't allowed choosing I2P."), { code: 403 });
  const pr = await B.i2pProbe(C.browser && C.browser.i2p);
  if (!pr.http || !pr.https) throw Object.assign(new Error("I2P isn't answering on the rig right now, so it can't be used. Try again later, or use the browser without it."), { code: 503 });
  return { i2p: !0 };
}
// the shared part of what a guest (by code) or a visitor (public) can do: the browser, and nothing else
async function guestBrowserApi(req, res, url, P, u, G) {
  const M = req.method,
    st = () => Object.assign(BRW ? BRW.state(u) : { available: !1, active: null }, { ack: !!G.ack(), on: brOn(), can: !0, allowed: brOn(), module: !!BRW, limits: brPolicyView(u), i2p: { on: require("./browser.js").i2pCfg(C.browser && C.browser.i2p).on, choice: require("./browser.js").i2pCfg(C.browser && C.browser.i2p).choice } });
  if (P === "/state") return json(res, 200, st());
  if (P === "/ack" && M === "POST") return (G.setAck(), json(res, 200, st()));
  if (P === "/stop" && M === "POST") return (BRW && BRW.stop("Closed.", u.id), json(res, 200, st()));
  if (!BRW || !brOn()) return fail(res, 403, "The rig's browser isn't available.");
  if (P === "/start" && M === "POST") {
    if (!G.ack()) return fail(res, 409, "Read the notice about the rig's browser first.");
    G.beforeStart && G.beforeStart();
    const b = await jsonBody(req, 500).catch(() => ({})),
      ex = await i2pChoice(b);
    return json(res, 200, await BRW.start(u, C.browser, brPolicy(u), ex));
  }
  if (["/go", "/input", "/resize"].includes(P) && M === "POST") {
    const b = await jsonBody(req, 20000);
    if (P === "/go") await BRW.go(u, b.url);
    else if (P === "/input") await BRW.input(u, b.events);
    else await BRW.resize(u, b.w, b.h);
    return json(res, 200, { ok: !0 });
  }
  if (P === "/frame") {
    const f = await BRW.frame(u, +url.searchParams.get("n") || 0, 20000),
      hd = { "Cache-Control": "no-store", "X-Frame": String(f.n), "X-Url": encodeURIComponent(f.url), "X-Title": encodeURIComponent(f.title), "X-Size": f.w + "x" + f.h, "Access-Control-Expose-Headers": "X-Frame, X-Url, X-Title, X-Size" };
    if (!f.buf) return (res.writeHead(204, hd), res.end());
    res.writeHead(200, Object.assign(hd, { "Content-Type": "image/jpeg", "Content-Length": f.buf.length }));
    return res.end(f.buf);
  }
  return fail(res, 404, "Not here.");
}
function brPolicyView(u) {
  const p = brPolicy(u);
  if (!p) return null;
  const L = brLimits();
  return { minutes: p.minutes, onlyListed: !!p.only, sites: p.only ? p.only : [], files: !1 };
}
// Does the rig's DNS filter out adult sites (like Cloudflare for Families, 1.1.1.3)? Everything a guest opens is looked up
// by this same DNS, so a filtering DNS protects guests with no list at all. Asked with Cloudflare's own test names.
async function dnsCheck() {
  const dnsP = require("dns").promises,
    look = async (h) => {
      try {
        const r = await dnsP.lookup(h, { all: !0 });
        return r.every((x) => /^0+(:0+)*$/.test(x.address)) ? "blocked" : "open";
      } catch (e) {
        return e.code === "ENOTFOUND" ? "blocked" : "error";
      }
    },
    [control, adult, malware] = await Promise.all([look("example.com"), look("nudity.testcategory.com"), look("malware.testcategory.com")]),
    on = control === "open" && adult === "blocked";
  return { control, adult, malware, filtered: on, text: control !== "open" ? "The rig couldn't look anything up just now, so I can't tell." : on ? "On: this rig's DNS refuses Cloudflare's adult test site" + (malware === "blocked" ? " and malware test site." : ".") : "Off: Cloudflare's adult test site opened. Set the rig's DNS to 1.1.1.3 and 1.0.0.3 (Windows → Network settings → DNS) to filter adult and malware sites." };
}
const pubBad = new Map();
// the public door: /p/state (anyone), /p/join (a Workbench Google sign-in), /p/browser/... (a guest session)
async function pubDoor(req, res, rest, url) {
  cors(req, res);
  if (req.method === "OPTIONS") return (res.writeHead(204), res.end());
  const L = brLimits(),
    now = Date.now();
  if (rest === "/state") return json(res, 200, L.pub.on && BRW && brOn() ? { on: !0, minutes: L.pub.minutes, cooldown: L.pub.cooldown, daily: L.pub.daily, onlyListed: !!L.pub.onlyListed, sites: L.pub.onlyListed ? brSites(L) : [], busy: !!(BRW && BRW.state(null).full), i2p: { on: require("./browser.js").i2pCfg(C.browser && C.browser.i2p).on, choice: require("./browser.js").i2pCfg(C.browser && C.browser.i2p).choice } } : { on: !1 });
  if (!L.pub.on || !BRW || !brOn()) return fail(res, 404, "Free browsing isn't on right now.");
  if (rest === "/join") {
    if (req.method !== "POST") return fail(res, 405, "Not here.");
    acctLimit(req, 30);
    const b = await jsonBody(req, 4000),
      id = acctCheck(b.token);
    if (!id) return fail(res, 401, "Sign in with Google on Workbench first.");
    const A = acctRead(acctFile(id), null) || {},
      PU = pbuLoad(),
      X = (PU.users[id] = PU.users[id] || { name: clip(A.name || "Visitor", 60), uses: 0, last: 0, ack: 0, mins: {} });
    if (X.banned) return fail(res, 403, "The owner has turned this account off.");
    X.name = clip(A.name || X.name || "Visitor", 60);
    X.last = now;
    pbuSave();
    const tok = crypto.randomBytes(32).toString("base64url");
    for (const [k, v] of GSESS) v.exp < now && GSESS.delete(k);
    GSESS.set(sha(tok), { pub: id, exp: now + 12 * 3600000 });
    return json(res, 200, { gtoken: tok, name: X.name });
  }
  const h = String(req.headers.authorization || ""),
    S = GSESS.get(sha(h.startsWith("Bearer ") ? h.slice(7).trim() : ""));
  if (!S || !S.pub || S.exp < now) return fail(res, 401, "Join again.");
  const PU = pbuLoad(),
    X = PU.users[S.pub];
  if (!X || X.banned) return fail(res, 403, "The owner has turned this account off.");
  const u = { id: "p:" + S.pub, name: X.name + " (visitor)", role: "guest", pub: !0, browser: !0, brAck: X.ack },
    P = rest.replace(/^\/browser/, "");
  return guestBrowserApi(req, res, url, P, u, {
    ack: () => X.ack,
    setAck: () => ((X.ack = now), pbuSave()),
    beforeStart: () => {
      const cd = brCool.get(u.id) || 0;
      if (cd > Date.now()) throw Object.assign(new Error("Wait " + Math.ceil((cd - Date.now()) / 60000) + " more minute(s) before opening it again."), { code: 429 });
      if (((X.mins || {})[brDayKey()] || 0) >= L.pub.daily) throw Object.assign(new Error("That's today's free time used up. Come back tomorrow."), { code: 429 });
      X.uses++;
      pbuSave();
      brStartedAt.set(u.id, Date.now());
    },
  });
}
const brStartedAt = new Map();
async function guestDoor(req, res, key, rest, url) {
  cors(req, res);
  if (req.method === "OPTIONS") return (res.writeHead(204), res.end());
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    bad = (guestBad.get(ip) || []).filter((t) => now - t < 3600000),
    kh = sha(key),
    g = guestLoad().guests.find((x) => safeEq(x.kh, kh));
  if (bad.length >= 20) return fail(res, 429, "Too many wrong codes. Try again in an hour.");
  if (!g || g.revoked || g.exp < now) return (!g && (bad.push(now), guestBad.set(ip, bad)), fail(res, 404, "That code isn't valid any more. Ask the owner for a new one."));
  if (rest === "/join") {
    if (req.method !== "POST") return fail(res, 405, "Not here.");
    const b = await jsonBody(req, 4000),
      id = acctCheck(b.token);
    if (!id) return fail(res, 401, "Sign in with Google on Workbench first, then use the code.");
    if (g.acct && g.acct !== id) return fail(res, 403, "This code is already linked to another account.");
    const A = acctRead(acctFile(id), null) || {};
    if (!g.acct) ((g.acct = id), (g.acctName = clip(A.name || A.email || "Guest", 60)), log("Guest code linked to", g.acctName));
    g.last = now;
    guestSave();
    const tok = crypto.randomBytes(32).toString("base64url");
    for (const [k, v] of GSESS) v.exp < now && GSESS.delete(k);
    GSESS.set(sha(tok), { gid: g.id, exp: Math.min(g.exp, now + 12 * 3600000) });
    try {
      pubEvent("browser", g.acctName + " joined with a guest code", "“" + g.name + "”: the rig's browser only");
    } catch {}
    return json(res, 200, { gtoken: tok, name: g.acctName, label: g.name, exp: g.exp });
  }
  const h = String(req.headers.authorization || ""),
    S = GSESS.get(sha(h.startsWith("Bearer ") ? h.slice(7).trim() : ""));
  if (!S || S.gid !== g.id || S.exp < now) return fail(res, 401, "Use the code again to reconnect.");
  const u = { id: "g:" + g.id, name: g.acctName + " (guest)", role: "guest", browser: !0, brAck: g.ack },
    P = rest.replace(/^\/browser/, "");
  return guestBrowserApi(req, res, url, P, u, {
    ack: () => g.ack,
    setAck: () => ((g.ack = now), guestSave()),
    beforeStart: () => {
      const L = brLimits().guest,
        cd = brCool.get(u.id) || 0;
      if (cd > Date.now()) throw Object.assign(new Error("Wait " + Math.ceil((cd - Date.now()) / 60000) + " more minute(s) before opening it again."), { code: 429 });
      g.last = now;
      g.uses++;
      guestSave();
    },
  });
}
function brState(u) {
  const st = BRW ? BRW.state(u) : { available: !1, active: null };
  return Object.assign(st, { ack: u.role === "owner" || !!u.brAck, on: brOn(), can: canBrowse(u), allowed: canBrowse(u) && brOn(), module: !!BRW, exe: u.role === "owner" ? (C.browser && C.browser.exe) || "" : undefined, i2p: u.role === "owner" ? require("./browser.js").i2pCfg(C.browser && C.browser.i2p) : { on: require("./browser.js").i2pCfg(C.browser && C.browser.i2p).on, choice: require("./browser.js").i2pCfg(C.browser && C.browser.i2p).choice } });
}
async function route(req, res) {
  const url = new URL(req.url, "http://hub"),
    p = url.pathname,
    M = req.method;
  cors(req, res);
  if (M === "OPTIONS") return (res.writeHead(204), res.end());
  if (p === "/" || p === "/index.html") return statusPage(req, res);
  if (p === "/api/tray") {
    if (!fromRig(req) || req.headers["x-forwarded-for"] || req.headers["x-forwarded-host"] || req.headers.origin) return fail(res, 403, "Only for the Hub's icon on the rig.");
    // the first ask (no "after") only learns where the list is, so old notices don't pop up again
    const after = url.searchParams.get("after");
    return json(res, 200, { last: trayN, notes: after == null ? [] : trayQ.filter((n) => n.n > +after) });
  }
  if (p === "/api/ping") return json(res, 200, { ok: !0, hub: "Workbench Hub", version: VERSION, name: C.name, setup: U.users.length > 0, time: Date.now() });
  if (p === "/api/login" && M === "POST") return json(res, 200, login(await jsonBody(req, 1e4)));
  if (p === "/api/act" && M === "POST") return json(res, 200, actDo(await jsonBody(req, 2e3)));
  const a = auth(req, url);
  if (!a) return fail(res, 401, "Sign in to the Hub again.");
  const u = a.user,
    owner = u.role === "owner";
  if (p.startsWith("/ollama/") || p === "/ollama") return proxyOllama(req, res, url);
  switch (p) {
    case "/api/logout":
      DV.devices = DV.devices.filter((d) => d !== a.device);
      saveDevices();
      return json(res, 200, { ok: !0 });
    case "/api/me": {
      let disk = null;
      try {
        const s = fs.statfsSync(C.root);
        disk = { free: s.bavail * s.bsize, size: s.blocks * s.bsize };
      } catch {}
      const via = String(url.searchParams.get("via") || "");
      // remember which sign-in is the rig's own (a Rig Remote can't sign the rig out by mistake)
      fromRig(req) && !a.device.rig && ((a.device.rig = !0), saveDevicesSoon());
      /^https?:\/\/[^\s"'<>]{3,300}$/.test(via) && via !== a.device.via && ((a.device.via = via.replace(/\/+$/, "")), saveDevicesSoon());
      return json(res, 200, { user: pub(u), device: { id: a.device.id, name: a.device.name, push: !!a.device.push, remote: !!a.device.remote, pairReq: a.device.pairReq || 0 }, hub: { name: C.name, version: VERSION, disk: owner ? disk : null, rig: fromRig(req), anywhere: !!req.wbRemote } });
    }
    case "/api/system/history":
      if (!owner) return fail(res, 403, "Only the owner can see the rig's health.");
      HIS = HIS || readJson(hubf("history.json"), { points: [] });
      return json(res, 200, { points: HIS.points, every: 600 });
    case "/api/system": {
      if (!owner) return fail(res, 403, "Only the owner can see the rig's health.");
      {
        const cc = String(url.searchParams.get("count") || "");
        /^[a-z0-9-]{2,40}$/.test(cc) && cc !== C.countCode && ((C.countCode = cc), writeJson(CONF, C));
      }
      return json(res, 200, Object.assign(await systemInfo(req), { visitsBase: C.visitsBase || 0, visitsBaseAt: C.visitsBaseAt || 0, browser: brStats(), goat: goatView() }));
    }
    case "/api/goat/config": {
      if (!owner) return fail(res, 403, "Only the owner can do that.");
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M !== "POST") return json(res, 200, { hasKey: !!C.goatToken, code: goatCode() });
      const b = await jsonBody(req, 2000);
      if ("code" in b) {
        const c = String(b.code || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\.goatcounter\.com.*$/, "");
        if (c && !/^[a-z0-9-]{2,40}$/.test(c)) return fail(res, 400, "That doesn't look like a GoatCounter site code (the part before .goatcounter.com).");
        C.goatCode = c;
        writeJson(CONF, C);
        GOAT.data = null;
        GOAT.at = 0;
        log("GoatCounter site code", c ? "set to " + c : "back to the website's");
      }
      if ("token" in b) {
        const t = String(b.token || "").trim();
        if (t && !/^[A-Za-z0-9_\-.]{8,200}$/.test(t)) return fail(res, 400, "That doesn't look like a GoatCounter API key.");
        C.goatToken = t;
        writeJson(CONF, C);
        GOAT.data = null;
        GOAT.at = 0;
        log("GoatCounter API key", t ? "saved" : "removed");
      }
      return json(res, 200, { hasKey: !!C.goatToken, code: goatCode() });
    }
    case "/api/goat/test": {
      if (!owner) return fail(res, 403, "Only the owner can do that.");
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M !== "POST") break;
      if (!goatCode()) return fail(res, 400, "The site code isn't known yet: type it in the Site code box, or open Workbench's website once with the visitor counter on.");
      if (!C.goatToken) return fail(res, 400, "Save an API key first.");
      GOAT.busy = !1;
      await goatRefresh(!0);
      const v = goatView();
      return json(res, 200, Object.assign(v, { sample: GOAT.data ? GOAT.data.sample : "" }));
    }
    case "/api/system/visits-base": {
      // 1.10.0: "count from now": the counter's total so far (the owner's own devices were in it) stops showing
      if (!owner) return fail(res, 403, "Only the owner can do that.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const n = await goatTotal();
      if (n == null) return fail(res, 502, "The counter didn't answer. Try again in a minute.");
      C.visitsBase = n;
      C.visitsBaseAt = Date.now();
      writeJson(CONF, C);
      return json(res, 200, { visitsBase: n, visitsBaseAt: C.visitsBaseAt });
    }
    case "/api/system/ai": {
      if (!owner) return fail(res, 403, "Only the owner can do that.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 1e4),
        m = String(b.model || "").slice(0, 200);
      if (!m) return fail(res, 400, "Which model?");
      if (b.do === "default") ((C.aiModel = m), writeJson(CONF, C));
      else await aiKeep(m, b.do === "load");
      log("AI", b.do || "unload", m);
      return json(res, 200, { ok: !0, ai: await aiInfo() });
    }
    // ---- Discover (the owner)
    case "/api/pub":
      if (!owner) return fail(res, 403, "Only the owner.");
      return json(res, 200, pubView(u));
    case "/api/pub/media": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const f = String(url.searchParams.get("f") || "");
      if (!/^[0-9a-f]{16}\.[a-z0-9]+$/.test(f)) return fail(res, 400, "No such file.");
      return sendFile(req, res, path.join(PUBDIR(), f));
    }
    case "/api/pub/company": {
      if (!owner) return fail(res, 403, "Only the owner lists companies.");
      if (M === "DELETE") {
        const S = pubLoad();
        S.companies = S.companies.filter((c) => c.id !== url.searchParams.get("id"));
        pubSave();
        return json(res, 200, pubView(u));
      }
      if (M === "POST") return (companySave(await jsonBody(req, 5e4)), json(res, 200, pubView(u)));
      break;
    }
    case "/api/pub/file": {
      if (M !== "PUT" && M !== "POST") break;
      const forId = url.searchParams.get("for") || "",
        S = pubLoad();
      if (url.searchParams.get("kind") !== "logo") return fail(res, 400, "What kind of file?");
      if (!owner) return fail(res, 403, "That isn't yours to change.");
      const co = S.companies.find((x) => x.id === forId);
      if (!co) return fail(res, 404, "No such company.");
      co.logo = await pubFile(req, url.searchParams.get("name"), "img");
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/app": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const b = await jsonBody(req, 1e4),
        S = pubLoad(),
        a = S.apps.find((x) => x.id === b.id);
      if (!a) return fail(res, 404, "No such application.");
      S.apps = S.apps.filter((x) => x !== a);
      if (b.do === "approve") {
        const c = companySave(Object.assign({}, a, { id: void 0 }));
        ((c.logo = a.logo || ""), (c.contact = a.contact || ""), (c.from = "application"));
      }
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/preview": {
      // what Publish would put on the website right now (the owner can look before sending it)
      if (!owner) return fail(res, 403, "Only the owner.");
      return json(res, 200, pubData());
    }
    case "/api/pub/support": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const b = await jsonBody(req, 4e3),
        S = pubLoad(),
        amt = Math.round(Number(b.amount) * 100) / 100;
      S.supporters ||= [];
      S.pledges ||= [];
      if (b.act === "verify") {
        // a pledge whose payment the owner has seen: it joins the list with the amount the owner confirms (not the one typed)
        const pl = S.pledges.find((x) => x.id === b.id);
        if (!pl) return fail(res, 404, "That one is gone.");
        if (!(amt > 0) || amt > 1e6) return fail(res, 400, "Write the amount you received.");
        S.supporters.push({ id: id36(), at: Date.now(), ref: pl.ref, name: clip(b.name, 60).trim() || pl.name, amount: amt, anon: b.anon !== void 0 ? !!b.anon : !!pl.anon, on: !0 });
        S.pledges = S.pledges.filter((x) => x.id !== b.id);
      } else if (b.act === "fix") {
        // a waiting entry: fix the name or amount before verifying (typos happen)
        const pl = S.pledges.find((x) => x.id === b.id);
        if (!pl) return fail(res, 404, "That one is gone.");
        if (b.name !== void 0 && clip(b.name, 60).trim()) pl.name = clip(b.name, 60).trim();
        if (b.amount !== void 0 && amt > 0 && amt <= 1e6) pl.amount = amt;
        if (b.anon !== void 0) pl.anon = !!b.anon;
      } else if (b.act === "dismiss") S.pledges = S.pledges.filter((x) => x.id !== b.id);
      else if (b.act === "add") {
        if (!clip(b.name, 60).trim() || !(amt > 0) || amt > 1e6) return fail(res, 400, "A name and an amount, please.");
        S.supporters.push({ id: id36(), at: Date.now(), ref: "", name: clip(b.name, 60).trim(), amount: amt, anon: !!b.anon, on: !0 });
      } else if (b.act === "edit") {
        const x = S.supporters.find((y) => y.id === b.id);
        if (!x) return fail(res, 404, "That one is gone.");
        if (b.name !== void 0 && clip(b.name, 60).trim()) x.name = clip(b.name, 60).trim();
        if (b.amount !== void 0 && amt > 0 && amt <= 1e6) x.amount = amt;
        if (b.anon !== void 0) x.anon = !!b.anon;
        if (b.on !== void 0) x.on = !!b.on;
      } else if (b.act === "remove") S.supporters = S.supporters.filter((x) => x.id !== b.id);
      else if (b.act === "settings") {
        // where people can pay: an email, and up to five links (GitHub Sponsors, a tip page...)
        const em = clip(b.email, 120),
          links = (Array.isArray(b.links) ? b.links : []).slice(0, 5).map((l) => ({ label: clip(l && l.label, 40), url: clip(l && l.url, 300) })).filter((l) => l.label && /^https:\/\/[^\s]+$/i.test(l.url));
        if (em && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) return fail(res, 400, "That email doesn't look right.");
        // (1.32.0) one line the owner writes about what Workbench has cost so far; the site shows it beside the logo
        // (1.33.0) the figure (a short text such as $412) and what it means, both written by the owner
        S.support = { email: em, links, cost: clip(b.cost, 24).replace(/\s+/g, " ").trim(), costNote: clip(b.costNote, 320).replace(/\s+/g, " ").trim(), weekInfo: clip(b.weekInfo, 500).trim() };
      } else return fail(res, 400, "Unknown.");
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/msg": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const b = await jsonBody(req, 1e4),
        S = pubLoad();
      S.msgs = S.msgs.filter((x) => x.id !== b.id);
      writeJson(hubf("public.json"), S);
      return json(res, 200, pubView(u));
    }
    case "/api/pub/form": {
      if (!owner) return fail(res, 403, "Only the owner makes forms.");
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M === "DELETE") {
        const S = pubLoad();
        S.forms = S.forms.filter((f) => f.id !== url.searchParams.get("id"));
        pubSave();
        return json(res, 200, pubView(u));
      }
      if (M === "POST") return (formSave(await jsonBody(req, 2e5)), json(res, 200, pubView(u)));
      break;
    }
    case "/api/pub/resp": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const S = pubLoad();
      if (M === "DELETE") {
        S.responses = S.responses.filter((r) => r.id !== url.searchParams.get("id"));
        writeJson(hubf("public.json"), S);
        return json(res, 200, pubView(u));
      }
      const b = await jsonBody(req, 1e4),
        r = S.responses.find((x) => x.id === b.id);
      if (!r) return fail(res, 404, "No such answer.");
      let made = null;
      if (b.do === "approve") {
        r.kind === "company" && (made = responseToCompany(r));
        r.status = "approved";
        pubEvent("company", made ? made.name + " is in Discover" : "Approved: " + r.title, made ? "Publish to put it on the website." : "", r.id);
      } else if (b.do === "decline") r.status = "declined";
      else if (b.do === "done") r.status = "done";
      else if (b.do === "new") r.status = "new";
      r.decided = Date.now();
      writeJson(hubf("public.json"), S);
      return json(res, 200, Object.assign(pubView(u), { made: made ? made.id : "" }));
    }
    case "/api/pub/setup":
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      {
        const r = await pubSetup(await jsonBody(req, 1e4));
        return json(res, 200, Object.assign(pubView(u), { setup: r }));
      }
    case "/api/pub/publish":
      if (!owner) return fail(res, 403, "Only the owner publishes.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      {
        const r = await publish();
        return json(res, 200, Object.assign(pubView(u), { done: r }));
      }
    case "/api/pub/inbox":
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      {
        const r = await inboxSet(!!(await jsonBody(req, 1e3)).on);
        return json(res, 200, Object.assign(pubView(u), { inboxResult: r }));
      }
    case "/api/pub/inbox/check":
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      await inboxWatch();
      return json(res, 200, pubView(u));
    case "/api/chat": {
      if (M === "GET") {
        const since = +url.searchParams.get("since") || 0,
          list = CHAT.msgs.filter((m) => m.at > since || (m.edit || 0) > since).slice(-200);
        return json(res, 200, { msgs: list.map(chatView), me: { id: u.id, name: u.name, owner }, muted: CHAT.muted.includes(u.id), people: owner ? U.users.map((x) => ({ id: x.id, name: x.name, muted: CHAT.muted.includes(x.id) })).concat(CHAT.pub.map((a) => ({ id: "p_" + a.id, name: a.name, muted: !!a.muted, pub: !0 }))) : void 0, now: Date.now() });
      }
      if (M === "POST") {
        if (CHAT.muted.includes(u.id)) return fail(res, 403, "The owner has paused your chat for now.");
        const text = chatClean((await jsonBody(req, 2e4)).text);
        if (!text) return fail(res, 400, "Write something first.");
        if (!owner && CHAT_LINK.test(text)) return fail(res, 400, "Links aren't allowed in the chat.");
        const last = chatLast.get(u.id) || 0,
          wait = owner ? 3000 : CHAT_SLOW;
        if (Date.now() - last < wait) return fail(res, 429, "Slow down: one message every " + wait / 1000 + " seconds.");
        chatLast.set(u.id, Date.now());
        const m = { id: id36(), at: Date.now(), uid: u.id, name: u.name, owner, text };
        CHAT.msgs.push(m);
        CHAT.msgs.length > 1000 && CHAT.msgs.splice(0, CHAT.msgs.length - 1000);
        saveChat();
        broadcast({ type: "chat", at: m.at });
        return json(res, 200, { msg: chatView(m) });
      }
      if (M === "DELETE") {
        const m = CHAT.msgs.find((x) => x.id === url.searchParams.get("id"));
        if (!m) return fail(res, 404, "That message is already gone.");
        if (!owner && m.uid !== u.id) return fail(res, 403, "You can only remove your own messages.");
        ((m.del = !0), (m.text = ""), (m.name = ""), (m.uid = ""), (m.edit = Date.now()));
        saveChat();
        broadcast({ type: "chat", at: m.edit });
        return json(res, 200, { ok: !0 });
      }
      break;
    }
    case "/api/chat/mute": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      const b = await jsonBody(req, 1e3),
        pa = typeof b.uid === "string" && b.uid.startsWith("p_") ? CHAT.pub.find((x) => "p_" + x.id === b.uid) : null;
      if (pa) {
        pa.muted = !!b.on;
        saveChat();
        broadcast({ type: "chat", at: Date.now() });
        return json(res, 200, { ok: !0, muted: pa.muted });
      }
      const who = U.users.find((x) => x.id === b.uid);
      if (!who || who.role === "owner") return fail(res, 400, "Pick someone to pause.");
      CHAT.muted = CHAT.muted.filter((x) => x !== who.id);
      b.on && CHAT.muted.push(who.id);
      saveChat();
      broadcast({ type: "chat", at: Date.now() });
      return json(res, 200, { ok: !0, muted: !!b.on });
    }
    case "/api/chat/remove": {
      // (1.14) the owner removes a public tester: the account, and everything they wrote
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      const b = await jsonBody(req, 1e3),
        i = CHAT.pub.findIndex((x) => "p_" + x.id === b.uid);
      if (i < 0) return fail(res, 404, "That person is already gone.");
      for (const m of CHAT.msgs) m.uid === b.uid && ((m.del = !0), (m.text = ""), (m.name = ""), (m.uid = ""), (m.edit = Date.now()));
      CHAT.pub.splice(i, 1);
      saveChat();
      broadcast({ type: "chat", at: Date.now() });
      return json(res, 200, { ok: !0 });
    }
    case "/api/me/pin": {
      const b = await jsonBody(req, 1e4);
      if (pinHash(String(b.old || ""), u.salt) !== u.hash) return fail(res, 401, "Your current PIN isn't right.");
      setPin(u, b.pin);
      return json(res, 200, { ok: !0 });
    }
    case "/api/events": {
      res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive", "X-Accel-Buffering": "no" });
      res.write("retry: 5000\n\n");
      const c = { res, user: u, device: a.device };
      live.add(c);
      req.on("close", () => live.delete(c));
      return;
    }
    case "/api/users":
      if (!owner) return fail(res, 403, "Only the owner can manage people.");
      if (M !== "GET" && !rigCtl(req, a)) return ctlNo(res);
      if (M === "GET") return json(res, 200, { users: U.users.map((x) => ({ ...pub(x), created: x.created, devices: DV.devices.filter((d) => d.user === x.id).map((d) => ({ id: d.id, name: d.name, seen: d.seen, push: !!d.push, rig: !!d.rig })) })) });
      if (M === "POST") {
        const b = await jsonBody(req, 1e4);
        const nu = addUser(b.name, b.pin, "member", !!b.work);
        log("Added", nu.name);
        return json(res, 200, { user: pub(nu) });
      }
      if (M === "PATCH" || M === "DELETE") {
        const b = M === "PATCH" ? await jsonBody(req, 1e4) : {},
          x = U.users.find((y) => y.id === (b.id || url.searchParams.get("id")));
        if (!x) return fail(res, 404, "Nobody like that on the Hub.");
        if (x.role === "owner") return fail(res, 400, "The owner can't be changed or removed here.");
        if (M === "PATCH") {
          "work" in b && (x.work = !!b.work);
          "browser" in b && ((x.browser = !!b.browser), !x.browser && BRW && BRW.stop("Turned off by the owner.", x.id));
          b.pin && setPin(x, b.pin);
          saveUsers();
          return json(res, 200, { user: pub(x) });
        }
        // their devices are signed out; their music, videos and saves stay in Users\<name> on the rig
        U.users = U.users.filter((y) => y !== x);
        DV.devices = DV.devices.filter((d) => d.user !== x.id);
        for (const c of live) c.user === x && (c.res.end(), live.delete(c));
        saveUsers();
        saveDevices();
        log("Removed", x.name);
        return json(res, 200, { ok: !0 });
      }
      break;
    case "/api/devices":
      if (M === "DELETE") {
        const d = DV.devices.find((x) => x.id === url.searchParams.get("id"));
        if (!d || (!owner && d.user !== u.id)) return fail(res, 404, "No such device.");
        if (d.user !== u.id && !rigCtl(req, a)) return ctlNo(res);
        DV.devices = DV.devices.filter((x) => x !== d);
        saveDevices();
        return json(res, 200, { ok: !0 });
      }
      break;
    // ---- Work (the owner, and anyone the owner lets in)
    case "/api/work": {
      if (!canWork(u)) return fail(res, 403, "Work is only for the people the owner allows.");
      const text = readWorkText(),
        rev = revOf(text);
      if (M === "GET") {
        res.setHeader("X-Rev", rev);
        return json(res, 200, '{"rev":"' + rev + '","data":' + (text || "null") + "}");
      }
      if (M === "PUT") {
        const b = await jsonBody(req, 200e6);
        if ((b.base || "") !== rev) return json(res, 409, '{"rev":"' + rev + '","data":' + (text || "null") + "}");
        if (!b.data || typeof b.data !== "object" || !Array.isArray(b.data.orders)) return fail(res, 400, "That isn't Work data.");
        const nt = JSON.stringify(b.data);
        fs.mkdirSync(WORK(), { recursive: !0 });
        const tmp = workFile() + ".tmp";
        fs.writeFileSync(tmp, nt);
        fs.renameSync(tmp, workFile());
        backupWork(nt);
        const nr = revOf(nt);
        broadcast({ type: "work", rev: nr, by: a.device.id }, (c) => canWork(c.user));
        clearTimeout(route.remT);
        route.remT = setTimeout(checkReminders, 8000);
        return json(res, 200, { rev: nr });
      }
      break;
    }
    case "/api/work/file": {
      if (!canWork(u)) return fail(res, 403, "Work is only for the people the owner allows.");
      const f = inside(WORK(), url.searchParams.get("path"));
      if (!f || /(^|[\\/])work\.json$/i.test(f)) return fail(res, 400, "That path isn't allowed.");
      if (M === "GET" || M === "HEAD") return sendFile(req, res, f, url.searchParams.has("download"));
      if (M === "PUT") return json(res, 200, { size: await receive(req, f) });
      if (M === "DELETE") return (await fsp.rm(f, { force: !0 }), json(res, 200, { ok: !0 }));
      break;
    }
    case "/api/work/list": {
      if (!canWork(u)) return fail(res, 403, "Work is only for the people the owner allows.");
      const d = url.searchParams.get("dir") ? inside(WORK(), url.searchParams.get("dir")) : WORK();
      if (!d) return fail(res, 400, "That path isn't allowed.");
      let ents = [];
      try {
        ents = await fsp.readdir(d, { withFileTypes: !0 });
      } catch {}
      const out = [];
      for (const e of ents) {
        if (e.name.endsWith(".part") || e.name.endsWith(".tmp")) continue;
        const st = await fsp.stat(path.join(d, e.name)).catch(() => null);
        st && out.push({ name: e.name, dir: e.isDirectory(), size: st.size, mtime: Math.floor(st.mtimeMs) });
      }
      return json(res, 200, { items: out });
    }
    // ---- saves and settings (each person their own)
    case "/api/saves": {
      const f = path.join(userDir(u, "Saves"), "saves.json");
      let text = "";
      try {
        text = fs.readFileSync(f, "utf8");
      } catch {}
      const rev = revOf(text);
      if (M === "GET") return json(res, 200, text ? '{"rev":"' + rev + '","save":' + text + "}" : { rev: "", save: null });
      if (M === "PUT") {
        const b = await jsonBody(req, 100e6);
        if ((b.base || "") !== rev) return json(res, 409, text ? '{"rev":"' + rev + '","save":' + text + "}" : { rev: "", save: null });
        if (!b.save || typeof b.save.storage !== "object") return fail(res, 400, "That isn't a Workbench save.");
        // who saved it: the Workbench on the rig itself doesn't need telling that its own save "came from the rig"
        const nt = JSON.stringify(Object.assign({}, b.save, { savedAt: Date.now(), device: a.device.name, deviceId: a.device.id, fromRig: fromRig(req) }));
        fs.mkdirSync(path.dirname(f), { recursive: !0 });
        fs.writeFileSync(f + ".tmp", nt);
        fs.renameSync(f + ".tmp", f);
        return json(res, 200, { rev: revOf(nt) });
      }
      break;
    }
    // ---- music and videos
    case "/api/media": {
      const kind = url.searchParams.get("kind") === "video" ? "video" : "music";
      if (M === "GET") return json(res, 200, { items: await listMedia(u, kind), libraries: libsFor(u, kind).map((l) => ({ scope: l.scope, label: l.label })) });
      if (M === "DELETE") {
        const m = fromId(url.searchParams.get("id")),
          base = m && (m.scope === "u" || owner) ? libDir(u, m.scope, m.kind) : null,
          f = base && inside(base, m.rel);
        if (!f) return fail(res, 403, "You can only remove your own files.");
        await fsp.rm(f, { force: !0 });
        libCache.clear();
        return json(res, 200, { ok: !0 });
      }
      break;
    }
    case "/api/media/file": {
      const m = fromId(url.searchParams.get("id")),
        base = m && libDir(u, m.scope, m.kind),
        f = base && inside(base, m.rel);
      if (!f) return fail(res, 404, "That file isn't on the rig.");
      return sendFile(req, res, f, url.searchParams.has("download"));
    }
    case "/api/media/upload": {
      if (M !== "PUT" && M !== "POST") break;
      const kind = url.searchParams.get("kind") === "video" ? "video" : "music",
        shared = url.searchParams.get("to") === "shared" && owner,
        name = safeName(url.searchParams.get("name"));
      if (!name || !EXT[kind].test(name)) return fail(res, 400, kind === "music" ? "Send MP3, M4A, FLAC, WAV or OGG files." : "Send MP4, WEBM, MOV or MKV files.");
      const base = shared ? path.join(C.root, "Shared", FOLDER[kind]) : userDir(u, FOLDER[kind]);
      let dest = path.join(base, name),
        n = 2;
      while (fs.existsSync(dest)) dest = path.join(base, name.replace(/(\.[^.]+)$/, " (" + n++ + ")$1"));
      const size = await receive(req, dest);
      forget(u, kind);
      return json(res, 200, { size, id: mediaId(kind, shared ? "s" : "u", path.basename(dest)) });
    }
    case "/api/media/fetch": {
      if (M !== "POST") break;
      const b = await jsonBody(req, 2e4);
      let x;
      try {
        x = new URL(String(b.url || "").trim());
      } catch {
        return fail(res, 400, "Paste the whole link, starting with https://");
      }
      try {
        await safeHost(x);
      } catch (e) {
        return fail(res, 400, e.message);
      }
      const job = { id: id36(), user: u.id, url: x.toString(), to: b.to === "music" || b.to === "video" ? b.to : "", shared: b.to === "shared" && owner, name: "", kind: "", got: 0, total: 0, state: "queued", err: "", at: Date.now() };
      jobs.set(job.id, job);
      for (const [k, j] of jobs) if (j.user === u.id && j.state !== "queued" && j.state !== "downloading" && Date.now() - j.at > 6 * 3600000) jobs.delete(k);
      nextJob(u);
      return json(res, 200, { job: jobView(job) });
    }
    case "/api/media/jobs": {
      if (M === "DELETE") {
        const j = jobs.get(url.searchParams.get("id"));
        if (j && j.user === u.id) j.state === "downloading" ? ((j.cancelled = !0), j.cancel && j.cancel()) : jobs.delete(j.id);
        return json(res, 200, { ok: !0 });
      }
      return json(res, 200, { jobs: [...jobs.values()].filter((j) => j.user === u.id).sort((a, b) => b.at - a.at).slice(0, 30).map(jobView) });
    }
    // ---- folders on the rig (the owner adds them; nothing is moved or copied)
    case "/api/libraries": {
      if (!owner) return fail(res, 403, "Only the owner can choose the rig's folders.");
      if (M !== "GET" && !rigCtl(req, a)) return ctlNo(res);
      if (M === "POST") {
        const b = await jsonBody(req, 2e4),
          p = path.resolve(String(b.path || ""));
        let st = null;
        try {
          st = fs.statSync(p);
        } catch {}
        if (!b.path || !st || !st.isDirectory()) return fail(res, 400, "That folder isn't on the rig.");
        if (libraries().some((l) => path.resolve(l.path).toLowerCase() === p.toLowerCase())) return fail(res, 400, "That folder is already in the list.");
        C.libraries = libraries().concat([{ id: libId(p), path: p, kind: b.kind === "music" || b.kind === "video" ? b.kind : "auto", everyone: !!b.everyone, label: String(b.label || path.basename(p) || p).slice(0, 60) }]);
        writeJson(CONF, C);
        log("Added folder", p);
      } else if (M === "DELETE") {
        C.libraries = libraries().filter((l) => l.id !== url.searchParams.get("id"));
        writeJson(CONF, C);
        libCache.clear();
      } else if (M === "PATCH") {
        const b = await jsonBody(req, 2e4),
          l = libraries().find((x) => x.id === b.id);
        if (!l) return fail(res, 404, "No such folder.");
        "everyone" in b && (l.everyone = !!b.everyone);
        C.libraries = libraries().map((x) => (x.id === l.id ? l : x));
        writeJson(CONF, C);
      }
      const out = [];
      // a folder nobody has looked through yet is looked through now, in the background
      for (const L of libsFor(u, "music").concat(libsFor(u, "video"))) {
        if (!L.key.startsWith("l:") || libCache.has(L.key) || scanning.has(L.key)) continue;
        scanning.add(L.key);
        scanLib(L)
          .then((items) => libCache.set(L.key, { t: Date.now(), items }))
          .catch(() => {})
          .finally(() => scanning.delete(L.key));
      }
      for (const l of libraries()) {
        let exists = !1;
        try {
          exists = fs.statSync(l.path).isDirectory();
        } catch {}
        const c = libCache.get("l:" + l.id);
        out.push({ id: l.id, path: l.path, kind: l.kind || "auto", everyone: !!l.everyone, label: l.label || path.basename(l.path), exists, music: c ? c.items.music.length : null, video: c ? c.items.video.length : null });
      }
      return json(res, 200, { libraries: out });
    }
    case "/api/browse":
      if (!owner) return fail(res, 403, "Only the owner can look through the rig's folders.");
      if (!rigCtl(req, a)) return ctlNo(res);
      return json(res, 200, browse(url.searchParams.get("path") || ""));
    // ---- Rig Remote (a phone the owner pairs from the rig) and "use from anywhere" keys (1.5.0)
    case "/api/remote": {
      if (!rigAdmin(req, a)) return adminNo(res);
      return json(res, 200, remoteView());
    }
    case "/api/remote/key": {
      if (!rigAdmin(req, a)) return adminNo(res);
      const R = remLoad();
      if (M === "DELETE") {
        const k = R.keys.find((x) => x.id === url.searchParams.get("id"));
        R.keys = R.keys.filter((x) => x !== k);
        writeJson(hubf("remote.json"), R);
        k && log("Anywhere key removed:", k.name);
        return json(res, 200, remoteView());
      }
      if (M !== "POST") break;
      const b = await jsonBody(req, 1e4),
        name = clip(b.name, 40) || "A device";
      if (R.keys.length >= 20) return fail(res, 400, "That's a lot of keys. Remove one you don't use first.");
      const k = { id: id36(), name, key: "wbk_" + crypto.randomBytes(24).toString("base64url"), at: Date.now(), used: 0, full: b.full !== !1 };
      R.keys.push(k);
      writeJson(hubf("remote.json"), R);
      log("Anywhere key made:", name);
      pubEvent("remote", "Made a key: " + name, k.full ? "The AI, and sign-in with a name and PIN" : "The AI only");
      return json(res, 200, Object.assign(remoteView(), { made: k.id }));
    }
    case "/api/mklinks": {
      // the owner's saved marketing links (Developer options, Marketing sheet): kept here so every device sees the same list.
      // A device sends what it has; the newest edit of each link wins, and a deleted link stays deleted.
      if (!rigCtl(req, a)) return ctlNo(res);
      const f = hubf("mklinks.json"),
        D = readJson(f, { links: [], gone: {} });
      D.links = Array.isArray(D.links) ? D.links : [];
      D.gone = D.gone && typeof D.gone === "object" ? D.gone : {};
      if (M === "POST") {
        const b = await jsonBody(req, 400000),
          by = new Map(D.links.map((l) => [l.id, l])),
          cl = (v, n) => String(v == null ? "" : v).slice(0, n);
        for (const id in b.gone || {}) D.gone[cl(id, 40)] = +b.gone[id] || Date.now();
        for (const l of (Array.isArray(b.links) ? b.links : []).slice(0, 500)) {
          if (!l || !l.id) continue;
          const c = { id: cl(l.id, 40), name: cl(l.name, 120), note: cl(l.note, 600), url: cl(l.url, 400), tag: cl(l.tag, 60), game: cl(l.game, 20), where: cl(l.where, 20), made: +l.made || Date.now(), at: +l.at || Date.now() },
            o = by.get(c.id);
          if (!o || c.at >= (o.at || 0)) by.set(c.id, c);
        }
        for (const id in D.gone) by.delete(id);
        D.links = [...by.values()].sort((x, y) => y.made - x.made).slice(0, 500);
        const keep = Object.entries(D.gone).sort((x, y) => y[1] - x[1]).slice(0, 1000);
        D.gone = Object.fromEntries(keep);
        writeJson(f, D);
      }
      return json(res, 200, D);
    }
    case "/api/traffic": {
      // only the owner, on the rig or on a paired phone
      if (!rigCtl(req, a)) return ctlNo(res);
      const T = trfLoad(),
        S = pubLoad();
      return json(res, 200, { days: T.days, companies: S.companies.map((c) => ({ slug: c.slug, name: c.name })), forms: S.forms.map((f) => ({ slug: f.slug, title: f.title })) });
    }
    case "/api/pair/new": {
      if (!rigAdmin(req, a)) return adminNo(res);
      if (M !== "POST") break;
      return json(res, 200, pairNew(await jsonBody(req, 1000)));
    }
    case "/api/pub/post": {
      // a short update on a company's page (and deleting one)
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M !== "POST") break;
      const b = await jsonBody(req, 2000),
        S = pubLoad(),
        c = S.companies.find((x) => x.id === b.company);
      if (!c) return fail(res, 404, "No such company.");
      c.posts = c.posts || [];
      if (b.del) c.posts = c.posts.filter((x) => x.id !== b.del);
      else {
        const text = clip(b.text, 280);
        if (!text) return fail(res, 400, "Write the update first.");
        c.posts.unshift({ id: id36(), at: Date.now(), text });
        c.posts.length = Math.min(c.posts.length, 20);
      }
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/trail": {
      if (!rigCtl(req, a)) return ctlNo(res);
      const S = pubLoad();
      if (M === "DELETE") {
        S.trails = S.trails.filter((t) => t.id !== url.searchParams.get("id"));
        pubSave();
        return json(res, 200, pubView(u));
      }
      if (M !== "POST") break;
      const b = await jsonBody(req, 5000),
        old = b.id && S.trails.find((t) => t.id === b.id),
        t = old || { id: id36(), at: Date.now(), on: !0 },
        stops = [...new Set([].concat(b.stops || []).map((x) => String(x)).filter((x) => S.companies.some((c) => c.slug === x)))].slice(0, 6);
      if (!clip(b.title, 80)) return fail(res, 400, "Give the trail a name.");
      if (stops.length < 2) return fail(res, 400, "Pick at least two companies for the trail.");
      Object.assign(t, { title: clip(b.title, 80), desc: clip(b.desc, 300), reward: clip(b.reward, 200), stops, on: b.on !== !1 });
      old || S.trails.push(t);
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/biz": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 3000),
        S = pubLoad();
      S.bizEdits ||= [];
      S.weeks ||= [];
      if (b.act === "approve" || b.act === "reject") {
        const e = S.bizEdits.find((x) => x.id === b.id),
          c = e && S.companies.find((x) => x.slug === e.slug);
        if (!e) return fail(res, 404, "No such edit.");
        if (b.act === "approve" && c) {
          const f = e.fields || {};
          "name" in f && f.name && f.name !== c.name && ((c.name = f.name), (c.slug = c.slug));
          companyFields(c, f);
          e.logo && (c.logo = e.logo);
          if (e.media) {
            const md = e.media;
            md.gallery && (c.gallery = md.gallery);
            "bg" in md && (c.bg = md.bg || "");
            md.videos && (c.videos = md.videos);
          }
          e.ad && (c.ad = e.ad);
          c.u = Date.now();
          pubEvent("company", c.name + " changed its card", "Publish to put it on the website.", c.id);
        }
        S.bizEdits = S.bizEdits.filter((x) => x.id !== e.id);
      } else if (b.act === "paid" || b.act === "no") {
        // company of the week (S.weeks) or the ad (S.ads, kind "ad"); weeks asked together (paying in advance) are decided together
        S.ads ||= [];
        const list = b.kind === "ad" ? S.ads : S.weeks,
          w = list.find((x) => x.id === b.id);
        if (!w) return fail(res, 404, "No such request.");
        const grp = w.grp ? list.filter((x) => x.grp === w.grp && x.status === "new") : [w];
        if (b.act === "paid") {
          for (const x of grp) if (list.some((y) => y.from === x.from && y.status === "paid" && y.id !== x.id)) return fail(res, 400, "Another business already has the week of " + x.from + ".");
          for (const x of grp) {
            x.status = "paid";
            x.paidAt = Date.now();
          }
          pubEvent("company", w.name + (b.kind === "ad" ? " has the ad" : " is company of the week"), grp.length + " week" + (grp.length > 1 ? "s" : "") + " from " + grp[0].from + ". Publish to show it.", w.id);
        } else for (const x of grp) x.status = "no";
      } else if (b.act === "setweek") {
        const c = S.companies.find((x) => x.slug === b.slug);
        if (!c) return fail(res, 404, "No such company.");
        const from = /^\d{4}-\d\d-\d\d$/.test(b.from || "") ? monOf(new Date(b.from + "T12:00:00").getTime()) : monOf(Date.now());
        S.weeks.forEach((x) => x.from === from && x.status === "paid" && (x.status = "no"));
        S.weeks.push({ id: id36(), slug: c.slug, name: c.name, from, at: Date.now(), ref: "", status: "paid", by: "owner", paidAt: Date.now() });
      } else if (b.act === "default") {
        S.defaultCo = b.slug && S.companies.some((x) => x.slug === b.slug) ? b.slug : "";
      } else if (b.act === "clearweek") {
        S.weeks.forEach((x) => x.slug === b.slug && x.status === "paid" && x.from === monOf(Date.now()) && (x.status = "no"));
      } else if (b.act === "link" || b.act === "linkno") {
        const r = (S.linkReqs || []).find((x) => x.id === b.id),
          c = r && S.companies.find((x) => x.slug === r.slug);
        if (!r) return fail(res, 404, "No such request.");
        if (b.act === "link") {
          if (!c) return fail(res, 404, "That company isn't listed any more.");
          c.owners = [...new Set([...(c.owners || []), r.email])].slice(0, 5);
          r.status = "ok";
          pubEvent("company", r.email + " now signs in for " + c.name, "Approved from the inbox.", c.id);
        } else r.status = "no";
      } else if (b.act === "idea") {
        const r = (S.ideas || []).find((x) => x.id === b.id);
        if (!r) return fail(res, 404, "No such idea.");
        r.status = b.do === "del" ? "gone" : "seen";
        S.ideas = S.ideas.filter((x) => x.status !== "gone");
      } else if (b.act === "preview") {
        // the owner looks at a company's Business Workbench exactly as the company sees it (read only, nothing is sent from it)
        const c = S.companies.find((x) => x.slug === b.slug);
        if (!c) return fail(res, 404, "No such company.");
        return json(res, 200, { preview: Object.assign(bizMeOf(S, c, (c.owners || [])[0] || "(no Google account yet)"), { preview: !0 }) });
      } else if (b.act === "claim") {
        // a one-time code that links a Google account to a company that is already listed (shown once; kept only as a scramble)
        const c = S.companies.find((x) => x.slug === b.slug);
        if (!c) return fail(res, 404, "No such company.");
        const AL = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
        let tail = "";
        for (const by of crypto.randomBytes(6)) tail += AL[by % AL.length];
        const pre = (c.name || "").normalize("NFD").replace(/[^A-Za-z0-9]/g, "").toUpperCase().slice(0, 8) || "BIZ",
          code = pre + "-" + tail;
        S.claims = (S.claims || []).filter((x) => !x.used && x.exp > Date.now() && x.slug !== c.slug).concat({ id: id36(), slug: c.slug, h: sha("claim:" + code.replace(/-/g, "")), pre, at: Date.now(), exp: Date.now() + 14 * 864e5 });
        pubSave();
        return json(res, 200, Object.assign({}, pubView(u), { claimCode: code, claimDays: 14 }));
      } else if (b.act === "prices") {
        S.prices = { week: Math.max(0, Math.min(9999, Math.round(+b.week || 0))), ad: Math.max(0, Math.min(9999, Math.round(+b.ad || 0))) };
      } else if (b.act === "owners") {
        const c = S.companies.find((x) => x.slug === b.slug);
        if (!c) return fail(res, 404, "No such company.");
        c.owners = [...new Set(String(b.emails || "").toLowerCase().split(/[\s,;]+/).filter((e) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)))].slice(0, 5);
      } else return fail(res, 400, "Unknown.");
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/today": {
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M !== "POST") break;
      const b = await jsonBody(req, 500),
        S = pubLoad();
      S.dayCo = b.slug && S.companies.some((c) => c.slug === b.slug) ? { slug: b.slug, date: /^\d{4}-\d\d-\d\d$/.test(b.date || "") ? b.date : dayKey() } : null;
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/remote/pair": {
      if (!owner) return fail(res, 403, "Only the owner's phone can be a Rig Remote.");
      if (M !== "POST") break;
      if (a.device.remote) return json(res, 200, { remote: !0 });
      if (fromRig(req)) return fail(res, 400, "This is the rig itself. Pair your phone instead.");
      a.device.pairReq = Date.now();
      saveDevices();
      pubNotify("Rig Remote: allow " + a.device.name + "?", u.name + " asked from " + a.device.name + ". Allow it on the rig.", "remote", a.device.id);
      return json(res, 200, { remote: !1, pairReq: a.device.pairReq });
    }
    case "/api/remote/code": {
      // 1.27.0: the access code, typed on the owner's phone (or any device signed in as the owner), makes it a Rig Remote without
      // anyone having to allow it on the rig. The Hub never sees the code, only a one-way scramble of it. The rig keeps the scramble
      // of the code the first time it is unlocked there (or the first phone to use it, until then); after that a phone must match it.
      if (!owner) return fail(res, 403, "Only the owner can do this.");
      if (M !== "POST") break;
      const b = await jsonBody(req, 500),
        pr = String(b.proof || ""),
        f = hubf("remotecode.json"),
        st = readJson(f, null);
      if (!/^[a-f0-9]{64}$/.test(pr)) return fail(res, 400, "That isn't a code.");
      if (fromRig(req)) {
        (!st || st.proof !== pr) && writeJson(f, { proof: pr, at: Date.now() });
        return json(res, 200, { ok: !0, rig: !0 });
      }
      const now = Date.now(),
        t = (CODE_TRIES.get(u.id) || []).filter((x) => now - x < 600000);
      if (t.length >= 8) return fail(res, 429, "Too many wrong codes. Wait a few minutes.");
      if (st && st.proof !== pr) {
        t.push(now);
        CODE_TRIES.set(u.id, t);
        return fail(res, 401, "That code isn't right.");
      }
      CODE_TRIES.delete(u.id);
      !st && writeJson(f, { proof: pr, at: now });
      if (!a.device.remote) {
        a.device.remote = { at: now, code: !0 };
        a.device.pairReq = 0;
        saveDevices();
        pubEvent("remote", "Rig Remote unlocked with the access code: " + a.device.name, "");
        log("Rig Remote (access code):", a.device.name);
      }
      return json(res, 200, { ok: !0, remote: !0 });
    }
    case "/api/remote/allow": {
      if (!rigAdmin(req, a)) return adminNo(res);
      if (M !== "POST") break;
      const b = await jsonBody(req, 1e4),
        d = DV.devices.find((x) => x.id === b.id);
      if (!d || !U.users.some((x) => x.id === d.user && x.role === "owner")) return fail(res, 404, "No such phone.");
      d.remote = b.on ? { at: Date.now() } : null;
      d.pairReq = 0;
      saveDevices();
      pubEvent("remote", (b.on ? "Rig Remote allowed: " : "Rig Remote removed: ") + d.name, "");
      broadcast({ type: "remote" }, (c) => c.device === d);
      log(b.on ? "Rig Remote allowed:" : "Rig Remote removed:", d.name);
      return json(res, 200, Object.assign(remoteView(), pubView(u)));
    }
    // ---- the rig's browser
    case "/api/browser/state":
      return json(res, 200, brState(u));
    case "/api/browser/config": {
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M !== "POST") break;
      const b = await jsonBody(req, 2000);
      C.browser = Object.assign({ on: !1, exe: "" }, C.browser);
      "on" in b && (C.browser.on = !!b.on);
      "exe" in b && (C.browser.exe = clip(b.exe, 300));
      if (b.i2p && typeof b.i2p === "object") {
        // I2P (1.24.0): the rig browser's traffic goes through the I2P router on this computer (loopback only, off by default)
        const was = require("./browser.js").i2pCfg(C.browser.i2p).on;
        C.browser.i2p = require("./browser.js").i2pCfg(Object.assign({}, C.browser.i2p, b.i2p));
        log("Rig browser through I2P", C.browser.i2p.on ? "on" : "off");
        was !== C.browser.i2p.on && BRW && BRW.stop(C.browser.i2p.on ? "The owner switched the browser to I2P." : "The owner switched the browser off I2P.");
      }
      writeJson(CONF, C);
      !C.browser.on && BRW && BRW.stop("Switched off on the rig.");
      log("Rig browser", C.browser.on ? "on" : "off");
      return json(res, 200, Object.assign(brState(u), { visits: readJson(hubf("browser-log.json"), { visits: [] }).visits.slice(0, 40) }));
    }
    case "/api/browser/guests": {
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M === "POST") return json(res, 200, guestNew(await jsonBody(req, 2000)));
      return json(res, 200, { guests: guestLoad().guests.map(guestView) });
    }
    case "/api/browser/limits": {
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M === "POST") {
        const b = await jsonBody(req, 12000),
          cur = brLimits(),
          num = (v, lo, hi, d) => (Number.isFinite(+v) ? Math.max(lo, Math.min(hi, Math.round(+v))) : d);
        C.browser = Object.assign({ on: !1, exe: "" }, C.browser);
        const nl = { guest: Object.assign({}, cur.guest), pub: Object.assign({}, cur.pub), sites: cur.sites };
        if (b.pub) {
          "on" in b.pub && (nl.pub.on = !!b.pub.on);
          "onlyListed" in b.pub && (nl.pub.onlyListed = !!b.pub.onlyListed);
          "minutes" in b.pub && (nl.pub.minutes = num(b.pub.minutes, 5, 240, 30));
          "cooldown" in b.pub && (nl.pub.cooldown = num(b.pub.cooldown, 0, 1440, 30));
          "daily" in b.pub && (nl.pub.daily = num(b.pub.daily, 5, 1440, 90));
        }
        if (b.guest) {
          "onlyListed" in b.guest && (nl.guest.onlyListed = !!b.guest.onlyListed);
          "minutes" in b.guest && (nl.guest.minutes = num(b.guest.minutes, 5, 240, 60));
          "cooldown" in b.guest && (nl.guest.cooldown = num(b.guest.cooldown, 0, 1440, 0));
        }
        if (Array.isArray(b.sites)) nl.sites = [...new Set(b.sites.map((x) => require("./browser.js").normHost(x)).filter((x) => /^[a-z0-9.-]{3,100}$/.test(x) && x.includes(".")))].slice(0, 200);
        C.browser.limits = nl;
        // new rules apply from now: waiting times people were already serving start over
        (nl.pub.cooldown !== cur.pub.cooldown || nl.guest.cooldown !== cur.guest.cooldown) && brCool.clear();
        if (b.ban) {
          const X = pbuLoad().users[String(b.ban.id)];
          X && ((X.banned = b.ban.on ? Date.now() : 0), pbuSave(), b.ban.on && BRW && BRW.stop("The owner turned this account off.", "p:" + b.ban.id));
        }
        writeJson(CONF, C);
        !nl.pub.on && BRW && BRW.all().filter((x) => x.user.id[0] === "p").forEach((x) => BRW.stop("Free browsing was switched off.", x));
        log("Browser limits changed" + (b.pub && "on" in b.pub ? " · public " + (nl.pub.on ? "on" : "off") : ""));
      }
      return json(res, 200, brLimitsView());
    }
    case "/api/browser/i2pcheck": {
      if (!rigCtl(req, a)) return ctlNo(res);
      return json(res, 200, await require("./browser.js").i2pProbe(C.browser && C.browser.i2p));
    }
    case "/api/browser/dnscheck": {
      if (!rigCtl(req, a)) return ctlNo(res);
      return json(res, 200, await dnsCheck());
    }
    case "/api/browser/guests/revoke": {
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M !== "POST") break;
      const b = await jsonBody(req, 1000),
        g = guestLoad().guests.find((x) => x.id === b.id);
      if (!g) return fail(res, 404, "No such guest code.");
      b.remove ? (GST.guests = GST.guests.filter((x) => x !== g)) : (g.revoked = Date.now());
      for (const [k, v] of GSESS) v.gid === g.id && GSESS.delete(k);
      BRW && BRW.stop("The owner ended the guest code.", "g:" + g.id);
      guestSave();
      log("Guest code", b.remove ? "removed:" : "revoked:", g.name);
      return json(res, 200, { guests: GST.guests.map(guestView) });
    }
    case "/api/browser/log": {
      if (!rigCtl(req, a)) return ctlNo(res);
      return json(res, 200, { visits: readJson(hubf("browser-log.json"), { visits: [] }).visits.slice(0, 60) });
    }
    case "/api/accounts": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const I = acctIndex();
      return json(res, 200, { clientId: (C.google && C.google.clientId) || "", count: I.list.length, signinsTotal: I.list.reduce((n, x) => n + (x.signins || 0), 0), runSecTotal: I.list.reduce((n, x) => n + (x.runSec || 0), 0), bytes: acctUsed(), limit: acctMaxEach(), maxEach: acctMaxEach(), maxTotal: acctMaxTotal(), list: I.list.slice().sort((a, b) => (b.seen || 0) - (a.seen || 0)).slice(0, 2000) });
    }
    case "/api/accounts/config": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 2000),
        cid = String(b.clientId || "").trim();
      if (cid && !/^[0-9]+-[0-9a-z]+\.apps\.googleusercontent\.com$/.test(cid)) return fail(res, 400, "That doesn't look like a Google Client ID (it ends in .apps.googleusercontent.com).");
      const g = { clientId: cid };
      if (b.maxEachKB !== undefined) g.maxEach = Math.max(50, Math.min(5000, Math.round(+b.maxEachKB) || 1000)) * 1000;
      if (b.maxTotalMB !== undefined) g.maxTotal = Math.max(50, Math.min(5e6, Math.round(+b.maxTotalMB) || 5000)) * 1e6;
      C.google = Object.assign({}, C.google, g);
      writeJson(CONF, C);
      pubSave();
      return json(res, 200, { clientId: cid, maxEach: acctMaxEach(), maxTotal: acctMaxTotal() });
    }
    case "/api/accounts/del": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 500),
        id = String(b.id || "");
      if (!/^[0-9a-f]{32}$/.test(id)) return fail(res, 400, "Which account?");
      for (const f of [acctFile(id), acctFile(id, !0)]) await fsp.rm(f, { force: !0 });
      const I = acctIndex();
      I.list = I.list.filter((x) => x.id !== id);
      acctIdxSave();
      return json(res, 200, { ok: !0 });
    }
    case "/api/terms/accept": {
      if (M !== "POST") break;
      const b = await jsonBody(req, 2000),
        T = termsLoad(),
        terms = String(b.terms || "").replace(/[^0-9A-Za-z._-]/g, "").slice(0, 20),
        dev = (a.device && a.device.name) || "";
      if (!terms) return fail(res, 400, "Which terms?");
      const last = T.acc.find((x) => x.user === u.id && x.device === dev && x.terms === terms);
      if (!last) {
        T.acc.unshift({ id: id36(), at: Date.now(), user: u.id, name: u.name, device: dev, terms, app: String(b.app || "").replace(/[^0-9A-Za-z._-]/g, "").slice(0, 20), clientAt: +b.at || 0 });
        T.acc.length > 2000 && (T.acc.length = 2000);
        termsSave();
      }
      return json(res, 200, { ok: !0 });
    }
    case "/api/terms": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const T = termsLoad(),
        seen = new Set(),
        latest = [];
      for (const x of T.acc) {
        const k = x.user + "|" + x.device;
        seen.has(k) || (seen.add(k), latest.push(x));
      }
      return json(res, 200, { acc: latest.slice(0, 100), log: T.log.slice(0, 200) });
    }
    case "/api/terms/note": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 4000),
        who = U.users.find((x) => x.id === b.user) || { id: "", name: clip(b.name, 60) };
      if (!clip(b.what, 400)) return fail(res, 400, "Write what happened.");
      ruleLog(who, b.what, b.action, !1);
      return json(res, 200, { log: termsLoad().log.slice(0, 200) });
    }
    case "/api/terms/note-del": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 500),
        T = termsLoad();
      T.log = T.log.filter((x) => x.id !== b.id);
      termsSave();
      return json(res, 200, { log: T.log.slice(0, 200) });
    }
    case "/api/browser/ack":
      if (M !== "POST") break;
      u.brAck = Date.now();
      saveUsers();
      return json(res, 200, brState(u));
    case "/api/browser/start": {
      if (M !== "POST") break;
      if (!BRW) return fail(res, 404, "The rig's browser needs the Hub's update.");
      if (!brOn()) return fail(res, 403, "The owner has the rig's browser switched off.");
      if (!canBrowse(u)) return fail(res, 403, "The owner hasn't turned the rig's browser on for you.");
      if (u.role !== "owner" && !u.brAck) return fail(res, 409, "Read the notice about the rig's browser first.");
      const b = await jsonBody(req, 500).catch(() => ({}));
      return json(res, 200, await BRW.start(u, C.browser, void 0, await i2pChoice(b)));
    }
    case "/api/browser/stop":
      if (M !== "POST") break;
      BRW && BRW.stop("Closed.", u.id);
      return json(res, 200, brState(u));
    case "/api/browser/go":
    case "/api/browser/input":
    case "/api/browser/resize": {
      if (M !== "POST" || !BRW || !brOn() || !canBrowse(u)) return fail(res, 403, "The rig's browser isn't available.");
      const b = await jsonBody(req, 20000);
      if (p.endsWith("/go")) await BRW.go(u, b.url);
      else if (p.endsWith("/input")) await BRW.input(u, b.events);
      else await BRW.resize(u, b.w, b.h);
      return json(res, 200, { ok: !0 });
    }
    case "/api/browser/frame": {
      if (!BRW || !brOn() || !canBrowse(u)) return fail(res, 403, "The rig's browser isn't available.");
      const f = await BRW.frame(u, +url.searchParams.get("n") || 0, 20000),
        h = { "Cache-Control": "no-store", "X-Frame": String(f.n), "X-Url": encodeURIComponent(f.url), "X-Title": encodeURIComponent(f.title), "X-Size": f.w + "x" + f.h, "Access-Control-Expose-Headers": "X-Frame, X-Url, X-Title, X-Size" };
      if (!f.buf) return (res.writeHead(204, h), res.end());
      res.writeHead(200, Object.assign(h, { "Content-Type": "image/jpeg", "Content-Length": f.buf.length }));
      return res.end(f.buf);
    }
    // fetch the newest Hub now instead of at the next check (1.13.1): the owner, from any device
    case "/api/hub/update": {
      if (M !== "POST") break;
      if (!owner) return fail(res, 403, "Only the owner can update the Hub.");
      const r = await checkUpdate(!0);
      if (!r.ok) return fail(res, 502, "The Hub couldn't fetch its update: " + r.error);
      r.updating && log("Update asked by", u.name, "on", a.device.name);
      return json(res, 200, { ok: !0, version: VERSION, latest: r.latest, updating: !!r.updating });
    }
    case "/api/hub/restart":
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      log("Restart asked by", u.name, "on", a.device.name);
      pubEvent("update", "Hub restarted", "from " + a.device.name);
      json(res, 200, { ok: !0 });
      // the icon by the clock starts it again in a few seconds
      setTimeout(() => process.exit(4), 600);
      return;
    // ---- notifications
    case "/api/push/key":
      return json(res, 200, { key: VAPID.pub });
    case "/api/push/subscribe": {
      const b = await jsonBody(req, 2e4);
      if (!b.sub || !b.sub.endpoint || !b.sub.keys) return fail(res, 400, "That isn't a push subscription.");
      a.device.push = { endpoint: b.sub.endpoint, keys: { p256dh: b.sub.keys.p256dh, auth: b.sub.keys.auth } };
      a.device.notify = b.notify !== !1;
      saveDevices();
      return json(res, 200, { ok: !0 });
    }
    case "/api/push/unsubscribe":
      a.device.push = null;
      saveDevices();
      return json(res, 200, { ok: !0 });
    case "/api/push/test": {
      const code = await pushTo(a.device, { title: "Workbench Hub", body: "Notifications work on this device.", tag: "wb-test", open: "bell" });
      return code >= 200 && code < 300 ? json(res, 200, { ok: !0 }) : fail(res, 502, "The phone's push service didn't take it" + (code ? " (" + code + ")" : "") + ". Check that the rig has internet.");
    }
    case "/api/digest": {
      if (!canWork(u)) return fail(res, 403, "Work is only for the people the owner allows.");
      if (M === "POST") {
        const b = await jsonBody(req, 1e4);
        if (b.lang && b.lang !== C.lang) ((C.lang = String(b.lang).slice(0, 30)), writeJson(CONF, C));
        return json(res, 200, (await makeDigest()) || {});
      }
      const dg = readJson(hubf("digest.json"), null);
      if (!dg || Date.now() - dg.at > 65 * 60000) makeDigest().catch(() => {});
      return json(res, 200, dg || {});
    }
  }
  return fail(res, 404, "Not found");
}

// ---- start -------------------------------------------------------------------------------------
function main() {
  const argv = process.argv.slice(2);
  setup();
  if (argv[0] === "--init-owner") {
    if (U.users.some((x) => x.role === "owner")) return console.log("The Hub already has an owner.");
    addUser(argv[1], argv[2], "owner");
    return console.log("Owner created: " + argv[1]);
  }
  if (argv[0] === "--reset-pin") {
    const x = U.users.find((y) => y.name.toLowerCase() === String(argv[1] || "").toLowerCase());
    if (!x) return (console.log("Nobody called " + argv[1]), process.exit(1));
    setPin(x, argv[2]);
    return console.log("New PIN set for " + x.name);
  }
  const srv = http.createServer((req, res) =>
    route(req, res).catch((e) => {
      if (e.code !== 400 && e.code !== 401 && e.code !== 429) log("Error", req.method, req.url.split("?")[0], e.stack || e.message);
      fail(res, typeof e.code === "number" ? e.code : 500, e.message || "Something went wrong on the Hub.");
    }),
  );
  srv.requestTimeout = 0;
  srv.headersTimeout = 60000;
  srv.on("error", (e) => {
    log("Can't start:", e.message);
    process.exit(e.code === "EADDRINUSE" ? 2 : 1);
  });
  srv.listen(C.port, C.host, () => log("Workbench Hub", VERSION, "on http://" + C.host + ":" + C.port, "· folder", C.root));
  // the public inbox: only company applications and messages (shared to the internet by Tailscale Funnel)
  const ib = http.createServer((req, res) => inboxRoute(req, res).catch((e) => fail(res, typeof e.code === "number" ? e.code : 500, e.message || "Something went wrong.")));
  // (long enough for an upload through the anywhere door; the inbox's own posts are small)
  ib.requestTimeout = 20 * 60000;
  ib.headersTimeout = 30000;
  ib.on("error", (e) => log("Inbox can't start:", e.message));
  ib.listen(C.inboxPort || 8771, "127.0.0.1");
  setTimeout(checkReminders, 20000);
  setInterval(() => checkReminders().catch((e) => log("reminders:", e.message)), 10 * 60000);
  setInterval(() => makeDigest().catch((e) => log("digest:", e.message)), 60 * 60000);
  setTimeout(() => makeDigest().catch(() => {}), 120000);
  // soon after it starts (so "Restart the Hub" is also "update the Hub"), then every hour
  setTimeout(checkUpdate, 30000);
  setTimeout(histSample, 45000);
  setInterval(histSample, 10 * 60000);
  setTimeout(() => inboxWatch().catch((e) => log("inbox:", e.message)), 90000);
  setInterval(() => inboxWatch().catch((e) => log("inbox:", e.message)), 10 * 60000);
  setInterval(checkUpdate, 3600000);
}
if (require.main === module) main();
module.exports = { route, setup, C, addUser, checkReminders, makeDigest, directLink, folderHint, autoKind, VERSION };
