// Workbench Hub: the home server on the rig. One folder on one drive holds everything (Work,
// designs, music, videos, saves and settings), and every device running Workbench syncs with it
// over Tailscale. It also sends phone notifications, hands the AI (Ollama) to every device, and
// updates itself from the Workbench site. Plain Node.js, no packages to install.
//
//   node server.js                      start the Hub
//   node server.js --init-owner NAME PIN    create the owner (the installer does this)
//   node server.js --reset-pin NAME PIN     set a new PIN for someone who forgot theirs
"use strict";
const http = require("http"),
  fs = require("fs"),
  fsp = fs.promises,
  path = require("path"),
  crypto = require("crypto"),
  os = require("os"),
  push = require("./push.js"),
  { readTags } = require("./tags.js"),
  { __wbReminders } = require("./reminders.js");

const VERSION = "1.13.1";
const HOME = process.env.WB_HUB_HOME || path.join(__dirname, "..");
const CONF = process.env.WB_HUB_CONFIG || path.join(HOME, "hub.json");
const APP = "https://tonystarkofficial1111-web.github.io";

// ---- settings ----------------------------------------------------------------------------------
const DEF = {
  port: 8770,
  host: "127.0.0.1",
  root: path.join(os.homedir(), "Workbench Hub"),
  name: os.hostname(),
  origins: [APP],
  ollama: "http://127.0.0.1:11434",
  aiModel: "",
  lang: "",
  update: APP + "/Workbench/hub/",
  autoUpdate: true,
  // more music or video folders, for example a second drive later:
  // [{ "path": "E:\\Music", "kind": "music", "everyone": false }]
  libraries: [],
  // a second copy of work.json every day, for example on a second drive later: "E:\\Backups"
  backupDir: "",
};
const readJson = (f, d) => {
  try {
    return JSON.parse(fs.readFileSync(f, "utf8").replace(/^\uFEFF/, ""));
  } catch {
    return d;
  }
};
function writeJson(f, v) {
  fs.mkdirSync(path.dirname(f), { recursive: !0 });
  const t = f + "." + process.pid + ".tmp";
  fs.writeFileSync(t, JSON.stringify(v, null, 1));
  fs.renameSync(t, f);
}
const C = Object.assign({}, DEF, readJson(CONF, {}));
const hubf = (n) => path.join(C.root, ".hub", n);
const WORK = () => path.join(C.root, "Work");
const sha = (b) => crypto.createHash("sha256").update(b).digest("hex");
const id36 = () => Date.now().toString(36) + crypto.randomBytes(4).toString("hex");

// ---- log ---------------------------------------------------------------------------------------
const LOG = path.join(HOME, "logs", "hub.log");
function log(...a) {
  const line = new Date().toISOString() + " " + a.join(" ");
  console.log(line);
  try {
    fs.mkdirSync(path.dirname(LOG), { recursive: !0 });
    if (fs.existsSync(LOG) && fs.statSync(LOG).size > 2e6) fs.renameSync(LOG, LOG + ".old");
    fs.appendFileSync(LOG, line + "\n");
  } catch {}
}

// ---- people and devices ------------------------------------------------------------------------
let U = { users: [] },
  DV = { devices: [] },
  VAPID = null,
  dvT = 0;
const saveUsers = () => writeJson(hubf("users.json"), U);
const saveDevices = () => (clearTimeout(dvT), writeJson(hubf("devices.json"), DV));
const saveDevicesSoon = () => (clearTimeout(dvT), (dvT = setTimeout(saveDevices, 3000)));
const pinHash = (pin, salt) => crypto.scryptSync(String(pin), salt, 32).toString("hex");
const safeName = (s) =>
  String(s || "")
    .replace(/[<>:"/\\|?*\x00-\x1f]/g, "")
    .replace(/^[.\s]+|[.\s]+$/g, "")
    .slice(0, 60);
const userDir = (u, kind) => path.join(C.root, "Users", u.dir, kind || "");
const canWork = (u) => !!u && (u.role === "owner" || !!u.work);
const canBrowse = (u) => !!u && (u.role === "owner" || !!u.browser);
const pub = (u) => ({ id: u.id, name: u.name, role: u.role, work: canWork(u), artist: !!u.artist, browser: canBrowse(u) });
function addUser(name, pin, role, work) {
  name = String(name || "").trim();
  if (!name || !/^\d{4,12}$/.test(String(pin))) throw new Error("A name and a PIN of 4 to 12 digits are needed.");
  if (U.users.some((u) => u.name.toLowerCase() === name.toLowerCase())) throw new Error("Someone called " + name + " is already on the Hub.");
  let dir = safeName(name) || "User",
    n = 2;
  while (U.users.some((u) => u.dir.toLowerCase() === dir.toLowerCase())) dir = safeName(name) + " " + n++;
  const salt = crypto.randomBytes(16).toString("hex"),
    u = { id: id36(), name, dir, role, work: role === "owner" || !!work, salt, hash: pinHash(pin, salt), created: Date.now() };
  U.users.push(u);
  for (const k of ["Music", "Videos", "Saves"]) fs.mkdirSync(userDir(u, k), { recursive: !0 });
  saveUsers();
  return u;
}
function setPin(u, pin) {
  if (!/^\d{4,12}$/.test(String(pin))) throw new Error("Use a PIN of 4 to 12 digits.");
  u.salt = crypto.randomBytes(16).toString("hex");
  u.hash = pinHash(pin, u.salt);
  saveUsers();
}

function setup() {
  for (const d of [".hub/cache", ".hub/backups", "Work", "Users", "Shared/Music", "Shared/Videos"]) fs.mkdirSync(path.join(C.root, d), { recursive: !0 });
  U = readJson(hubf("users.json"), { users: [] });
  DV = readJson(hubf("devices.json"), { devices: [] });
  VAPID = readJson(hubf("vapid.json"), null);
  if (!VAPID) writeJson(hubf("vapid.json"), (VAPID = push.makeVapid()));
  if (!fs.existsSync(CONF)) writeJson(CONF, C);
}

// ---- HTTP helpers ------------------------------------------------------------------------------
function json(res, code, obj) {
  if (res.headersSent) return res.end();
  const b = Buffer.from(typeof obj === "string" ? obj : JSON.stringify(obj));
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Content-Length": b.length, "Cache-Control": "no-store" });
  res.end(b);
}
const fail = (res, code, msg) => json(res, code, { error: msg });
function body(req, limit) {
  return new Promise((ok, bad) => {
    const parts = [];
    let n = 0;
    req.on("data", (c) => {
      n += c.length;
      if (n > (limit || 64e6)) (bad(new Error("Too big")), req.destroy());
      else parts.push(c);
    });
    req.on("end", () => ok(Buffer.concat(parts)));
    req.on("error", bad);
  });
}
async function jsonBody(req, limit) {
  const b = await body(req, limit);
  try {
    return b.length ? JSON.parse(b.toString("utf8")) : {};
  } catch {
    throw Object.assign(new Error("That wasn't valid data."), { code: 400 });
  }
}
function allowOrigin(o) {
  if (!o) return "";
  if (o === "null" || (C.origins || []).includes(o)) return o;
  if (/^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(o)) return o;
  if (/^https:\/\/[a-z0-9-]+(\.[a-z0-9-]+)*\.ts\.net$/i.test(o)) return o;
  return "";
}
function cors(req, res) {
  const o = allowOrigin(req.headers.origin);
  res.setHeader("Vary", "Origin");
  if (!o) return;
  res.setHeader("Access-Control-Allow-Origin", o);
  res.setHeader("Access-Control-Expose-Headers", "ETag, Content-Range, Accept-Ranges, Content-Length, X-Rev");
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", req.headers["access-control-request-headers"] || "Authorization, Content-Type, Range");
    res.setHeader("Access-Control-Max-Age", "600");
    if (req.headers["access-control-request-private-network"]) res.setHeader("Access-Control-Allow-Private-Network", "true");
  }
}
// a path inside base, or null if it tries to leave it
function inside(base, rel) {
  rel = String(rel || "").replace(/\\/g, "/");
  if (!rel || rel.includes("\0") || /(^|\/)\.\.(\/|$)/.test(rel) || /^[a-z]:/i.test(rel) || rel.startsWith("/") || /:/.test(rel)) return null;
  const full = path.resolve(base, rel),
    r = path.relative(base, full);
  return r && !r.startsWith("..") && !path.isAbsolute(r) ? full : null;
}
const TYPES = { mp3: "audio/mpeg", m4a: "audio/mp4", aac: "audio/aac", flac: "audio/flac", wav: "audio/wav", ogg: "audio/ogg", oga: "audio/ogg", opus: "audio/ogg", weba: "audio/webm", aif: "audio/aiff", aiff: "audio/aiff", mp4: "video/mp4", m4v: "video/mp4", webm: "video/webm", mov: "video/quicktime", mkv: "video/x-matroska", ogv: "video/ogg", psd: "image/vnd.adobe.photoshop", psb: "image/vnd.adobe.photoshop", pdf: "application/pdf", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", svg: "image/svg+xml", gif: "image/gif", tif: "image/tiff", tiff: "image/tiff", json: "application/json", txt: "text/plain; charset=utf-8" };
const typeOf = (f) => TYPES[path.extname(f).slice(1).toLowerCase()] || "application/octet-stream";
function sendFile(req, res, file, download) {
  let st;
  try {
    st = fs.statSync(file);
  } catch {
    return fail(res, 404, "That file isn't on the rig.");
  }
  if (!st.isFile()) return fail(res, 404, "That file isn't on the rig.");
  const size = st.size;
  res.setHeader("Accept-Ranges", "bytes");
  res.setHeader("Content-Type", typeOf(file));
  res.setHeader("ETag", '"' + size.toString(36) + "-" + Math.floor(st.mtimeMs).toString(36) + '"');
  res.setHeader("Last-Modified", st.mtime.toUTCString());
  res.setHeader("Cache-Control", "private, no-cache");
  if (download) res.setHeader("Content-Disposition", "attachment; filename*=UTF-8''" + encodeURIComponent(path.basename(file)));
  let start = 0,
    end = size - 1,
    code = 200;
  const m = /^bytes=(\d*)-(\d*)$/.exec(String(req.headers.range || "").trim());
  if (m && size) {
    if (m[1] === "") start = Math.max(0, size - +m[2]);
    else ((start = +m[1]), m[2] !== "" && (end = Math.min(+m[2], size - 1)));
    if (start > end || start >= size) {
      res.writeHead(416, { "Content-Range": "bytes */" + size });
      return res.end();
    }
    code = 206;
    res.setHeader("Content-Range", "bytes " + start + "-" + end + "/" + size);
  }
  res.setHeader("Content-Length", size ? end - start + 1 : 0);
  res.writeHead(code);
  if (req.method === "HEAD" || !size) return res.end();
  const s = fs.createReadStream(file, { start, end });
  s.on("error", () => res.destroy());
  res.on("close", () => s.destroy());
  s.pipe(res);
}
// a file upload, streamed straight to disk (any size), then put in place
async function receive(req, dest) {
  await fsp.mkdir(path.dirname(dest), { recursive: !0 });
  const tmp = dest + ".part";
  await new Promise((ok, bad) => {
    const w = fs.createWriteStream(tmp);
    req.pipe(w);
    w.on("finish", ok);
    w.on("error", bad);
    req.on("aborted", () => (w.destroy(), bad(new Error("The upload stopped."))));
  });
  await fsp.rename(tmp, dest);
  return (await fsp.stat(dest)).size;
}

// ---- sign in -----------------------------------------------------------------------------------
const tries = new Map();
function auth(req, url) {
  const h = String(req.headers.authorization || ""),
    tok = h.startsWith("Bearer ") ? h.slice(7).trim() : url.searchParams.get("t") || "";
  if (!tok) return null;
  const th = sha(tok),
    d = DV.devices.find((x) => x.tokenHash === th),
    u = d && U.users.find((x) => x.id === d.user);
  if (!u) return null;
  if (Date.now() - (d.seen || 0) > 60000) ((d.seen = Date.now()), saveDevicesSoon());
  return { user: u, device: d };
}
function login(b) {
  const name = String(b.name || "").trim(),
    key = name.toLowerCase(),
    t = tries.get(key) || { n: 0, until: 0 };
  if (t.until > Date.now()) throw Object.assign(new Error("Too many wrong PINs. Try again in " + Math.ceil((t.until - Date.now()) / 60000) + " minutes."), { code: 429 });
  const u = U.users.find((x) => x.name.toLowerCase() === key);
  if (!u || pinHash(String(b.pin || ""), u.salt) !== u.hash) {
    t.n++;
    if (t.n >= 5) ((t.until = Date.now() + (t.n >= 10 ? 60 : 15) * 60000), t.n >= 10 && (t.n = 5));
    tries.set(key, t);
    throw Object.assign(new Error(u ? "That PIN isn't right." : "Nobody called " + (name || "that") + " is on this Hub. Ask the owner to add you."), { code: 401 });
  }
  tries.delete(key);
  const token = crypto.randomBytes(32).toString("base64url"),
    d = { id: id36(), user: u.id, name: String(b.device || "Device").slice(0, 60), tokenHash: sha(token), created: Date.now(), seen: Date.now(), push: null, notify: !0 };
  DV.devices.push(d);
  saveDevices();
  log("Signed in:", u.name, "on", d.name);
  try {
    pubEvent("device", u.name + " signed in", "on " + d.name);
  } catch {}
  return { token, user: pub(u), device: { id: d.id, name: d.name } };
}

// ---- live updates (Server-Sent Events) ---------------------------------------------------------
const live = new Set();
function broadcast(ev, filter) {
  const line = "data: " + JSON.stringify(ev) + "\n\n";
  for (const c of live) if (!filter || filter(c)) c.res.write(line);
}
setInterval(() => {
  for (const c of live) c.res.write(": ping\n\n");
}, 25000).unref();

// ---- the testers' chat (1.13) -------------------------------------------------------------------
// One group chat for everyone with a Hub account, kept on the rig (.hub/chat.json, the last 1,000
// messages). Text only, 500 characters, one message every 3 seconds each, rude words starred out.
// The owner can remove any message and pause anyone's chat; people can remove their own.
const CHAT = readJson(hubf("chat.json"), { msgs: [], muted: [] });
CHAT.msgs ||= [];
CHAT.muted ||= [];
let chatT = null;
const saveChat = () => (clearTimeout(chatT), (chatT = setTimeout(() => writeJson(hubf("chat.json"), CHAT), 600)));
const chatLast = new Map();
const CHAT_RUDE = /\b(f+u+c+k+\w*|sh+i+t+\w*|bitch\w*|cunt\w*|n+i+g+g+\w*|fag\w*|retard\w*|whore\w*|slut\w*|pussy\w*|asshole\w*|bastard\w*)/gi;
const chatClean = (t) => String(t || "").replace(/[\u0000-\u0008\u000b-\u001f\u007f]/g, "").replace(/\n{3,}/g, "\n\n").trim().slice(0, 500).replace(CHAT_RUDE, (w) => w[0] + "*".repeat(Math.max(2, w.length - 1)));
const chatView = (m) => (m.del ? { id: m.id, at: m.at, uid: m.uid, name: m.name, del: !0 } : { id: m.id, at: m.at, uid: m.uid, name: m.name, owner: !!m.owner, text: m.text });

// ---- Work --------------------------------------------------------------------------------------
const workFile = () => path.join(WORK(), "work.json");
function readWorkText() {
  try {
    return fs.readFileSync(workFile(), "utf8");
  } catch {
    return "";
  }
}
const revOf = (t) => (t ? sha(t).slice(0, 16) : "");
function readWork() {
  const t = readWorkText();
  try {
    return t ? JSON.parse(t) : null;
  } catch {
    return null;
  }
}
function backupWork(text) {
  const day = new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
  for (const dir of [hubf("backups"), C.backupDir ? path.join(C.backupDir, "Workbench Hub backups") : ""].filter(Boolean))
    try {
      fs.mkdirSync(dir, { recursive: !0 });
      fs.writeFileSync(path.join(dir, "work-" + day + ".json"), text);
      const old = fs
        .readdirSync(dir)
        .filter((n) => /^work-\d{4}-\d\d-\d\d\.json$/.test(n))
        .sort()
        .reverse();
      for (const n of old.slice(90)) fs.unlinkSync(path.join(dir, n));
    } catch (e) {
      log("backup:", e.message);
    }
}

// ---- music and videos --------------------------------------------------------------------------
// Each person's own Music and Videos folders, the Shared ones, and folders the owner adds from
// anywhere on the rig (a big folder of everything, a second drive later). Those are read where
// they are: nothing is moved or copied. In a mixed folder ("auto") Workbench picks out what it
// needs by folder names and file types: songs from music-looking folders (or anything that is
// clearly a song), videos, and it skips photo folders, program folders and tiny sound effects.
const EXT = { music: /\.(mp3|m4a|aac|flac|wav|ogg|oga|opus|weba|aif|aiff)$/i, video: /\.(mp4|m4v|webm|mov|mkv|ogv)$/i };
const FOLDER = { music: "Music", video: "Videos" };
const SKIP_DIR = /^(\$recycle\.bin|system volume information|windows|program files( \(x86\))?|programdata|appdata|node_modules|\.git|\.hub|temp|tmp|cache|caches|steamapps|xboxgames|recovery|perflogs)$/i;
const PHOTO_DIR = /(^|[\s_.-])(photos?|pictures?|pics|imgs?|images?|camera|camera roll|dcim|screenshots?|wallpapers?|fotos?|im[aá]genes|selfies)($|[\s_.-])/i;
const MUSIC_DIR = /(^|[\s_.-])(music|songs?|audio|mp3s?|tracks?|beats?|albums?|playlists?|dj|m[uú]sica|canciones|mixes|remixes|instrumentals?)($|[\s_.-])/i;
const VIDEO_DIR = /(^|[\s_.-])(videos?|v[ií]deos|movies?|films?|clips?|shows?|series|pel[ií]culas|tv|anime|recordings?)($|[\s_.-])/i;
// what a folder looks like it holds, from its own name or the nearest parent with a telling name
function folderHint(names) {
  for (let i = names.length - 1; i >= 0; i--) {
    if (PHOTO_DIR.test(names[i])) return "photo";
    if (MUSIC_DIR.test(names[i])) return "music";
    if (VIDEO_DIR.test(names[i])) return "video";
  }
  return "";
}
// which list a file belongs in, in a mixed folder (or null to leave it out)
function autoKind(name, size, hint) {
  if (hint === "photo") return null;
  if (EXT.music.test(name)) return hint === "music" || size >= 1.2e6 ? "music" : null;
  if (EXT.video.test(name)) return size >= 1e6 ? "video" : null;
  return null;
}
let tagCache = null,
  tagT = 0;
const libCache = new Map();
const libId = (p) => sha(String(p).toLowerCase()).slice(0, 8);
function libraries() {
  let L = [].concat(C.libraries || []).filter((l) => l && l.path);
  for (const l of L) l.id = l.id || libId(l.path);
  return L;
}
// the folders a person sees for one kind (music or video)
function libsFor(u, kind) {
  const out = [
    { key: "u:" + u.id + ":" + kind, scope: "u", dir: userDir(u, FOLDER[kind]), mode: kind, label: "Mine" },
    { key: "s:" + kind, scope: "s", dir: path.join(C.root, "Shared", FOLDER[kind]), mode: kind, label: "Shared" },
  ];
  for (const l of libraries()) {
    const mode = l.kind === "music" || l.kind === "video" ? l.kind : "auto";
    if ((mode === kind || mode === "auto") && (l.everyone || u.role === "owner")) out.push({ key: "l:" + l.id, scope: "l" + l.id, dir: l.path, mode, label: l.label || path.basename(l.path) || l.path });
  }
  return out;
}
function libDir(u, scope, kind) {
  const l = libsFor(u, kind).find((x) => x.scope === scope);
  return l ? l.dir : null;
}
const mediaId = (kind, scope, rel) => Buffer.from(kind + "\n" + scope + "\n" + rel).toString("base64url");
function fromId(id) {
  const p = Buffer.from(String(id || ""), "base64url").toString("utf8").split("\n");
  return p.length === 3 && FOLDER[p[0]] ? { kind: p[0], scope: p[1], rel: p[2] } : null;
}
function tagsOf(file, st, name) {
  if (!tagCache) tagCache = readJson(hubf("cache/tags.json"), {});
  const k = file,
    c = tagCache[k];
  if (c && c.s === st.size && c.m === Math.floor(st.mtimeMs)) return c;
  const t = readTags(file, name);
  tagCache[k] = { s: st.size, m: Math.floor(st.mtimeMs), title: t.title, artist: t.artist, album: t.album, bpm: t.bpm, key: t.key };
  clearTimeout(tagT);
  tagT = setTimeout(() => writeJson(hubf("cache/tags.json"), tagCache), 2000);
  return tagCache[k];
}
// one walk through a folder collects its music and its videos
async function scanLib(L) {
  const out = { music: [], video: [] };
  const walk = async (dir, rel, names) => {
    let ents;
    try {
      ents = await fsp.readdir(dir, { withFileTypes: !0 });
    } catch {
      return;
    }
    const hint = L.mode === "auto" ? folderHint(names) : "";
    for (const e of ents) {
      if (e.name.startsWith(".") || e.name.startsWith("~$")) continue;
      const full = path.join(dir, e.name),
        r = rel ? rel + "/" + e.name : e.name;
      if (e.isDirectory()) {
        if (names.length >= 14 || SKIP_DIR.test(e.name) || (L.mode === "auto" && PHOTO_DIR.test(e.name))) continue;
        await walk(full, r, [...names, e.name]);
        continue;
      }
      if (e.name.endsWith(".part")) continue;
      const maybe = L.mode === "auto" ? EXT.music.test(e.name) || EXT.video.test(e.name) : EXT[L.mode].test(e.name);
      if (!maybe) continue;
      let st;
      try {
        st = await fsp.stat(full);
      } catch {
        continue;
      }
      const kind = L.mode === "auto" ? autoKind(e.name, st.size, hint) : L.mode;
      if (!kind) continue;
      const t = kind === "music" ? tagsOf(full, st, e.name) : { title: e.name.replace(/\.[^.]+$/, "") };
      out[kind].push({ id: mediaId(kind, L.scope, r), name: e.name, title: t.title, artist: t.artist || "", album: t.album || "", bpm: t.bpm || 0, key: t.key || "", size: st.size, mtime: Math.floor(st.mtimeMs), type: typeOf(e.name), scope: L.scope, where: L.label, folder: rel });
    }
  };
  await walk(L.dir, "", []);
  return out;
}
// a folder's list, from memory when it's recent (and refreshed in the background when older)
async function libItems(L, kind) {
  const c = libCache.get(L.key);
  if (c && Date.now() - c.t > 60000 && !c.busy)
    c.busy = scanLib(L)
      .then((items) => libCache.set(L.key, { t: Date.now(), items }))
      .catch(() => (c.busy = null));
  if (c) return c.items[kind] || [];
  const items = await scanLib(L);
  libCache.set(L.key, { t: Date.now(), items });
  return items[kind] || [];
}
const scanning = new Set();
const forget = (u, kind) => (libCache.delete("u:" + u.id + ":" + kind), libCache.delete("s:" + kind));
async function listMedia(u, kind) {
  const items = [];
  for (const L of libsFor(u, kind)) items.push(...(await libItems(L, kind)));
  return items.sort((a, b) => b.mtime - a.mtime);
}
// folders on the rig, for the owner picking one from another device
function drives() {
  if (process.platform !== "win32") return ["/"];
  const out = [];
  for (let c = 67; c <= 90; c++) {
    const d = String.fromCharCode(c) + ":\\";
    try {
      fs.statSync(d) && out.push(d);
    } catch {}
  }
  return out;
}
function browse(p) {
  if (!p) return { path: "", parent: null, dirs: drives().map((d) => ({ name: d, path: d })) };
  const full = path.resolve(p);
  let ents = [];
  try {
    ents = fs.readdirSync(full, { withFileTypes: !0 });
  } catch (e) {
    throw Object.assign(new Error("Can't open that folder on the rig."), { code: 400 });
  }
  const parent = path.dirname(full) === full ? "" : path.dirname(full);
  return {
    path: full,
    parent,
    dirs: ents
      .filter((e) => e.isDirectory() && !e.name.startsWith(".") && !e.name.startsWith("$") && !/^(system volume information|recovery|perflogs)$/i.test(e.name))
      .map((e) => ({ name: e.name, path: path.join(full, e.name) }))
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(0, 500),
  };
}

// ---- save from a link -----------------------------------------------------------------------------
// A link to a music or video file (one you bought, free or Creative Commons music, a file in your
// own Google Drive or Dropbox) is downloaded by the rig straight into your Music or Videos, so
// big files keep going while your devices are off. Streaming sites are not downloaded from.
const NO_RIP = /(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com|googlevideo\.com|spotify\.com|scdn\.co|soundcloud\.com|sndcdn\.com|music\.apple\.com|tidal\.com|deezer\.com|tiktok\.com|instagram\.com|facebook\.com|fbcdn\.net|twitch\.tv|netflix\.com|primevideo\.com|disneyplus\.com|hulu\.com|pandora\.com|audiomack\.com)$/i;
const TYPE_EXT = { "audio/mpeg": ".mp3", "audio/mp3": ".mp3", "audio/mp4": ".m4a", "audio/x-m4a": ".m4a", "audio/aac": ".aac", "audio/flac": ".flac", "audio/x-flac": ".flac", "audio/wav": ".wav", "audio/x-wav": ".wav", "audio/wave": ".wav", "audio/ogg": ".ogg", "audio/opus": ".opus", "audio/webm": ".weba", "video/mp4": ".mp4", "video/x-m4v": ".m4v", "video/webm": ".webm", "video/quicktime": ".mov", "video/x-matroska": ".mkv", "video/ogg": ".ogv" };
const jobs = new Map();
// share links that open a page turned into the file itself
function directLink(u) {
  const x = new URL(u);
  if (/(^|\.)dropbox\.com$/i.test(x.hostname)) (x.searchParams.delete("dl"), x.searchParams.set("dl", "1"));
  const g = /(^|\.)drive\.google\.com$/i.test(x.hostname) && (/\/file\/d\/([\w-]+)/.exec(x.pathname) || (x.searchParams.get("id") && [0, x.searchParams.get("id")]));
  if (g) return "https://drive.usercontent.google.com/download?id=" + g[1] + "&export=download&confirm=t";
  if (/(^|\.)1drv\.ms$|(^|\.)onedrive\.live\.com$/i.test(x.hostname) && !x.searchParams.has("download")) x.searchParams.set("download", "1");
  return x.toString();
}
async function safeHost(x) {
  if (!/^https?:$/.test(x.protocol)) throw new Error("Only http and https links can be saved.");
  if (NO_RIP.test(x.hostname)) throw new Error("Workbench doesn't download from streaming sites like " + x.hostname.replace(/^www\./, "") + ". Use a direct link to a file you own.");
  if (C.allowLocalFetch) return;
  const addrs = await require("dns").promises.lookup(x.hostname, { all: !0 }).catch(() => {
    throw new Error("Can't find " + x.hostname + ". Check the link.");
  });
  for (const a of addrs) if (/^(127\.|0\.|169\.254\.|::1$|fe80:|::ffff:127\.)/i.test(a.address)) throw new Error("That link points at the rig itself.");
}
function fileName(res, url, kind, type) {
  let n = "";
  const cd = res.headers.get("content-disposition") || "";
  const m = /filename\*=(?:UTF-8'')?([^;]+)/i.exec(cd) || /filename="?([^";]+)"?/i.exec(cd);
  if (m)
    try {
      n = decodeURIComponent(m[1].trim().replace(/^"|"$/g, ""));
    } catch {
      n = m[1];
    }
  if (!n)
    try {
      n = decodeURIComponent(new URL(url).pathname.split("/").filter(Boolean).pop() || "");
    } catch {}
  n = safeName(n) || (kind === "video" ? "Video" : "Song") + " " + new Date().toISOString().slice(0, 10);
  if (!EXT[kind].test(n)) n = n.replace(/\.[a-z0-9]{2,5}$/i, "") + (TYPE_EXT[type] || (kind === "video" ? ".mp4" : ".mp3"));
  return n;
}
async function runJob(job, u) {
  job.state = "downloading";
  const ctl = new AbortController();
  job.cancel = () => ctl.abort();
  let stall = setTimeout(() => ctl.abort(), 60000),
    tmp = "";
  try {
    let url = directLink(job.url),
      res = null;
    for (let hop = 0; hop < 8; hop++) {
      const x = new URL(url);
      await safeHost(x);
      res = await fetch(url, { redirect: "manual", signal: ctl.signal, headers: { "User-Agent": "WorkbenchHub/" + VERSION, Accept: "audio/*,video/*,*/*;q=0.5" } });
      if (res.status >= 300 && res.status < 400 && res.headers.get("location")) {
        url = new URL(res.headers.get("location"), url).toString();
        continue;
      }
      break;
    }
    if (!res || !res.ok) throw new Error("The link answered " + (res ? res.status : "nothing") + ".");
    const type = String(res.headers.get("content-type") || "").split(";")[0].trim().toLowerCase(),
      cd = /filename\*?=(?:UTF-8'')?"?([^";]+)/i.exec(res.headers.get("content-disposition") || ""),
      guess = (cd ? cd[1] : "") + " " + decodeURIComponent(new URL(url).pathname),
      kind = job.to || (/^audio\//.test(type) ? "music" : /^video\//.test(type) ? "video" : /\.(mp3|m4a|aac|flac|wav|ogg|oga|opus|weba|aif|aiff)\b/i.test(guess) ? "music" : /\.(mp4|m4v|webm|mov|mkv|ogv)\b/i.test(guess) ? "video" : "");
    if (/text\/html|application\/xhtml/.test(type)) throw new Error("That link opens a web page, not a file. Use the file's direct download link (it usually ends in .mp3 or .mp4).");
    if (!kind) throw new Error("That isn't a music or video file (it's " + (type || "something else") + ").");
    const name = fileName(res, url, kind, type),
      base = job.shared ? path.join(C.root, "Shared", FOLDER[kind]) : userDir(u, FOLDER[kind]);
    fs.mkdirSync(base, { recursive: !0 });
    let dest = path.join(base, name),
      n = 2;
    while (fs.existsSync(dest)) dest = path.join(base, name.replace(/(\.[^.]+)$/, " (" + n++ + ")$1"));
    Object.assign(job, { kind, name: path.basename(dest), total: +res.headers.get("content-length") || 0, got: 0 });
    tmp = dest + ".part";
    const ws = fs.createWriteStream(tmp);
    for await (const chunk of res.body) {
      clearTimeout(stall);
      stall = setTimeout(() => ctl.abort(), 60000);
      job.got += chunk.length;
      if (!ws.write(chunk)) await new Promise((r) => ws.once("drain", r));
    }
    await new Promise((ok, bad) => (ws.end(ok), ws.on("error", bad)));
    if (!job.got) throw new Error("The link gave an empty file.");
    fs.renameSync(tmp, dest);
    tmp = "";
    job.state = "done";
    job.mediaId = mediaId(kind, job.shared ? "s" : "u", path.basename(dest));
    forget(u, kind);
    log("Saved from a link:", job.name, "for", u.name);
  } catch (e) {
    job.state = "error";
    job.err = e.name === "AbortError" ? (job.cancelled ? "Stopped." : "The download stalled. Try again.") : e.message;
    tmp && fs.rmSync(tmp, { force: !0 });
  } finally {
    clearTimeout(stall);
    job.at = Date.now();
    delete job.cancel;
    broadcast({ type: "media", job: job.id, state: job.state }, (c) => c.user.id === u.id);
    nextJob(u);
  }
}
function nextJob(u) {
  const mine = [...jobs.values()].filter((j) => j.user === u.id);
  if (mine.filter((j) => j.state === "downloading").length >= 2) return;
  const q = mine.find((j) => j.state === "queued");
  q && runJob(q, u);
}
const jobView = (j) => ({ id: j.id, url: j.url, name: j.name, kind: j.kind, got: j.got, total: j.total, state: j.state, err: j.err, mediaId: j.mediaId || "", at: j.at });

// ---- notifications -----------------------------------------------------------------------------
const subject = () => (C.origins && C.origins[0]) || APP;
async function pushTo(d, msg) {
  if (!d.push) return 0;
  try {
    const code = await push.send(d.push, msg, VAPID, subject(), { topic: String(msg.tag || "").replace(/[^A-Za-z0-9_-]/g, "").slice(0, 32) || undefined });
    if (code === 404 || code === 410) ((d.push = null), saveDevices(), log("Push: a device's notifications expired:", d.name));
    else if (code >= 400) log("Push to", d.name, "answered", code);
    return code;
  } catch (e) {
    log("Push to", d.name, "failed:", e.message);
    return 0;
  }
}
const target = (t) => (t.ord ? "ord:" + t.ord : t.co ? "co:" + t.co : "");
const localDay = () => new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
async function checkReminders() {
  const D = readWork();
  if (!D) return;
  const items = __wbReminders(D, Date.now()),
    N = readJson(hubf("notified.json"), { sent: {}, daily: "" }),
    to = DV.devices.filter((d) => d.push && d.notify !== !1 && canWork(U.users.find((u) => u.id === d.user)));
  if (to.length) {
    const fresh = items.filter((t) => t.p >= 50 && !N.sent[t.key]);
    const msgs =
      fresh.length > 3
        ? [{ title: fresh.length + " things need you", body: fresh.slice(0, 3).map((t) => t.text).join(" · ") + "…", tag: "wb-many", open: "bell" }]
        : fresh.map((t) => ({ title: t.text, body: t.sub || "", tag: t.key, open: target(t) }));
    for (const d of to) for (const m of msgs) await pushTo(d, m);
    for (const t of fresh) N.sent[t.key] = Date.now();
    // a morning round-up of everything on the list
    if (new Date().getHours() >= 8 && N.daily !== localDay() && items.length) {
      N.daily = localDay();
      for (const d of to) await pushTo(d, { title: "Today: " + items.length + " thing" + (items.length === 1 ? "" : "s") + " on your list", body: items.slice(0, 3).map((t) => t.text).join(" · "), tag: "wb-daily", open: "bell" });
    }
  }
  for (const k in N.sent) if (Date.now() - N.sent[k] > 45 * 864e5) delete N.sent[k];
  writeJson(hubf("notified.json"), N);
}

// ---- the AI (Ollama on this computer) ----------------------------------------------------------
async function ollama(p, init, ms) {
  const r = await fetch(C.ollama.replace(/\/+$/, "") + p, Object.assign({ signal: AbortSignal.timeout(ms || 180000) }, init || {}));
  if (!r.ok) throw new Error("Ollama answered " + r.status);
  return r.json();
}
async function pickModel() {
  if (C.aiModel) return C.aiModel;
  const t = await ollama("/api/tags", {}, 8000),
    names = (t.models || []).map((m) => m.name);
  return names.find((n) => /^llama3\.1/.test(n)) || names[0] || "";
}
function briefContext(D) {
  const live = (a) => (a || []).filter((r) => r && !r.del),
    co = (id) => live(D.companies).find((c) => c.id === id),
    lines = [];
  for (const o of live(D.orders).filter((o) => !["Done", "Cancelled", "Installed", "Paid"].includes(o.status)).slice(0, 30)) {
    const c = co(o.companyId),
      l = (o.log || [])[0];
    lines.push("- " + [o.no, c ? c.name : "no customer", o.status, o.want ? "wants: " + String(o.want).slice(0, 140) : "", o.due ? "due " + o.due : "", l ? "last update: " + String(l.text).slice(0, 100) : ""].filter(Boolean).join(" | "));
  }
  return lines.join("\n");
}
let digesting = null;
async function makeDigest() {
  if (digesting) return digesting;
  digesting = (async () => {
    const D = readWork();
    if (!D) return null;
    const items = __wbReminders(D, Date.now()),
      biz = (D.settings && D.settings.biz) || {},
      dg = { at: Date.now(), items: items.slice(0, 20).map((t) => ({ key: t.key, kind: t.kind, p: t.p, text: t.text, sub: t.sub, chip: t.chip, cls: t.cls, ord: t.ord, co: t.co })), text: "", model: "", err: "" };
    try {
      const model = await pickModel();
      if (model) {
        const r = await ollama("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            model,
            stream: !1,
            keep_alive: "30m",
            options: { num_ctx: 8192, temperature: 0.3 },
            messages: [
              { role: "system", content: "You write the short hourly briefing for the owner of " + (biz.name || "a small vehicle graphics, decal and wrap shop") + ". Use only the facts given. Name customers and job numbers. One short paragraph of 3 to 5 sentences, no lists, no headings." + (C.lang ? " Write in " + C.lang + "." : "") },
              { role: "user", content: "Now: " + new Date().toString().slice(0, 21) + "\n\nTHE LIST (most important first):\n" + (items.length ? items.slice(0, 15).map((t) => "- " + t.text + (t.sub ? " (" + t.sub + ")" : "")).join("\n") : "- nothing waiting") + "\n\nOPEN JOBS:\n" + (briefContext(D) || "- none") + "\n\nWrite the briefing: what matters most right now and why." },
            ],
          }),
        });
        dg.text = String((r.message && r.message.content) || "")
          .replace(/<think>[\s\S]*?<\/think>/gi, "")
          .trim();
        dg.model = model;
      }
    } catch (e) {
      dg.err = "The AI on the rig didn't answer (" + e.message + ").";
    }
    writeJson(hubf("digest.json"), dg);
    broadcast({ type: "digest", at: dg.at }, (c) => canWork(c.user));
    return dg;
  })().finally(() => (digesting = null));
  return digesting;
}
function proxyOllama(req, res, url) {
  const t = new URL(C.ollama),
    q = new URLSearchParams(url.search);
  q.delete("t");
  const headers = Object.assign({}, req.headers);
  for (const h of ["origin", "referer", "authorization", "host", "cookie"]) delete headers[h];
  for (const h of Object.keys(headers)) if (/^sec-|^access-control-/i.test(h)) delete headers[h];
  const pr = http.request({ hostname: t.hostname, port: t.port || 80, method: req.method, path: (url.pathname.replace(/^\/ollama/, "") || "/") + (q.toString() ? "?" + q : ""), headers }, (r) => {
    const h = Object.assign({}, r.headers);
    for (const k of Object.keys(h)) if (/^access-control-/i.test(k)) delete h[k];
    res.writeHead(r.statusCode, h);
    r.pipe(res);
  });
  pr.on("error", () => fail(res, 502, "The AI isn't running on the rig. On the rig, open Ollama (it starts with Windows once installed), then try again."));
  req.pipe(pr);
}

// ---- updates -----------------------------------------------------------------------------------
const newer = (a, b) => {
  const x = String(a).split(".").map(Number),
    y = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  return !1;
};
// (now: asked for by the owner in Workbench, so it runs even with autoUpdate off and says what happened)
let updating = !1;
async function checkUpdate(now) {
  if ((!C.autoUpdate && now !== !0) || !C.update) return { ok: !1, error: "This Hub has no update address." };
  if (updating) return { ok: !0, updating: !0, latest: UPD.latest };
  updating = !0;
  try {
    const r = await fetch(C.update + "version.json?" + Date.now(), { cache: "no-store", signal: AbortSignal.timeout(20000) });
    if (!r.ok) throw new Error("The update address answered " + r.status);
    const v = await r.json();
    Object.assign(UPD, { checked: Date.now(), latest: String(v.version || ""), err: "" });
    if (!newer(v.version, VERSION)) return { ok: !0, updating: !1, latest: UPD.latest };
    const tmp = path.join(__dirname, ".update");
    fs.rmSync(tmp, { recursive: !0, force: !0 });
    fs.mkdirSync(tmp);
    for (const [name, hash] of Object.entries(v.files || {})) {
      if (!/^[\w.-]+$/.test(name)) throw new Error("bad file name " + name);
      const b = Buffer.from(await (await fetch(C.update + name, { cache: "no-store", signal: AbortSignal.timeout(60000) })).arrayBuffer());
      if (sha(b) !== hash) throw new Error(name + " didn't download correctly");
      fs.writeFileSync(path.join(tmp, name), b);
    }
    for (const name of Object.keys(v.files)) fs.copyFileSync(path.join(tmp, name), path.join(__dirname, name));
    fs.rmSync(tmp, { recursive: !0, force: !0 });
    log("Updated to", v.version, "- restarting");
    try {
      pubEvent("update", "Hub updated to " + v.version, "");
    } catch {}
    setTimeout(() => process.exit(3), 800);
    return { ok: !0, updating: !0, latest: UPD.latest };
  } catch (e) {
    Object.assign(UPD, { checked: Date.now(), err: e.message });
    log("Update check:", e.message);
    return { ok: !1, error: e.message };
  } finally {
    updating = !1;
  }
}

// ---- the status page (what you see opening the Hub's address in a browser) ---------------------
function statusPage(req, res) {
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]),
    work = readWorkText(),
    html =
      '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Workbench Hub</title><style>body{margin:0;background:#101114;color:#eef1f5;font:15px/1.5 system-ui,Segoe UI,sans-serif}main{max-width:640px;margin:8vh auto;padding:0 20px}h1{font-size:34px;margin:0 0 4px;letter-spacing:-.01em}.k{color:#9aa2ae;text-transform:uppercase;font-size:12px;letter-spacing:.16em}.ok{color:#7dffa8}ul{padding-left:18px}a{color:#7dffa8}code{background:#1d2026;padding:2px 6px}</style><main><div class="k">// Workbench Hub ' +
      VERSION +
      '</div><h1>Running <span class="ok">●</span></h1><p>This is your Workbench home server. Open Workbench on any of your devices and connect to this address: the menu at the top right → Hub.</p><ul><li>' +
      U.users.length +
      " people · " +
      DV.devices.length +
      " devices signed in</li><li>Work data: " +
      (work ? Math.round(work.length / 1024) + " KB" : "none yet") +
      '</li></ul><p><a href="' +
      APP +
      '/Workbench/">Open Workbench</a></p></main>';
  res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
  res.end(html);
}

// ---- the rig's health (the Rig tab in Workbench) -------------------------------------------------
// Only what's safe on a screen other people look at: no addresses, paths, drive letters, driver
// versions, programs on the graphics card or the private network (1.2.1).
const { execFile } = require("child_process");
const STARTED = Date.now();
const UPD = { checked: 0, latest: "", err: "" };
// run a program on the rig and give back what it printed, or "" if it isn't there
function runOut(cmds, args, ms) {
  return new Promise((done) => {
    const list = [].concat(cmds),
      next = (i) => {
        if (i >= list.length) return done("");
        execFile(list[i], args, { timeout: ms || 4000, windowsHide: !0, maxBuffer: 4e6 }, (e, out) => (e && !out ? next(i + 1) : done(String(out || ""))));
      };
    next(0);
  });
}
const WIN = process.platform === "win32";
const NVSMI = WIN ? ["nvidia-smi", "C:\\Windows\\System32\\nvidia-smi.exe", "C:\\Program Files\\NVIDIA Corporation\\NVSMI\\nvidia-smi.exe"] : ["nvidia-smi"];
const num = (s) => {
  const n = parseFloat(String(s).trim());
  return isFinite(n) ? n : null;
};
// how busy the processor is: the share of time not idle since the last look
let cpuPrev = null;
function cpuNow() {
  const t = os.cpus().map((c) => c.times),
    sum = t.reduce((a, x) => ((a.idle += x.idle), (a.all += x.user + x.nice + x.sys + x.idle + x.irq), a), { idle: 0, all: 0 });
  return sum;
}
async function cpuBusy() {
  let a = cpuPrev;
  if (!a || Date.now() - a.at > 30000) ((a = Object.assign(cpuNow(), { at: Date.now() })), await new Promise((z) => setTimeout(z, 400)));
  const b = Object.assign(cpuNow(), { at: Date.now() });
  if (b.at - a.at < 400) return cpuPrev.pct;
  const pct = b.all > a.all ? Math.max(0, Math.min(100, Math.round((100 * (1 - (b.idle - a.idle) / (b.all - a.all))) * 10) / 10)) : 0;
  cpuPrev = Object.assign(b, { pct });
  return pct;
}
// the graphics card, from NVIDIA's own tool (cached a couple of seconds)
const gpuC = { t: 0, v: null, p: null };
async function gpuInfo() {
  if (Date.now() - gpuC.t < 2500) return gpuC.v;
  if (gpuC.p) return gpuC.p;
  return (gpuC.p = (async () => {
    const out = await runOut(NVSMI, ["--query-gpu=name,temperature.gpu,utilization.gpu,memory.used,memory.total,power.draw,power.limit,fan.speed", "--format=csv,noheader,nounits"], 5000);
    let cards = out
      .split(/\r?\n/)
      .filter((l) => l.trim())
      .map((l) => {
        const f = l.split(",").map((x) => x.trim());
        return { name: f[0], temp: num(f[1]), busy: num(f[2]), memUsed: num(f[3]), memTotal: num(f[4]), power: num(f[5]), powerMax: num(f[6]), fan: num(f[7]) };
      });
    gpuC.v = cards.length ? cards : null;
    gpuC.t = Date.now();
    gpuC.p = null;
    return gpuC.v;
  })());
}
// the AI (Ollama): is it up, which models it has, which one sits in memory now
async function aiGet(p, ms) {
  try {
    const r = await fetch(C.ollama.replace(/\/+$/, "") + p, { signal: AbortSignal.timeout(ms || 1500) });
    return r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}
async function aiInfo() {
  const [v, tags, ps] = await Promise.all([aiGet("/api/version"), aiGet("/api/tags"), aiGet("/api/ps")]);
  if (!v && !tags) return { up: !1 };
  return {
    up: !0,
    version: (v && v.version) || "",
    models: ((tags && tags.models) || []).map((m) => ({ name: m.name, size: m.size, at: Date.parse(m.modified_at) || 0, params: (m.details && m.details.parameter_size) || "", quant: (m.details && m.details.quantization_level) || "" })),
    loaded: ((ps && ps.models) || []).map((m) => ({ name: m.name, size: m.size, vram: m.size_vram, until: Date.parse(m.expires_at) || 0 })),
    model: C.aiModel || "",
  };
}
async function aiKeep(model, load) {
  const r = await fetch(C.ollama.replace(/\/+$/, "") + "/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ model, keep_alive: load ? "30m" : 0 }), signal: AbortSignal.timeout(load ? 120000 : 15000) }).catch(() => null);
  if (!r) throw Object.assign(new Error("The AI isn't running on the rig."), { code: 502 });
  if (!r.ok) throw Object.assign(new Error("The AI said no: " + ((await r.text().catch(() => "")) || r.status).slice(0, 200)), { code: 502 });
  await r.text().catch(() => "");
}
// is this request coming from the rig itself? (the Hub only listens on the rig; Tailscale says who
// is on the other end in X-Forwarded-For, and the rig's own addresses mean it's the rig)
function localAddrs() {
  const s = new Set(["127.0.0.1", "::1"]);
  for (const l of Object.values(os.networkInterfaces())) for (const a of l || []) s.add(String(a.address).replace(/^::ffff:/, "").replace(/%.*$/, ""));
  return s;
}
function fromRig(req) {
  // through the "use from anywhere" door it's never the rig, whatever the addresses say
  if (req.wbRemote) return !1;
  const L = localAddrs(),
    ra = String(req.socket.remoteAddress || "").replace(/^::ffff:/, "");
  if (!L.has(ra)) return !1;
  const xf = String(req.headers["x-forwarded-for"] || "")
    .split(",")
    .map((s) => s.trim().replace(/^::ffff:/, "").replace(/^\[|\]$/g, ""))
    .filter(Boolean);
  if (!xf.length) return !(req.headers["x-forwarded-host"] || req.headers["tailscale-user-login"]);
  return xf.every((ip) => L.has(ip));
}
// the owner on the rig itself, or on a phone the owner paired as a Rig Remote (1.5.0)
const rigCtl = (req, a) => a.user.role === "owner" && (fromRig(req) || !!(a.device && a.device.remote));
// the rig itself only (the keys, pairing codes and who may be a Rig Remote): never a phone, never the
// anywhere door. (1.6.0: a paired Rig Remote can change everything else the rig's own screen can.)
const rigAdmin = (req, a) => a.user.role === "owner" && fromRig(req);
const ctlNo = (res) => fail(res, 403, "Only on the rig, or on a phone you paired as a Rig Remote.");
const adminNo = (res) => fail(res, 403, "Only on the rig itself.");
function diskList() {
  const root = path.resolve(C.root).toLowerCase(),
    out = [];
  for (const d of drives())
    try {
      const s = fs.statfsSync(d);
      out.push({ free: s.bavail * s.bsize, size: s.blocks * s.bsize, hub: root.startsWith(d.toLowerCase()) && (d !== "/" || out.length === 0) });
    } catch {}
  return out;
}
function lastBackup() {
  let best = null;
  for (const dir of [hubf("backups"), C.backupDir ? path.join(C.backupDir, "Workbench Hub backups") : ""].filter(Boolean))
    try {
      for (const f of fs.readdirSync(dir))
        if (/^work-.*\.json$/.test(f)) {
          const st = fs.statSync(path.join(dir, f));
          if (!best || st.mtimeMs > best.at) best = { at: st.mtimeMs, name: f, size: st.size, second: dir !== hubf("backups") };
        }
    } catch {}
  return best;
}
// who uses the Hub: people, their devices, and who is here right now
function usage() {
  const now = Date.now(),
    on = new Set([...live].map((c) => c.device.id)),
    devs = DV.devices.map((d) => {
      const x = U.users.find((y) => y.id === d.user);
      return { id: d.id, name: d.name, user: x ? x.name : "?", seen: d.seen || 0, online: on.has(d.id), push: !!d.push, created: d.created || 0 };
    }),
    act = (ms) => new Set(devs.filter((d) => d.online || now - d.seen < ms).map((d) => d.user)).size;
  return {
    people: U.users.length,
    devices: devs.length,
    online: devs.filter((d) => d.online).length,
    peopleOnline: act(0),
    today: act(864e5),
    week: act(7 * 864e5),
    month: act(30 * 864e5),
    list: devs.sort((a, b) => b.online - a.online || b.seen - a.seen),
  };
}
async function systemInfo(req) {
  const [cpu, gpu, ai] = await Promise.all([cpuBusy(), gpuInfo(), aiInfo()]),
    c0 = os.cpus()[0] || {},
    mem = process.memoryUsage();
  const libs = libraries().map((l) => {
    const c = libCache.get("l:" + l.id);
    let exists = !1;
    try {
      exists = fs.statSync(l.path).isDirectory();
    } catch {}
    return { everyone: !!l.everyone, exists, music: c ? c.items.music.length : null, video: c ? c.items.video.length : null };
  });
  return {
    at: Date.now(),
    rig: fromRig(req),
    machine: { os: WIN ? "Windows " + os.release() : os.type() + " " + os.release(), arch: os.arch(), up: Math.round(os.uptime()) },
    cpu: { model: String(c0.model || "").replace(/\s+/g, " ").trim(), cores: os.cpus().length, busy: cpu, speed: c0.speed || 0 },
    ram: { total: os.totalmem(), free: os.freemem() },
    disks: diskList(),
    gpu,
    ai,
    usage: usage(),
    libraries: libs,
    backup: lastBackup(),
    jobs: [...jobs.values()].filter((j) => j.state === "downloading" || j.state === "queued").length,
    hub: { version: VERSION, up: Math.round((Date.now() - STARTED) / 1000), node: process.version, mem: mem.rss, autoUpdate: !!C.autoUpdate, update: { checked: UPD.checked, latest: UPD.latest } },
  };
}

// ---- Discover and Spotlight: what the website shows everyone (1.3.0) ------------------------------
// Companies, their applications and messages, and the Spotlight artist and tracks live on the rig
// (.hub/public.json and the Public folder). "Publish" puts what's live and approved on the
// Workbench website through GitHub, so visitors see it even while the rig is off. A small public
// door, the inbox (its own port, shared to the internet with Tailscale Funnel), only takes company
// applications and messages to companies; nothing else on the rig is reachable through it.
const PUBDIR = () => path.join(C.root, "Public");
let P = null;
function pubLoad() {
  if (!P) {
    P = Object.assign({ companies: [], apps: [], msgs: [], artist: { name: "", bio: "", photo: "", socials: {} }, tracks: [], published: { at: 0, commit: "", files: {} }, radioEpoch: 0, forms: null, responses: [], events: [], changedAt: 0 }, readJson(hubf("public.json"), {}));
    // 1.4.0: ready-made forms, and 1.3.0's applications become answers to the company sign-up form
    if (!Array.isArray(P.forms)) P.forms = formDefaults();
    const cf = P.forms.find((f) => f.kind === "company");
    if (cf && P.apps.length) {
      for (const a of P.apps)
        P.responses.push({ id: a.id, form: cf.id, slug: cf.slug, title: cf.title, kind: "company", at: a.at, files: a.logo ? { logo: a.logo } : {}, status: "new", items: cf.fields.map((q) => ({ id: q.id, label: q.label, type: q.type, map: q.map, value: q.map === "logo" ? a.logo || "" : q.map === "instagram" || q.map === "tiktok" || q.map === "facebook" ? (a.socials || {})[q.map] || "" : a[q.map] || "" })) });
      P.apps = [];
    }
    // 1.5.0: a form is on the website only after Post. Forms that went up with an earlier publish
    // count as posted; if nothing was ever published, none are.
    if (!Array.isArray(P.trails)) P.trails = [];
    for (const c of P.companies) c.stamp = c.stamp || newStamp();
    if (!P.postModel) {
      P.postModel = 1;
      const pb = P.published || (P.published = { at: 0, commit: "", files: {} }),
        before = !!(pb.at && pb.forms > 0);
      pb.formU = pb.formU || {};
      for (const f of P.forms)
        if (before && f.open && (f.u || 0) <= pb.at) pb.formU[f.id] = f.u || f.at || 1;
        else if (!before) f.open = !1;
    }
    writeJson(hubf("public.json"), P);
  }
  return P;
}
// every change remembers when it happened, so the Rig tab can say "not published yet"
const pubSave = () => ((P.changedAt = Date.now()), writeJson(hubf("public.json"), P));
const clip = (v, n) => String(v ?? "").replace(/[\u0000-\u001f]/g, " ").trim().slice(0, n);
const webUrl = (u) => (/^https?:\/\/[^\s<>"']+$/i.test(String(u || "").trim()) ? String(u).trim().slice(0, 300) : "");
const SOCIALS = ["instagram", "tiktok", "facebook", "youtube", "x", "whatsapp", "soundcloud", "spotify"];
function slugOf(s) {
  return (
    String(s || "")
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 40) || "company"
  );
}
function uniqueSlug(name, id) {
  let s = slugOf(name),
    n = 2,
    t = s;
  while (pubLoad().companies.some((c) => c.slug === t && c.id !== id)) t = s + "-" + n++;
  return t;
}
function socialsOf(b) {
  const o = {};
  for (const k of SOCIALS) b && b[k] && webUrl(b[k]) && (o[k] = webUrl(b[k]));
  return o;
}
function companyFields(c, b) {
  for (const [k, n] of [["category", 40], ["description", 1500], ["city", 80], ["address", 160], ["phone", 40], ["email", 120], ["deal", 200], ["code", 40]]) k in b && (c[k] = clip(b[k], n));
  "website" in b && (c.website = webUrl(b.website));
  "socials" in b && (c.socials = socialsOf(b.socials));
  return c;
}
function companySave(b) {
  const L = pubLoad().companies,
    old = b.id && L.find((x) => x.id === b.id),
    c = old || { id: id36(), at: Date.now(), live: !0, featured: !1 },
    name = clip(b.name, 80) || c.name;
  if (!name) throw Object.assign(new Error("A company needs a name."), { code: 400 });
  if (!old || name !== c.name) c.slug = uniqueSlug(name, c.id);
  c.name = name;
  c.stamp = c.stamp || newStamp();
  companyFields(c, b);
  "featured" in b && (c.featured = !!b.featured);
  "live" in b && (c.live = !!b.live);
  c.u = Date.now();
  old || L.push(c);
  pubSave();
  return c;
}
// a picture or a song saved under its own fingerprint, so publishing never sends one twice
const PUBTYPES = { png: "img", jpg: "img", jpeg: "img", webp: "img", mp3: "song", m4a: "song", aac: "song", ogg: "song", oga: "song", opus: "song", wav: "song", flac: "song" };
async function pubFile(req, name, kind) {
  const ext = path.extname(String(name || "")).slice(1).toLowerCase();
  if (PUBTYPES[ext] !== (kind === "song" ? "song" : "img")) throw Object.assign(new Error(kind === "song" ? "Send an MP3, M4A, OGG, WAV or FLAC file." : "Send a PNG, JPG or WEBP picture."), { code: 400 });
  const max = kind === "song" ? 80e6 : 6e6;
  if (+req.headers["content-length"] > max) throw Object.assign(new Error(kind === "song" ? "Songs up to 80 MB." : "Pictures up to 6 MB."), { code: 400 });
  const tmp = path.join(PUBDIR(), ".in-" + id36());
  const size = await receive(req, tmp);
  if (size > max) throw (await fsp.rm(tmp, { force: !0 }), Object.assign(new Error("That file is too big."), { code: 400 }));
  const file = sha(fs.readFileSync(tmp)).slice(0, 16) + "." + (ext === "jpeg" ? "jpg" : ext);
  await fsp.rename(tmp, path.join(PUBDIR(), file));
  return file;
}
function pubFromB64(b64, mime) {
  const ext = { "image/png": "png", "image/jpeg": "jpg", "image/webp": "webp" }[mime];
  if (!ext || !b64) return "";
  const buf = Buffer.from(String(b64), "base64");
  if (!buf.length || buf.length > 1.5e6) return "";
  const file = sha(buf).slice(0, 16) + "." + ext;
  fs.mkdirSync(PUBDIR(), { recursive: !0 });
  fs.writeFileSync(path.join(PUBDIR(), file), buf);
  return file;
}
// tell the owner's devices
function pubNotify(title, body, kind, ref, acts) {
  pubEvent(kind || "note", title, body, ref);
  trayNote(title, body);
  const owners = new Set(U.users.filter((u) => u.role === "owner").map((u) => u.id)),
    open = ref && (kind === "form" || kind === "message" || kind === "remote") ? "rig:" + (kind === "form" ? "resp" : kind === "message" ? "msg" : "remote") + ":" + ref : "rig";
  for (const d of DV.devices) {
    if (!owners.has(d.user) || !d.push) continue;
    const m = { title, body, tag: "pub-" + (ref || "x"), open };
    // a paired Rig Remote gets buttons (Approve, Done…) that work without opening Workbench
    if (d.remote && acts && acts.length && d.via) {
      const k = crypto.randomBytes(18).toString("base64url");
      ACTS.set(k, { dev: d.id, kind, ref, acts: acts.map((x) => x[0]), exp: Date.now() + 3 * 864e5 });
      m.actions = acts.slice(0, 2).map(([action, t]) => ({ action, title: t }));
      m.act = { k, url: d.via };
    }
    pushTo(d, m);
  }
  broadcast({ type: "pub" }, (c) => c.user.role === "owner");
}
// one-time keys behind the buttons on a Rig Remote's notifications
const ACTS = new Map();
setInterval(() => {
  for (const [k, v] of ACTS) v.exp < Date.now() && ACTS.delete(k);
}, 3600000).unref();
function actDo(b) {
  const A = ACTS.get(String(b.k || "")),
    d = A && DV.devices.find((x) => x.id === A.dev);
  if (!A || A.exp < Date.now() || !d || !d.remote) throw Object.assign(new Error("That button has expired. Open Workbench to decide."), { code: 410 });
  const what = String(b.do || "");
  if (!A.acts.includes(what)) throw Object.assign(new Error("Not that one."), { code: 400 });
  ACTS.delete(String(b.k));
  const S = pubLoad();
  if (A.kind === "form") {
    const r = S.responses.find((x) => x.id === A.ref);
    if (!r) throw Object.assign(new Error("That answer is gone."), { code: 404 });
    let made = null;
    if (what === "approve") (r.kind === "company" && (made = responseToCompany(r)), (r.status = "approved"), pubEvent("company", made ? made.name + " is in Discover" : "Approved: " + r.title, made ? "Publish to put it on the website." : "", r.id));
    else r.status = what === "decline" ? "declined" : "done";
    r.decided = Date.now();
    writeJson(hubf("public.json"), S);
    broadcast({ type: "pub" }, (c) => c.user.role === "owner");
    log("Decided from a notification:", what, r.title);
    return { ok: !0, text: what === "approve" ? (made ? made.name + " is in Discover. Publish to put it on the website." : "Approved.") : what === "decline" ? "Turned down." : "Done." };
  }
  if (A.kind === "message") {
    S.msgs = S.msgs.filter((x) => x.id !== A.ref);
    writeJson(hubf("public.json"), S);
    broadcast({ type: "pub" }, (c) => c.user.role === "owner");
    return { ok: !0, text: "Marked as passed on." };
  }
  throw Object.assign(new Error("Not that one."), { code: 400 });
}
// ---- publishing to the website through GitHub
const ghTok = () => readJson(hubf("github.json"), {}).token || "";
async function gh(p, o) {
  const cfg = C.publish || {},
    r = await fetch((process.env.WB_GH_API || "https://api.github.com") + (p.startsWith("/repos") || p.startsWith("/user") ? p : "/repos/" + cfg.repo + p), {
      method: (o && o.method) || "GET",
      headers: { Authorization: "Bearer " + ((o && o.token) || ghTok()), Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "WorkbenchHub/" + VERSION, "Content-Type": "application/json" },
      body: o && o.body ? JSON.stringify(o.body) : void 0,
      signal: AbortSignal.timeout((o && o.ms) || 60000),
    });
  const t = await r.text();
  let j = null;
  try {
    j = JSON.parse(t);
  } catch {}
  if (!r.ok) throw Object.assign(new Error("GitHub said " + r.status + ": " + ((j && j.message) || t).slice(0, 160)), { code: 502, status: r.status, ghMsg: String((j && j.message) || "") });
  return j;
}
// what GitHub's "no" means, in plain words (null when it isn't about the key)
function ghPlain(e, repo) {
  const st = e && e.status,
    m = String((e && e.ghMsg) || ""),
    fix = "On github.com: your picture → Settings → Developer settings → Personal access tokens → Fine-grained tokens → the Workbench rig key → Edit. Under Repository access pick Only select repositories → " + (String(repo || "").split("/")[1] || "workbench") + ", and under Repository permissions set Contents to Read and write → Update. Then press Post again (the same key keeps working).";
  if (st === 401) return "GitHub says the key is wrong or has expired. Make a new key (Fine-grained tokens → Generate new token) and paste it here.";
  if (st === 403 && /rate limit/i.test(m)) return "";
  if (st === 403 || (st === 404 && /not found/i.test(m))) return "The key can look at the website's repository but can't change it. " + fix;
  return "";
}
async function pubSetup(b) {
  const repo = clip(b.repo, 120).replace(/^https?:\/\/github\.com\//i, "").replace(/\.git$|\/+$/g, ""),
    token = clip(b.token, 300);
  if (!/^[\w.-]+\/[\w.-]+$/.test(repo)) throw Object.assign(new Error("The repository looks like owner/name, for example you/workbench."), { code: 400 });
  if (!token) throw Object.assign(new Error("Paste the GitHub key (token)."), { code: 400 });
  let info;
  try {
    info = await gh("/repos/" + repo, { token });
  } catch (e) {
    throw Object.assign(new Error(e.status === 404 ? "GitHub can't find " + repo + " with this key. Check the name, and that the key's Repository access includes it." : ghPlain(e, repo) || e.message), { code: 400 });
  }
  if (!info.permissions || !info.permissions.push) throw Object.assign(new Error("That key can't write to " + repo + ". Give it Contents: Read and write."), { code: 400 });
  // (that answer is about the account, not the key: make sure the key itself can write, with a
  // tiny file GitHub keeps nowhere visible)
  try {
    await gh("/repos/" + repo + "/git/blobs", { method: "POST", token, body: { content: Buffer.from("Workbench can publish here.\n").toString("base64"), encoding: "base64" } });
  } catch (e) {
    throw Object.assign(new Error(ghPlain(e, repo) || e.message), { code: 400 });
  }
  writeJson(hubf("github.json"), { token });
  C.publish = { repo, branch: clip(b.branch, 60) || info.default_branch || "main", dir: "public" };
  writeJson(CONF, C);
  log("Publishing set up for", repo);
  return { repo, branch: C.publish.branch };
}
function pubData() {
  const S = pubLoad(),
    m = (f) => (f ? "media/" + f : ""),
    live = S.companies.filter((c) => c.live !== !1),
    tracks = S.tracks.filter((t) => t.status === "approved" && t.file);
  S.radioEpoch ||= Date.now();
  return {
    v: 1,
    at: Date.now(),
    inbox: C.inbox && C.inboxUrl ? C.inboxUrl : "",
    google: (C.google && C.google.clientId) || "",
    trails: (S.trails || []).filter((t) => t.on !== !1 && t.stops.length >= 2).map((t) => ({ id: t.id, title: t.title, desc: t.desc || "", reward: t.reward || "", stops: t.stops.filter((x) => live.some((c) => c.slug === x)) })),
    today: S.dayCo && live.some((c) => c.slug === S.dayCo.slug) ? S.dayCo : null,
    stats: Object.fromEntries(live.map((c) => [c.slug, trfSum("co", c.slug, 30)]).filter((x) => x[1] >= 5)),
    forms: (S.forms || []).filter((f) => f.open).map((f) => ({ slug: f.slug, title: f.title, desc: f.desc || "", kind: f.kind, fields: f.fields.map((q) => ({ id: q.id, type: q.type, label: q.label, help: q.help, req: q.req, opts: q.opts })) })),
    companies: live.map((c) => ({ id: c.id, slug: c.slug, sh2: stampHash(c.slug, c.stamp), posts: (c.posts || []).slice(0, 5).map((x) => ({ at: x.at, text: x.text })), name: c.name, category: c.category || "", description: c.description || "", city: c.city || "", address: c.address || "", phone: c.phone || "", email: c.email || "", website: c.website || "", socials: c.socials || {}, deal: c.deal || "", code: c.code || "", featured: !!c.featured, logo: m(c.logo) })),
    spotlight: tracks.length || S.artist.name ? { artist: { name: S.artist.name || "", bio: S.artist.bio || "", photo: m(S.artist.photo), socials: S.artist.socials || {} }, epoch: S.radioEpoch, tracks: tracks.map((t) => ({ id: t.id, title: t.title, dur: t.dur || 0, file: m(t.file), cover: m(t.cover), at: t.at })) } : null,
  };
}
let publishing = null;
async function publish() {
  if (publishing) return publishing;
  return (publishing = publishRun()
    .then((r) => (C.publish && C.publish.keyErr && (delete C.publish.keyErr, writeJson(CONF, C)), r))
    .catch((e) => {
      // a key that can't change the repository: say how to fix it, and keep it on the Forms page
      const plain = ghPlain(e, C.publish && C.publish.repo);
      if (!plain) throw e;
      C.publish && ((C.publish.keyErr = plain), writeJson(CONF, C));
      log("Publish refused by GitHub:", e.message);
      throw Object.assign(new Error(plain), { code: 400 });
    })
    .finally(() => (publishing = null)));
}
function publishRun() {
  return (async () => {
    const cfg = C.publish;
    if (!cfg || !cfg.repo || !ghTok()) throw Object.assign(new Error("Set up publishing first (the GitHub key)."), { code: 400 });
    const S = pubLoad(),
      data = pubData(),
      dir = cfg.dir || "public",
      want = new Set();
    for (const c of data.companies) c.logo && want.add(c.logo.slice(6));
    if (data.spotlight) {
      data.spotlight.artist.photo && want.add(data.spotlight.artist.photo.slice(6));
      for (const t of data.spotlight.tracks) (want.add(t.file.slice(6)), t.cover && want.add(t.cover.slice(6)));
    }
    const ref = await gh("/git/ref/heads/" + cfg.branch),
      base = ref.object.sha,
      commit = await gh("/git/commits/" + base),
      tree = [],
      sent = Object.assign({}, S.published.files);
    for (const f of want) {
      const p = dir + "/media/" + f;
      if (sent[p]) continue;
      const blob = await gh("/git/blobs", { method: "POST", body: { content: fs.readFileSync(path.join(PUBDIR(), f)).toString("base64"), encoding: "base64" }, ms: 600000 });
      tree.push({ path: p, mode: "100644", type: "blob", sha: blob.sha });
      sent[p] = blob.sha;
    }
    tree.push({ path: dir + "/data.json", mode: "100644", type: "blob", content: JSON.stringify(data) });
    const nt = await gh("/git/trees", { method: "POST", body: { base_tree: commit.tree.sha, tree } }),
      nc = await gh("/git/commits", { method: "POST", body: { message: "Workbench: publish Discover and Spotlight", tree: nt.sha, parents: [base] } });
    await gh("/git/refs/heads/" + cfg.branch, { method: "PATCH", body: { sha: nc.sha } });
    S.published = { at: Date.now(), commit: nc.sha, files: sent, companies: data.companies.length, tracks: data.spotlight ? data.spotlight.tracks.length : 0, forms: data.forms.length, formU: Object.fromEntries((S.forms || []).filter((f) => f.open).map((f) => [f.id, f.u || f.at || 1])) };
    delete S.inboxMoved;
    writeJson(hubf("public.json"), S);
    pubEvent("publish", "Published to the website", data.companies.length + " companies, " + S.published.tracks + " songs, " + data.forms.length + " forms");
    log("Published", data.companies.length, "companies and", S.published.tracks, "tracks");
    return S.published;
  })();
}
// ---- the public inbox (Tailscale Funnel → 127.0.0.1:8771)
function runAll(cmds, args, ms) {
  return new Promise((done) => {
    const list = [].concat(cmds),
      next = (i) => {
        if (i >= list.length) return done({ ok: !1, out: "Tailscale isn't installed or didn't answer." });
        execFile(list[i], args, { timeout: ms || 20000, windowsHide: !0 }, (e, out, err) => (e && e.code === "ENOENT" ? next(i + 1) : done({ ok: !e, out: (String(out || "") + "\n" + String(err || "")).trim() })));
      };
    next(0);
  });
}
const TSCLI = WIN ? ["tailscale", "C:\\Program Files\\Tailscale\\tailscale.exe"] : ["tailscale"];
async function inboxSet(on) {
  const port = C.inboxPort || 8771,
    r = await runAll(TSCLI, on ? ["funnel", "--bg", "--https=8443", "http://127.0.0.1:" + port] : ["funnel", "--https=8443", "off"]);
  let host = "";
  if (on) {
    try {
      host = String(JSON.parse((await runAll(TSCLI, ["status", "--json"], 8000)).out).Self.DNSName || "").replace(/\.$/, "");
    } catch {}
  }
  C.inbox = !!(on && r.ok);
  C.inboxUrl = C.inbox && host ? "https://" + host + ":8443" : "";
  writeJson(CONF, C);
  log("Inbox", C.inbox ? "on at " + C.inboxUrl : "off");
  return { on: C.inbox, url: C.inboxUrl, out: r.out.slice(0, 600) };
}
// ---- 1.9.0: keep the inbox alive (visitor counts, forms, messages all arrive through it) ----------------
// Every 10 minutes: does Tailscale still give this rig the address the website was told? Does the inbox
// answer from outside? If the Funnel was switched off (an update, a restart) it is switched on again.
// A moved address is picked up and the website is marked as needing a publish; an inbox that stays
// silent is shown on Rig Start. (Tests point WB_INBOX_SELF at the local inbox instead of the public one.)
const IBH = { at: 0, ok: null, msg: "" };
async function inboxProbe() {
  const base = process.env.WB_INBOX_SELF || C.inboxUrl;
  try {
    const r = await fetch(base.replace(/\/+$/, "") + "/ping", { signal: AbortSignal.timeout(7000), cache: "no-store" });
    return r.ok;
  } catch {
    return !1;
  }
}
async function inboxWatch() {
  if (!C.inbox) return void Object.assign(IBH, { at: Date.now(), ok: null, msg: "" });
  let host = "";
  try {
    host = String(JSON.parse((await runAll(TSCLI, ["status", "--json"], 8000)).out).Self.DNSName || "").replace(/\.$/, "");
  } catch {}
  const url = host ? "https://" + host + ":8443" : "";
  if (url && url !== C.inboxUrl) {
    log("Inbox address changed; the website needs a publish");
    C.inboxUrl = url;
    writeJson(CONF, C);
    const S = pubLoad();
    S.inboxMoved = !0;
    pubSave();
    pubEvent("publish", "The rig's address changed", "Publish so visitor counts and forms reach the rig again.");
  }
  let ok = await inboxProbe();
  if (!ok) {
    await runAll(TSCLI, ["funnel", "--bg", "--https=8443", "http://127.0.0.1:" + (C.inboxPort || 8771)]);
    ok = await inboxProbe();
  }
  const was = IBH.ok;
  Object.assign(IBH, { at: Date.now(), ok, msg: ok ? "" : "The inbox doesn't answer from the internet. Visitor counts and forms are paused. Check that Tailscale is running on the rig." });
  if (was !== !1 && !ok) pubEvent("note", "The inbox isn't answering", IBH.msg);
  if (was === !1 && ok) pubEvent("note", "The inbox is back", "Visitor counts and forms are coming through again.");
}
// ---- 1.12.0: Google accounts: people's progress kept on the rig ------------------------------------
// Someone signs in with Google on the website; Google proves who they are (a signed ID token the rig checks
// against Google's public keys) and the rig keeps their Workbench progress: profile, settings, scores and
// notes, never Block World worlds (those stay on their device). One file per person, 5 MB at most, plus the
// version before the last save. People are known by Google's permanent id, not their email.
const GCERTS = process.env.WB_GOOGLE_CERTS || "https://www.googleapis.com/oauth2/v3/certs";
const ACCT_MAX = 5e6;
let gKeys = { at: 0, keys: [] };
async function googleKeys(force) {
  if (!force && Date.now() - gKeys.at < 3600000 && gKeys.keys.length) return gKeys.keys;
  let r;
  try {
    r = await fetch(GCERTS, { signal: AbortSignal.timeout(8000) });
  } catch {}
  if (!r || !r.ok) throw Object.assign(new Error("Google didn't answer. Try again in a minute."), { code: 502 });
  gKeys = { at: Date.now(), keys: (await r.json()).keys || [] };
  return gKeys.keys;
}
const b64u = (s) => Buffer.from(String(s).replace(/-/g, "+").replace(/_/g, "/"), "base64");
async function googleVerify(tok) {
  const id = C.google && C.google.clientId,
    no = (m) => Object.assign(new Error(m || "That sign-in didn't work. Try again."), { code: 401 });
  if (!id) throw Object.assign(new Error("Google sign-in isn't switched on for this rig yet."), { code: 400 });
  const parts = String(tok || "").split(".");
  if (parts.length !== 3 || String(tok).length > 4096) throw no();
  let h, p;
  try {
    h = JSON.parse(b64u(parts[0]).toString("utf8"));
    p = JSON.parse(b64u(parts[1]).toString("utf8"));
  } catch {
    throw no();
  }
  if (h.alg !== "RS256" || !h.kid) throw no();
  let k = (await googleKeys()).find((x) => x.kid === h.kid);
  k || (k = (await googleKeys(!0)).find((x) => x.kid === h.kid));
  if (!k) throw no();
  let ok = !1;
  try {
    ok = crypto.verify("RSA-SHA256", Buffer.from(parts[0] + "." + parts[1]), crypto.createPublicKey({ key: k, format: "jwk" }), b64u(parts[2]));
  } catch {}
  if (!ok) throw no();
  if (!["accounts.google.com", "https://accounts.google.com"].includes(p.iss) || p.aud !== id || !(p.exp * 1000 > Date.now() - 60000) || !p.sub) throw no("That sign-in has run out or isn't for this site. Try again.");
  if (p.email_verified === !1) throw no("That Google account's email isn't verified yet.");
  return { sub: String(p.sub), email: clip(p.email, 200), name: clip(p.name || p.given_name || "", 80) };
}
const acctId = (sub) => sha("google:" + sub).slice(0, 32);
const acctFile = (id, prev) => path.join(hubf("accounts"), id + (prev ? ".prev" : "") + ".json");
const acctIndex = () => readJson(hubf("accounts.json"), { list: [] });
function acctKey() {
  if (!C.acctKey) ((C.acctKey = crypto.randomBytes(32).toString("hex")), writeJson(CONF, C));
  return C.acctKey;
}
const acctSig = (body) => crypto.createHmac("sha256", acctKey()).update(body).digest("base64url");
const acctTok = (id) => {
  const body = id + "." + (Date.now() + 60 * 864e5);
  return "a1." + body + "." + acctSig(body);
};
function acctCheck(t) {
  const m = /^a1\.([0-9a-f]{32})\.(\d{13})\.([A-Za-z0-9_-]{43})$/.exec(String(t || ""));
  if (!m || +m[2] < Date.now()) return null;
  const a = Buffer.from(acctSig(m[1] + "." + m[2])),
    b = Buffer.from(m[3]);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  return fs.existsSync(acctFile(m[1])) ? m[1] : null;
}
function acctIndexPut(A) {
  const I = acctIndex(),
    e = { id: A.id, email: A.email, name: A.name, created: A.created, seen: A.seen, size: A.size || 0 },
    i = I.list.findIndex((x) => x.id === A.id);
  i < 0 ? I.list.push(e) : (I.list[i] = e);
  writeJson(hubf("accounts.json"), I);
}
// Block World worlds never come here, even if a device sends them
const acctClean = (st) => Object.fromEntries(Object.entries(st || {}).filter(([k, v]) => typeof v === "string" && /^(wb[-_]|stark_)/.test(k) && !/world|^wb-bw/i.test(k)));
const acctView = (A) => ({ account: { email: A.email, name: A.name, created: A.created }, rev: A.rev || "", save: A.save || null, size: A.size || 0, limit: ACCT_MAX });
const acctHits = new Map();
function acctLimit(req, n) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim() + "|" + n,
    now = Date.now(),
    a = (acctHits.get(ip) || []).filter((t) => now - t < 3600000);
  if (a.length >= n) throw Object.assign(new Error("Too many in a short time. Try again later."), { code: 429 });
  a.push(now);
  acctHits.set(ip, a);
  acctHits.size > 5000 && acctHits.clear();
}
async function acctRoute(req, res, what) {
  if (what === "google") {
    acctLimit(req, 40);
    const b = await jsonBody(req, 8000),
      g = await googleVerify(b.credential),
      id = acctId(g.sub);
    fs.mkdirSync(hubf("accounts"), { recursive: !0 });
    const A = readJson(acctFile(id), null) || { id, sub: g.sub, created: Date.now(), rev: "", save: null, size: 0 };
    const isNew = !A.seen;
    Object.assign(A, { email: g.email, name: g.name, seen: Date.now() });
    writeJson(acctFile(id), A);
    acctIndexPut(A);
    isNew && pubEvent("note", "A new Workbench account", (g.name || "Someone") + " signed in with Google for the first time.");
    return json(res, 200, Object.assign({ token: acctTok(id) }, acctView(A)));
  }
  acctLimit(req, 600);
  const b = await jsonBody(req, ACCT_MAX * 1.3),
    id = acctCheck(b.token);
  if (!id) return fail(res, 401, "Sign in with Google again.");
  const A = readJson(acctFile(id), null);
  if (!A) return fail(res, 401, "Sign in with Google again.");
  if (what === "load") return ((A.seen = Date.now()), writeJson(acctFile(id), A), json(res, 200, acctView(A)));
  if (what === "save") {
    if ((b.base || "") !== (A.rev || "")) return json(res, 409, acctView(A));
    if (!b.save || typeof b.save.storage !== "object") return fail(res, 400, "That isn't Workbench progress.");
    const storage = acctClean(b.save.storage),
      text = JSON.stringify(storage);
    if (text.length > ACCT_MAX) return fail(res, 413, "Your progress is bigger than 5 MB, so it can't be kept on the account. It stays on this device.");
    A.save && writeJson(acctFile(id, !0), { at: A.saved || 0, storage: A.save.storage });
    Object.assign(A, { save: { storage }, size: text.length, saved: Date.now(), seen: Date.now(), rev: sha(text + "|" + Date.now()).slice(0, 16) });
    writeJson(acctFile(id), A);
    acctIndexPut(A);
    return json(res, 200, { rev: A.rev, size: A.size, limit: ACCT_MAX });
  }
  if (what === "delete") {
    for (const f of [acctFile(id), acctFile(id, !0)]) await fsp.rm(f, { force: !0 });
    const I = acctIndex();
    I.list = I.list.filter((x) => x.id !== id);
    writeJson(hubf("accounts.json"), I);
    return json(res, 200, { ok: !0 });
  }
  return fail(res, 404, "Not here.");
}
const inboxHits = new Map();
function inboxLimit(req) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    a = (inboxHits.get(ip) || []).filter((t) => now - t < 3600000);
  if (a.length >= 6) throw Object.assign(new Error("Too many in a short time. Try again in an hour."), { code: 429 });
  a.push(now);
  inboxHits.set(ip, a);
}
// ---- traffic (1.6.0): anonymous counts the website sends to the inbox: no addresses, no cookies ----
let TRF = null;
const trfLoad = () => (TRF = TRF || readJson(hubf("traffic.json"), { days: {} }));
const dayKey = (t) => new Date((t || Date.now()) - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
let trfT = 0;
function trfHit(kind, slug) {
  const T = trfLoad(),
    d = (T.days[dayKey()] = T.days[dayKey()] || { open: 0, ref: {}, form: {}, co: {}, sent: {}, msg: {}, stamp: {}, trail: {} });
  if (kind === "open") d.open++;
  else if (["ref", "form", "co", "sent", "msg", "stamp", "trail"].includes(kind) && /^[a-z0-9-]{1,60}$/.test(slug)) {
    const m = d[kind] || (d[kind] = {});
    if (Object.keys(m).length < 300 || m[slug]) m[slug] = (m[slug] || 0) + 1;
  } else return;
  const keep = Object.keys(T.days).sort().slice(-70);
  for (const k of Object.keys(T.days)) keep.includes(k) || delete T.days[k];
  clearTimeout(trfT);
  trfT = setTimeout(() => writeJson(hubf("traffic.json"), T), 4000);
}
// the last N days of one counter for one company or form
function trfSum(kind, slug, days) {
  const T = trfLoad(),
    from = dayKey(Date.now() - days * 864e5);
  let n = 0;
  for (const [k, d] of Object.entries(T.days)) k >= from && (n += (d[kind] && d[kind][slug]) || 0);
  return n;
}
const hitHits = new Map();
function hitLimit(req) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    a = (hitHits.get(ip) || []).filter((t) => now - t < 3600000);
  if (a.length >= 120) return !1;
  a.push(now);
  hitHits.set(ip, a);
  hitHits.size > 5000 && hitHits.clear();
  return !0;
}
// ---- pairing codes (1.6.0): the rig shows a code, the device types it, and it's connected ----
const PAIR = new Map(),
  pairTries = new Map();
const PAIRABC = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
// 1.9.0: a stamp word is 8 letters/digits, and the website holds only a slow, salted scramble of it
// (PBKDF2, 50,000 rounds) so nobody can work the word out from the published file in any useful time.
// Words made before 1.9.0 are 5 long and keep working; only the scramble got stronger.
const newStamp = () => Array.from(crypto.randomBytes(8), (x) => PAIRABC[x % PAIRABC.length]).join("");
const stampMemo = new Map();
const stampHash = (slug, word) => {
  const k = slug + ":" + word;
  if (!stampMemo.has(k)) {
    stampMemo.size > 2000 && stampMemo.clear();
    stampMemo.set(k, crypto.pbkdf2Sync(String(word), "wb-stamp:" + slug, 50000, 16, "sha256").toString("hex"));
  }
  return stampMemo.get(k);
};
function pairNew(b) {
  const owner = U.users.find((x) => x.role === "owner"),
    u = !b.user || b.user === "me" ? owner : U.users.find((x) => x.id === b.user);
  if (!u) throw Object.assign(new Error("Nobody like that on the Hub."), { code: 404 });
  let code;
  do code = Array.from(crypto.randomBytes(6), (x) => PAIRABC[x % PAIRABC.length]).join("");
  while (PAIR.has(code));
  for (const [k, v] of PAIR) v.exp < Date.now() && PAIR.delete(k);
  [...PAIR].length >= 20 && PAIR.delete(PAIR.keys().next().value);
  const exp = Date.now() + 5 * 60000;
  PAIR.set(code, { user: u.id, name: clip(b.name, 40) || "New device", exp });
  log("Pairing code made for", u.name);
  return { code, exp, who: u.name };
}
function pairUse(req, b) {
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    t = (pairTries.get(ip) || []).filter((x) => now - x < 600000);
  if (t.length >= 8) throw Object.assign(new Error("Too many tries. Wait 10 minutes."), { code: 429 });
  const code = String(b.code || "").toUpperCase().replace(/[^A-Z0-9]/g, ""),
    P = PAIR.get(code);
  if (!P || P.exp < now) {
    t.push(now);
    pairTries.set(ip, t);
    throw Object.assign(new Error("That code isn't right, or it ran out. Ask for a new one on the rig."), { code: 400 });
  }
  PAIR.delete(code);
  const u = U.users.find((x) => x.id === P.user);
  if (!u) throw Object.assign(new Error("That person is gone."), { code: 400 });
  const R = remLoad(),
    dev = clip(b.device, 60) || P.name,
    key = { id: id36(), name: dev, key: "wbk_" + crypto.randomBytes(24).toString("base64url"), at: now, used: now, full: !0, paired: !0 },
    token = crypto.randomBytes(32).toString("base64url"),
    d = { id: id36(), user: u.id, name: dev, tokenHash: sha(token), created: now, seen: now, push: null, notify: !0, via: C.inboxUrl ? C.inboxUrl + "/k/" + key.key : "" };
  if (u.role === "owner") d.remote = { at: now, paired: !0 };
  R.keys.push(key);
  writeJson(hubf("remote.json"), R);
  DV.devices.push(d);
  saveDevices();
  log("Paired:", u.name, "on", dev);
  try {
    pubEvent("device", dev + " paired", u.role === "owner" ? "as a Rig Remote" : "as " + u.name);
  } catch {}
  return { key: key.key, url: C.inboxUrl ? C.inboxUrl + "/k/" + key.key : "", token, user: pub(u), device: { id: d.id, name: d.name }, name: C.name, remote: !!d.remote };
}
// ---- "use from anywhere" (1.5.0): the same Funnel address, plus a key made on the rig, in the path:
// https://rig.<tailnet>.ts.net:8443/k/<key>. The key alone lets a device chat with the AI (no
// Tailscale needed); a key that allows it also lets the device sign in with a name and PIN and use
// the Hub as usual. Without a valid key the door says nothing. It's never "the rig": the rig's own
// settings (folders, people, keys, publishing setup) stay on the rig.
let RMK = null;
const remLoad = () => (RMK = RMK || readJson(hubf("remote.json"), { keys: [] }));
const remBad = new Map(),
  remHits = new Map();
const safeEq = (a, b) => {
  const x = Buffer.from(String(a)),
    y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
function remoteView() {
  const R = remLoad(),
    base = C.inbox && C.inboxUrl ? C.inboxUrl : "",
    owners = new Set(U.users.filter((x) => x.role === "owner").map((x) => x.id));
  return {
    anywhere: { on: !!base, base, keys: R.keys.map((k) => ({ id: k.id, name: k.name, at: k.at, used: k.used || 0, full: !!k.full, url: base ? base + "/k/" + k.key : "" })) },
    remotes: DV.devices.filter((d) => owners.has(d.user) && (d.remote || d.pairReq)).map((d) => ({ id: d.id, name: d.name, seen: d.seen || 0, remote: !!d.remote, at: d.remote ? d.remote.at : 0, pairReq: d.pairReq || 0 })),
  };
}
async function remoteDoor(req, res, key, rest, url) {
  cors(req, res);
  if (req.method === "OPTIONS") return (res.writeHead(204), res.end());
  const ip = String(req.headers["x-forwarded-for"] || req.socket.remoteAddress || "?").split(",")[0].trim(),
    now = Date.now(),
    bad = (remBad.get(ip) || []).filter((t) => now - t < 3600000);
  if (bad.length >= 20) return fail(res, 429, "Too many wrong keys. Try again in an hour.");
  const R = remLoad(),
    k = R.keys.find((x) => safeEq(x.key, key));
  if (!k) return (bad.push(now), remBad.set(ip, bad), fail(res, 404, "That key isn't on this Hub. It may have been removed on the rig."));
  const h = (remHits.get(k.id) || []).filter((t) => now - t < 60000);
  if (h.length >= 900) return fail(res, 429, "Slow down a little and try again.");
  h.push(now);
  remHits.set(k.id, h);
  now - (k.used || 0) > 60000 && ((k.used = now), writeJson(hubf("remote.json"), R));
  req.wbRemote = !0;
  req.wbKey = k;
  req.url = rest + url.search;
  if (rest === "/ollama" || rest.startsWith("/ollama/")) {
    // the AI, with the key alone: chatting, and the list of models
    if (!/^\/api\/(chat|generate|tags|show|version|ps)$/.test(rest.slice(7) || "/")) return fail(res, 404, "Not here.");
    return proxyOllama(req, res, new URL(req.url, "http://hub"));
  }
  if (rest === "/ping" || rest === "/api/ping") return json(res, 200, { ok: !0, hub: "Workbench Hub", version: VERSION, name: C.name, anywhere: !0, full: !!k.full, time: Date.now() });
  if (!k.full) return fail(res, 403, "This key is only for the AI. On the rig, make a key that can also sign in.");
  if (rest === "/" || rest === "/index.html") return fail(res, 404, "Not here.");
  return route(req, res);
}
async function inboxRoute(req, res) {
  const url = new URL(req.url, "http://inbox"),
    o = req.headers.origin && allowOrigin(req.headers.origin),
    RD = /^\/k\/(wbk_[A-Za-z0-9_-]{20,80})(\/.*)?$/.exec(url.pathname);
  if (RD) return remoteDoor(req, res, RD[1], RD[2] || "/", url);
  res.setHeader("Vary", "Origin");
  if (o) (res.setHeader("Access-Control-Allow-Origin", o), res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS"), res.setHeader("Access-Control-Allow-Headers", "Content-Type"));
  if (req.method === "OPTIONS") return (res.writeHead(204), res.end());
  if (url.pathname === "/ping") return json(res, 200, { ok: !0 });
  if (req.method === "POST" && url.pathname === "/hit") {
    const b = await jsonBody(req, 400);
    hitLimit(req) && trfHit(String(b.k || ""), String(b.s || ""));
    return json(res, 200, { ok: !0 });
  }
  if (req.method === "POST" && url.pathname === "/pair") return json(res, 200, pairUse(req, await jsonBody(req, 2000)));
  if (req.method === "POST" && /^\/acct\/(google|load|save|delete)$/.test(url.pathname)) return acctRoute(req, res, url.pathname.slice(6));
  if (req.method !== "POST" || !["/apply", "/message", "/form"].includes(url.pathname)) return fail(res, 404, "Not here.");
  const b = await jsonBody(req, 2.2e6),
    S = pubLoad();
  if (b.website2) return json(res, 200, { ok: !0 });
  inboxLimit(req);
  if (url.pathname === "/form" || url.pathname === "/apply") {
    if (S.responses.filter((r) => r.status === "new").length >= 1000) return fail(res, 503, "Too many answers are waiting right now. Try again later.");
    let f, body = b;
    if (url.pathname === "/form") f = S.forms.find((x) => x.slug === clip(b.form, 60) && x.open);
    else {
      // a 6.6 page's "List your company": the same answers, into the company sign-up form
      f = S.forms.find((x) => x.kind === "company" && x.open);
      const A = {},
        Fl = {};
      f &&
        f.fields.forEach((q) => {
          if (q.map === "logo") b.logo && (Fl[q.id] = { b64: b.logo, type: b.logoType });
          else if (["instagram", "tiktok", "facebook"].includes(q.map)) A[q.id] = (b.socials || {})[q.map] || "";
          else if (q.map) A[q.id] = b[q.map] || "";
        });
      body = { answers: A, files: Fl };
    }
    if (!f) return fail(res, 404, "That form isn't open.");
    const r = formAnswer(f, body);
    S.responses.unshift(r);
    S.responses.length > 2000 && (S.responses.length = 2000);
    writeJson(hubf("public.json"), S);
    const who = (r.items.find((x) => x.map === "name") || r.items.find((x) => x.type === "short" && x.value) || {}).value || "Someone";
    log("Form:", f.title, "·", who);
    trfHit("sent", f.slug);
    pubNotify(f.kind === "company" ? "New company sign-up" : f.kind === "artist" ? "New artist sign-up" : "New answer: " + f.title, String(who), "form", r.id, f.kind === "company" ? [["approve", "Approve"], ["decline", "Turn down"]] : [["done", "Done"]]);
    return json(res, 200, { ok: !0 });
  }
  if (S.msgs.length >= 1000) return fail(res, 503, "Messages are full right now. Try again later.");
  const c = S.companies.find((x) => x.slug === clip(b.company, 60) && x.live !== !1),
    m = { id: id36(), at: Date.now(), company: c ? c.slug : "", companyName: c ? c.name : "", name: clip(b.name, 80), contact: clip(b.contact, 160), text: clip(b.text, 2000) };
  if (!c || !m.text || !m.contact) return fail(res, 400, "Write a message and a way to reach you.");
  S.msgs.push(m);
  writeJson(hubf("public.json"), S);
  log("Message for", c.name);
  trfHit("msg", c.slug);
  pubNotify("Message for " + c.name, (m.name ? m.name + ": " : "") + m.text.slice(0, 120), "message", m.id, [["done", "Passed on"]]);
  return json(res, 200, { ok: !0 });
}
// what the owner (everything) or the Spotlight artist (the artist and the tracks) gets
function pubView(u) {
  const S = pubLoad();
  if (u.role === "owner")
    return Object.assign({}, S, {
      pairs: DV.devices.filter((d) => d.user === u.id && d.pairReq && !d.remote).map((d) => ({ id: d.id, name: d.name, at: d.pairReq })), publish: C.publish ? { repo: C.publish.repo, branch: C.publish.branch, key: !!ghTok(), keyErr: C.publish.keyErr || "" } : null, inbox: { on: !!C.inbox, url: C.inboxUrl || "", ok: IBH.ok, msg: IBH.msg, at: IBH.at, moved: !!S.inboxMoved }, owner: !0, dirty: (S.changedAt || 0) > ((S.published && S.published.at) || 0), events: (S.events || []).slice(0, 40), responses: (S.responses || []).slice(0, 300) });
  return { artist: S.artist, tracks: S.tracks, owner: !1 };
}

// ---- forms: Workbench's own Google Forms (1.4.0) ----------------------------------------------------
// The owner builds forms on the rig (short answer, paragraph, choices, checkboxes, dropdown, email,
// phone, date, number, link, picture). Open forms are published with Discover; people fill them in
// on the website, the answers come through the inbox, and the owner reads them on the Rig tab's
// front page. A company sign-up that's approved becomes its Discover page by itself.
const FTYPES = ["short", "long", "choice", "checks", "select", "email", "phone", "date", "number", "link", "image"];
const FMAPS = ["name", "category", "city", "address", "phone", "email", "website", "instagram", "tiktok", "facebook", "youtube", "whatsapp", "description", "deal", "code", "logo", "contact"];
const fld = (type, label, req, map, help, opts) => ({ id: id36().slice(-8) + Math.floor(Math.random() * 1e4), type, label, req: !!req, map: map || "", help: help || "", opts: opts || [] });
function formDefaults() {
  return [
    {
      id: id36(),
      slug: "company-sign-up",
      kind: "company",
      title: "List your company",
      desc: "Tell us about your business. Once it's approved it shows up in Discover, with its own link to send people.",
      open: !1,
      fields: [
        fld("short", "Company name", 1, "name"),
        fld("short", "What you do", 0, "category", "Food, signs, auto, beauty…"),
        fld("short", "City", 0, "city"),
        fld("short", "Address", 0, "address"),
        fld("phone", "Phone", 0, "phone"),
        fld("email", "Email", 0, "email"),
        fld("link", "Website", 0, "website"),
        fld("link", "Instagram", 0, "instagram"),
        fld("link", "TikTok", 0, "tiktok"),
        fld("link", "Facebook", 0, "facebook"),
        fld("long", "About your company", 0, "description"),
        fld("short", "A deal for people from Workbench (optional)", 0, "deal", "10% off your first order"),
        fld("image", "Logo", 0, "logo"),
        fld("short", "How we reach you (not shown)", 1, "contact", "Phone or email"),
      ],
    },
    { id: id36(), slug: "contact", kind: "contact", title: "Contact Workbench", desc: "Write to us. We'll get back to you.", open: !1, fields: [fld("short", "Your name"), fld("short", "How to reach you", 1, "", "Phone or email"), fld("long", "Message", 1)] },
    {
      id: id36(),
      slug: "artist-sign-up",
      kind: "artist",
      title: "Be on Spotlight",
      desc: "Make music? Tell us about it, and where we can hear it.",
      open: !1,
      fields: [fld("short", "Artist name", 1), fld("short", "How to reach you", 1, "", "Phone or email"), fld("link", "Where we can hear you", 0, "", "SoundCloud, YouTube, Instagram…"), fld("long", "About you"), fld("image", "A photo")],
    },
  ];
}
function formSlug(title, id) {
  let s = slugOf(title).slice(0, 36) || "form",
    n = 2,
    t = s;
  while (pubLoad().forms.some((f) => f.slug === t && f.id !== id)) t = s + "-" + n++;
  return t;
}
function formSave(b) {
  const S = pubLoad(),
    old = b.id && S.forms.find((f) => f.id === b.id),
    f = old || { id: id36(), at: Date.now(), open: !1, kind: "custom" },
    title = clip(b.title, 120) || f.title;
  if (!title) throw Object.assign(new Error("A form needs a title."), { code: 400 });
  if (!old || (b.slug && b.slug !== f.slug)) f.slug = formSlug(b.slug || title, f.id);
  f.title = title;
  "desc" in b && (f.desc = clip(b.desc, 1000));
  "open" in b && (f.open = !!b.open);
  "kind" in b && (f.kind = ["company", "contact", "artist", "custom"].includes(b.kind) ? b.kind : "custom");
  if ("fields" in b) {
    const F = [].concat(b.fields || []).slice(0, 40);
    f.fields = F.map((x) => ({
      id: /^[\w-]{4,24}$/.test(String(x.id || "")) ? String(x.id) : id36().slice(-8) + Math.floor(Math.random() * 1e4),
      type: FTYPES.includes(x.type) ? x.type : "short",
      label: clip(x.label, 200) || "Question",
      help: clip(x.help, 200),
      req: !!x.req,
      map: f.kind === "company" && FMAPS.includes(x.map) ? x.map : "",
      opts: ["choice", "checks", "select"].includes(x.type) ? [...new Set([].concat(x.opts || []).map((o) => clip(o, 100)).filter(Boolean))].slice(0, 30) : [],
    }));
    if (!f.fields.length) throw Object.assign(new Error("Add at least one question."), { code: 400 });
  }
  f.u = Date.now();
  old || S.forms.push(f);
  pubSave();
  return f;
}
// one person's answers, checked against the form
function formAnswer(f, b) {
  const A = (b && b.answers) || {},
    Fl = (b && b.files) || {},
    items = [],
    files = {};
  for (const q of f.fields) {
    let v = A[q.id],
      bad = (m) => Object.assign(new Error((q.label || "A question") + ": " + m), { code: 400 });
    if (q.type === "image") {
      const x = Fl[q.id];
      if (x && x.b64) {
        const file = pubFromB64(x.b64, x.type);
        if (!file) throw bad("send a PNG, JPG or WEBP picture up to 1.5 MB.");
        files[q.id] = file;
        v = file;
      } else v = "";
    } else if (q.type === "checks") v = [].concat(v || []).map((o) => clip(o, 100)).filter((o) => q.opts.includes(o));
    else {
      v = clip(v, q.type === "long" ? 5000 : 300);
      if (v) {
        if (q.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw bad("that email doesn't look right.");
        if (q.type === "phone" && !/^[+\d(][\d\s().+-]{4,30}$/.test(v)) throw bad("that phone number doesn't look right.");
        if (q.type === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(v)) throw bad("pick a date.");
        if (q.type === "number" && !isFinite(+v)) throw bad("write a number.");
        if (q.type === "link") v = webUrl(/^https?:\/\//i.test(v) ? v : "https://" + v) || "";
        if ((q.type === "choice" || q.type === "select") && !q.opts.includes(v)) throw bad("pick one of the choices.");
      }
    }
    if (q.req && (!v || (Array.isArray(v) && !v.length))) throw bad("this one is needed.");
    items.push({ id: q.id, label: q.label, type: q.type, map: q.map || "", value: v });
  }
  return { id: id36(), form: f.id, slug: f.slug, title: f.title, kind: f.kind, at: Date.now(), items, files, status: "new" };
}
// an approved company sign-up becomes its Discover page
function responseToCompany(r) {
  const m = {};
  for (const it of r.items) it.map && it.value && (m[it.map] = it.value);
  const c = companySave({ name: m.name || r.items.find((x) => x.type === "short" && x.value)?.value || "New company", category: m.category, city: m.city, address: m.address, phone: m.phone, email: m.email, website: m.website, description: m.description, deal: m.deal, code: m.code, socials: { instagram: m.instagram, tiktok: m.tiktok, facebook: m.facebook, youtube: m.youtube, whatsapp: m.whatsapp } });
  m.logo && (c.logo = m.logo);
  c.contact = m.contact || "";
  c.from = "form";
  pubSave();
  return c;
}
// ---- the owner's feed of what happened, and the rig's own pop-ups
const trayQ = [];
let trayN = 0;
function pubEvent(kind, title, body, ref) {
  const S = pubLoad(),
    top = S.events[0];
  // the same thing again within the hour just moves to the top (a phone signing in twice, say)
  if (top && top.kind === kind && top.title === clip(title, 120) && Date.now() - top.at < 3600000 && kind !== "form" && kind !== "message") S.events.shift();
  S.events.unshift({ id: id36(), at: Date.now(), kind, title: clip(title, 120), body: clip(body, 300), ref: ref || "" });
  S.events.length > 300 && (S.events.length = 300);
  writeJson(hubf("public.json"), S);
}
function trayNote(title, body) {
  trayQ.push({ n: ++trayN, title: clip(title, 60), body: clip(body, 200) });
  trayQ.length > 50 && trayQ.shift();
}
// ---- a week of the rig's numbers, every 10 minutes, for the little graphs
let HIS = null;
// the website counter's running total (GoatCounter shows it when "Allow adding visitor counts" is on)
async function goatTotal() {
  if (!C.countCode) return null;
  try {
    const r = await fetch((process.env.WB_GOAT_URL || "https://" + C.countCode + ".goatcounter.com") + "/counter/TOTAL.json", { signal: AbortSignal.timeout(8000) });
    return r.ok ? parseInt(String((await r.json()).count || "").replace(/[^\d]/g, ""), 10) || 0 : null;
  } catch {
    return null;
  }
}
async function histSample() {
  HIS = HIS || readJson(hubf("history.json"), { points: [] });
  try {
    const [cpu, gpu] = await Promise.all([cpuBusy(), gpuInfo()]),
      disks = diskList(),
      hd = disks.find((d) => d.hub) || disks[0],
      g = gpu && gpu[0];
    const visits = await goatTotal();
    HIS.points.push({ t: Date.now(), cpu, ram: Math.round(1000 * (1 - os.freemem() / os.totalmem())) / 10, gpu: g ? g.busy : null, temp: g ? g.temp : null, free: hd ? hd.free : null, online: new Set([...live].map((c) => c.device.id)).size, visits });
    const cut = Date.now() - 7 * 864e5 - 9e5;
    HIS.points = HIS.points.filter((p) => p.t >= cut).slice(-1100);
    writeJson(hubf("history.json"), HIS);
  } catch (e) {
    log("History:", e.message);
  }
}

// ---- 1.11.0: which terms people agreed to, and the rule log (when did someone break something) ----------
// Every "I understand and agree" is kept: who, which device, which version of the terms and of Workbench, when.
// The rule log notes who broke what and when, with the terms version they had agreed to at that moment. The
// rig's browser adds an entry by itself when someone tries to reach a private address; the owner can add more.
let TM = null;
const termsLoad = () => (TM = TM || Object.assign({ acc: [], log: [] }, readJson(hubf("terms.json"), {})));
const termsSave = () => writeJson(hubf("terms.json"), TM);
function termsOf(userId, at) {
  let best = null;
  for (const a of termsLoad().acc) if (a.user === userId && a.at <= at && (!best || a.at > best.at)) best = a;
  return best;
}
function ruleLog(user, what, action, auto) {
  const T = termsLoad(),
    at = Date.now(),
    ac = user && user.id ? termsOf(user.id, at) : null;
  T.log.unshift({ id: id36(), at, user: (user && user.id) || "", name: (user && user.name) || "", what: clip(what, 400), action: ["none", "warned", "removed", "blocked", "ended"].includes(action) ? action : "none", auto: !!auto, terms: ac ? ac.terms : "", termsAt: ac ? ac.at : 0, app: ac ? ac.app : "" });
  T.log.length > 500 && (T.log.length = 500);
  termsSave();
}
// ---- the routes ---------------------------------------------------------------------------------
// ---- the rig's browser (1.8.0): one person at a time, only the public internet ----
let BRW = null;
try {
  BRW = require("./browser.js").create({
    log,
    exe: () => (C.browser && C.browser.exe) || "",
    onVisit: (host, u) => {
      // only the host name is kept (not the page or what was typed): who, when, which site
      const L = readJson(hubf("browser-log.json"), { visits: [] });
      L.visits.unshift({ at: Date.now(), who: u.name, host });
      L.visits.length = Math.min(L.visits.length, 300);
      writeJson(hubf("browser-log.json"), L);
    },
    onStop: (u, why) => {
      try {
        pubEvent("browser", u.name + " closed the rig's browser", why);
      } catch {}
    },
    onBlock: (u) => {
      try {
        ruleLog(u, "Tried to open a private address (the rig, the home network or the tailnet) in the rig's browser. It was refused.", "blocked", !0);
        pubEvent("browser", u.name + " tried to open a private address in the rig's browser", "It was refused, and it's in the rule log.");
      } catch {}
    },
  });
} catch (e) {
  log("The rig's browser isn't available:", e.message);
}
const brOn = () => !!(C.browser && C.browser.on);
function brState(u) {
  const st = BRW ? BRW.state(u) : { available: !1, active: null };
  return Object.assign(st, { ack: u.role === "owner" || !!u.brAck, on: brOn(), can: canBrowse(u), allowed: canBrowse(u) && brOn(), module: !!BRW, exe: u.role === "owner" ? (C.browser && C.browser.exe) || "" : undefined });
}
async function route(req, res) {
  const url = new URL(req.url, "http://hub"),
    p = url.pathname,
    M = req.method;
  cors(req, res);
  if (M === "OPTIONS") return (res.writeHead(204), res.end());
  if (p === "/" || p === "/index.html") return statusPage(req, res);
  if (p === "/api/tray") {
    if (!fromRig(req) || req.headers["x-forwarded-for"] || req.headers["x-forwarded-host"] || req.headers.origin) return fail(res, 403, "Only for the Hub's icon on the rig.");
    // the first ask (no "after") only learns where the list is, so old notices don't pop up again
    const after = url.searchParams.get("after");
    return json(res, 200, { last: trayN, notes: after == null ? [] : trayQ.filter((n) => n.n > +after) });
  }
  if (p === "/api/ping") return json(res, 200, { ok: !0, hub: "Workbench Hub", version: VERSION, name: C.name, setup: U.users.length > 0, time: Date.now() });
  if (p === "/api/login" && M === "POST") return json(res, 200, login(await jsonBody(req, 1e4)));
  if (p === "/api/act" && M === "POST") return json(res, 200, actDo(await jsonBody(req, 2e3)));
  const a = auth(req, url);
  if (!a) return fail(res, 401, "Sign in to the Hub again.");
  const u = a.user,
    owner = u.role === "owner";
  if (p.startsWith("/ollama/") || p === "/ollama") return proxyOllama(req, res, url);
  switch (p) {
    case "/api/logout":
      DV.devices = DV.devices.filter((d) => d !== a.device);
      saveDevices();
      return json(res, 200, { ok: !0 });
    case "/api/me": {
      let disk = null;
      try {
        const s = fs.statfsSync(C.root);
        disk = { free: s.bavail * s.bsize, size: s.blocks * s.bsize };
      } catch {}
      const via = String(url.searchParams.get("via") || "");
      // remember which sign-in is the rig's own (a Rig Remote can't sign the rig out by mistake)
      fromRig(req) && !a.device.rig && ((a.device.rig = !0), saveDevicesSoon());
      /^https?:\/\/[^\s"'<>]{3,300}$/.test(via) && via !== a.device.via && ((a.device.via = via.replace(/\/+$/, "")), saveDevicesSoon());
      return json(res, 200, { user: pub(u), device: { id: a.device.id, name: a.device.name, push: !!a.device.push, remote: !!a.device.remote, pairReq: a.device.pairReq || 0 }, hub: { name: C.name, version: VERSION, disk: owner ? disk : null, rig: fromRig(req), anywhere: !!req.wbRemote } });
    }
    case "/api/system/history":
      if (!owner) return fail(res, 403, "Only the owner can see the rig's health.");
      HIS = HIS || readJson(hubf("history.json"), { points: [] });
      return json(res, 200, { points: HIS.points, every: 600 });
    case "/api/system": {
      if (!owner) return fail(res, 403, "Only the owner can see the rig's health.");
      {
        const cc = String(url.searchParams.get("count") || "");
        /^[a-z0-9-]{2,40}$/.test(cc) && cc !== C.countCode && ((C.countCode = cc), writeJson(CONF, C));
      }
      return json(res, 200, Object.assign(await systemInfo(req), { visitsBase: C.visitsBase || 0, visitsBaseAt: C.visitsBaseAt || 0 }));
    }
    case "/api/system/visits-base": {
      // 1.10.0: "count from now": the counter's total so far (the owner's own devices were in it) stops showing
      if (!owner) return fail(res, 403, "Only the owner can do that.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const n = await goatTotal();
      if (n == null) return fail(res, 502, "The counter didn't answer. Try again in a minute.");
      C.visitsBase = n;
      C.visitsBaseAt = Date.now();
      writeJson(CONF, C);
      return json(res, 200, { visitsBase: n, visitsBaseAt: C.visitsBaseAt });
    }
    case "/api/system/ai": {
      if (!owner) return fail(res, 403, "Only the owner can do that.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 1e4),
        m = String(b.model || "").slice(0, 200);
      if (!m) return fail(res, 400, "Which model?");
      if (b.do === "default") ((C.aiModel = m), writeJson(CONF, C));
      else await aiKeep(m, b.do === "load");
      log("AI", b.do || "unload", m);
      return json(res, 200, { ok: !0, ai: await aiInfo() });
    }
    // ---- Discover and Spotlight (the owner; the Spotlight artist for the music)
    case "/api/pub":
      if (!owner && !u.artist) return fail(res, 403, "Only the owner and the Spotlight artist.");
      return json(res, 200, pubView(u));
    case "/api/pub/media": {
      if (!owner && !u.artist) return fail(res, 403, "Only the owner and the Spotlight artist.");
      const f = String(url.searchParams.get("f") || "");
      if (!/^[0-9a-f]{16}\.[a-z0-9]+$/.test(f)) return fail(res, 400, "No such file.");
      return sendFile(req, res, path.join(PUBDIR(), f));
    }
    case "/api/pub/company": {
      if (!owner) return fail(res, 403, "Only the owner lists companies.");
      if (M === "DELETE") {
        const S = pubLoad();
        S.companies = S.companies.filter((c) => c.id !== url.searchParams.get("id"));
        pubSave();
        return json(res, 200, pubView(u));
      }
      if (M === "POST") return (companySave(await jsonBody(req, 5e4)), json(res, 200, pubView(u)));
      break;
    }
    case "/api/pub/file": {
      if (M !== "PUT" && M !== "POST") break;
      const kind = url.searchParams.get("kind"),
        forId = url.searchParams.get("for") || "",
        S = pubLoad();
      if (!["logo", "photo", "cover", "song"].includes(kind)) return fail(res, 400, "What kind of file?");
      if (kind === "logo" ? !owner : !(owner || u.artist)) return fail(res, 403, "That isn't yours to change.");
      const t = kind === "cover" && S.tracks.find((x) => x.id === forId),
        co = kind === "logo" && S.companies.find((x) => x.id === forId);
      if (kind === "cover" && (!t || (!owner && t.by !== u.id))) return fail(res, 404, "No such track.");
      if (kind === "logo" && !co) return fail(res, 404, "No such company.");
      const file = await pubFile(req, url.searchParams.get("name"), kind === "song" ? "song" : "img");
      if (kind === "logo") co.logo = file;
      else if (kind === "photo") S.artist.photo = file;
      else if (kind === "cover") t.cover = file;
      else S.tracks.push({ id: id36(), title: clip(url.searchParams.get("title") || path.parse(String(url.searchParams.get("name") || "Track")).name, 100), file, dur: Math.max(0, Math.min(3600, +url.searchParams.get("dur") || 0)), status: owner ? "approved" : "pending", by: u.id, byName: u.name, at: Date.now() });
      pubSave();
      kind === "song" && !owner && pubNotify("A Spotlight song to approve", u.name + " added a song.", "track");
      return json(res, 200, pubView(u));
    }
    case "/api/pub/track": {
      const S = pubLoad(),
        b = M === "DELETE" ? { id: url.searchParams.get("id") } : await jsonBody(req, 2e4),
        t = S.tracks.find((x) => x.id === b.id);
      if (!t || !(owner || (u.artist && t.by === u.id))) return fail(res, 404, "No such track.");
      if (M === "DELETE") {
        if (!owner && t.status === "approved") return fail(res, 403, "Ask the owner to take down a track that's already approved.");
        S.tracks = S.tracks.filter((x) => x !== t);
      } else {
        "title" in b && (t.title = clip(b.title, 100) || t.title);
        "dur" in b && (t.dur = Math.max(0, Math.min(3600, +b.dur || 0)));
        owner && "status" in b && (t.status = b.status === "approved" ? "approved" : "pending");
      }
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/artist": {
      if (!owner && !u.artist) return fail(res, 403, "Only the owner and the Spotlight artist.");
      const b = await jsonBody(req, 2e4),
        A = pubLoad().artist;
      "name" in b && (A.name = clip(b.name, 80));
      "bio" in b && (A.bio = clip(b.bio, 1500));
      "socials" in b && (A.socials = socialsOf(b.socials));
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/app": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const b = await jsonBody(req, 1e4),
        S = pubLoad(),
        a = S.apps.find((x) => x.id === b.id);
      if (!a) return fail(res, 404, "No such application.");
      S.apps = S.apps.filter((x) => x !== a);
      if (b.do === "approve") {
        const c = companySave(Object.assign({}, a, { id: void 0 }));
        ((c.logo = a.logo || ""), (c.contact = a.contact || ""), (c.from = "application"));
      }
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/msg": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const b = await jsonBody(req, 1e4),
        S = pubLoad();
      S.msgs = S.msgs.filter((x) => x.id !== b.id);
      writeJson(hubf("public.json"), S);
      return json(res, 200, pubView(u));
    }
    case "/api/pub/form": {
      if (!owner) return fail(res, 403, "Only the owner makes forms.");
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M === "DELETE") {
        const S = pubLoad();
        S.forms = S.forms.filter((f) => f.id !== url.searchParams.get("id"));
        pubSave();
        return json(res, 200, pubView(u));
      }
      if (M === "POST") return (formSave(await jsonBody(req, 2e5)), json(res, 200, pubView(u)));
      break;
    }
    case "/api/pub/resp": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const S = pubLoad();
      if (M === "DELETE") {
        S.responses = S.responses.filter((r) => r.id !== url.searchParams.get("id"));
        writeJson(hubf("public.json"), S);
        return json(res, 200, pubView(u));
      }
      const b = await jsonBody(req, 1e4),
        r = S.responses.find((x) => x.id === b.id);
      if (!r) return fail(res, 404, "No such answer.");
      let made = null;
      if (b.do === "approve") {
        r.kind === "company" && (made = responseToCompany(r));
        r.status = "approved";
        pubEvent("company", made ? made.name + " is in Discover" : "Approved: " + r.title, made ? "Publish to put it on the website." : "", r.id);
      } else if (b.do === "decline") r.status = "declined";
      else if (b.do === "done") r.status = "done";
      else if (b.do === "new") r.status = "new";
      r.decided = Date.now();
      writeJson(hubf("public.json"), S);
      return json(res, 200, Object.assign(pubView(u), { made: made ? made.id : "" }));
    }
    case "/api/pub/setup":
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      {
        const r = await pubSetup(await jsonBody(req, 1e4));
        return json(res, 200, Object.assign(pubView(u), { setup: r }));
      }
    case "/api/pub/publish":
      if (!owner) return fail(res, 403, "Only the owner publishes.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      {
        const r = await publish();
        return json(res, 200, Object.assign(pubView(u), { done: r }));
      }
    case "/api/pub/inbox":
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      {
        const r = await inboxSet(!!(await jsonBody(req, 1e3)).on);
        return json(res, 200, Object.assign(pubView(u), { inboxResult: r }));
      }
    case "/api/pub/inbox/check":
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      await inboxWatch();
      return json(res, 200, pubView(u));
    case "/api/chat": {
      if (M === "GET") {
        const since = +url.searchParams.get("since") || 0,
          list = CHAT.msgs.filter((m) => m.at > since || (m.edit || 0) > since).slice(-200);
        return json(res, 200, { msgs: list.map(chatView), me: { id: u.id, name: u.name, owner }, muted: CHAT.muted.includes(u.id), people: owner ? U.users.map((x) => ({ id: x.id, name: x.name, muted: CHAT.muted.includes(x.id) })) : void 0, now: Date.now() });
      }
      if (M === "POST") {
        if (CHAT.muted.includes(u.id)) return fail(res, 403, "The owner has paused your chat for now.");
        const text = chatClean((await jsonBody(req, 2e4)).text);
        if (!text) return fail(res, 400, "Write something first.");
        const last = chatLast.get(u.id) || 0;
        if (Date.now() - last < 3000) return fail(res, 429, "Slow down: one message every 3 seconds.");
        chatLast.set(u.id, Date.now());
        const m = { id: id36(), at: Date.now(), uid: u.id, name: u.name, owner, text };
        CHAT.msgs.push(m);
        CHAT.msgs.length > 1000 && CHAT.msgs.splice(0, CHAT.msgs.length - 1000);
        saveChat();
        broadcast({ type: "chat", at: m.at });
        return json(res, 200, { msg: chatView(m) });
      }
      if (M === "DELETE") {
        const m = CHAT.msgs.find((x) => x.id === url.searchParams.get("id"));
        if (!m) return fail(res, 404, "That message is already gone.");
        if (!owner && m.uid !== u.id) return fail(res, 403, "You can only remove your own messages.");
        ((m.del = !0), (m.text = ""), (m.edit = Date.now()));
        saveChat();
        broadcast({ type: "chat", at: m.edit });
        return json(res, 200, { ok: !0 });
      }
      break;
    }
    case "/api/chat/mute": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      const b = await jsonBody(req, 1e3),
        who = U.users.find((x) => x.id === b.uid);
      if (!who || who.role === "owner") return fail(res, 400, "Pick someone to pause.");
      CHAT.muted = CHAT.muted.filter((x) => x !== who.id);
      b.on && CHAT.muted.push(who.id);
      saveChat();
      broadcast({ type: "chat", at: Date.now() });
      return json(res, 200, { ok: !0, muted: !!b.on });
    }
    case "/api/me/pin": {
      const b = await jsonBody(req, 1e4);
      if (pinHash(String(b.old || ""), u.salt) !== u.hash) return fail(res, 401, "Your current PIN isn't right.");
      setPin(u, b.pin);
      return json(res, 200, { ok: !0 });
    }
    case "/api/events": {
      res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive", "X-Accel-Buffering": "no" });
      res.write("retry: 5000\n\n");
      const c = { res, user: u, device: a.device };
      live.add(c);
      req.on("close", () => live.delete(c));
      return;
    }
    case "/api/users":
      if (!owner) return fail(res, 403, "Only the owner can manage people.");
      if (M !== "GET" && !rigCtl(req, a)) return ctlNo(res);
      if (M === "GET") return json(res, 200, { users: U.users.map((x) => ({ ...pub(x), created: x.created, devices: DV.devices.filter((d) => d.user === x.id).map((d) => ({ id: d.id, name: d.name, seen: d.seen, push: !!d.push, rig: !!d.rig })) })) });
      if (M === "POST") {
        const b = await jsonBody(req, 1e4);
        const nu = addUser(b.name, b.pin, "member", !!b.work);
        b.artist && ((nu.artist = !0), saveUsers());
        log("Added", nu.name);
        return json(res, 200, { user: pub(nu) });
      }
      if (M === "PATCH" || M === "DELETE") {
        const b = M === "PATCH" ? await jsonBody(req, 1e4) : {},
          x = U.users.find((y) => y.id === (b.id || url.searchParams.get("id")));
        if (!x) return fail(res, 404, "Nobody like that on the Hub.");
        if (x.role === "owner") return fail(res, 400, "The owner can't be changed or removed here.");
        if (M === "PATCH") {
          "work" in b && (x.work = !!b.work);
          "browser" in b && ((x.browser = !!b.browser), !x.browser && BRW && BRW.active() && BRW.active().user.id === x.id && BRW.stop("Turned off by the owner."));
          "artist" in b && (x.artist = !!b.artist);
          b.pin && setPin(x, b.pin);
          saveUsers();
          return json(res, 200, { user: pub(x) });
        }
        // their devices are signed out; their music, videos and saves stay in Users\<name> on the rig
        U.users = U.users.filter((y) => y !== x);
        DV.devices = DV.devices.filter((d) => d.user !== x.id);
        for (const c of live) c.user === x && (c.res.end(), live.delete(c));
        saveUsers();
        saveDevices();
        log("Removed", x.name);
        return json(res, 200, { ok: !0 });
      }
      break;
    case "/api/devices":
      if (M === "DELETE") {
        const d = DV.devices.find((x) => x.id === url.searchParams.get("id"));
        if (!d || (!owner && d.user !== u.id)) return fail(res, 404, "No such device.");
        if (d.user !== u.id && !rigCtl(req, a)) return ctlNo(res);
        DV.devices = DV.devices.filter((x) => x !== d);
        saveDevices();
        return json(res, 200, { ok: !0 });
      }
      break;
    // ---- Work (the owner, and anyone the owner lets in)
    case "/api/work": {
      if (!canWork(u)) return fail(res, 403, "Work is only for the people the owner allows.");
      const text = readWorkText(),
        rev = revOf(text);
      if (M === "GET") {
        res.setHeader("X-Rev", rev);
        return json(res, 200, '{"rev":"' + rev + '","data":' + (text || "null") + "}");
      }
      if (M === "PUT") {
        const b = await jsonBody(req, 200e6);
        if ((b.base || "") !== rev) return json(res, 409, '{"rev":"' + rev + '","data":' + (text || "null") + "}");
        if (!b.data || typeof b.data !== "object" || !Array.isArray(b.data.orders)) return fail(res, 400, "That isn't Work data.");
        const nt = JSON.stringify(b.data);
        fs.mkdirSync(WORK(), { recursive: !0 });
        const tmp = workFile() + ".tmp";
        fs.writeFileSync(tmp, nt);
        fs.renameSync(tmp, workFile());
        backupWork(nt);
        const nr = revOf(nt);
        broadcast({ type: "work", rev: nr, by: a.device.id }, (c) => canWork(c.user));
        clearTimeout(route.remT);
        route.remT = setTimeout(checkReminders, 8000);
        return json(res, 200, { rev: nr });
      }
      break;
    }
    case "/api/work/file": {
      if (!canWork(u)) return fail(res, 403, "Work is only for the people the owner allows.");
      const f = inside(WORK(), url.searchParams.get("path"));
      if (!f || /(^|[\\/])work\.json$/i.test(f)) return fail(res, 400, "That path isn't allowed.");
      if (M === "GET" || M === "HEAD") return sendFile(req, res, f, url.searchParams.has("download"));
      if (M === "PUT") return json(res, 200, { size: await receive(req, f) });
      if (M === "DELETE") return (await fsp.rm(f, { force: !0 }), json(res, 200, { ok: !0 }));
      break;
    }
    case "/api/work/list": {
      if (!canWork(u)) return fail(res, 403, "Work is only for the people the owner allows.");
      const d = url.searchParams.get("dir") ? inside(WORK(), url.searchParams.get("dir")) : WORK();
      if (!d) return fail(res, 400, "That path isn't allowed.");
      let ents = [];
      try {
        ents = await fsp.readdir(d, { withFileTypes: !0 });
      } catch {}
      const out = [];
      for (const e of ents) {
        if (e.name.endsWith(".part") || e.name.endsWith(".tmp")) continue;
        const st = await fsp.stat(path.join(d, e.name)).catch(() => null);
        st && out.push({ name: e.name, dir: e.isDirectory(), size: st.size, mtime: Math.floor(st.mtimeMs) });
      }
      return json(res, 200, { items: out });
    }
    // ---- saves and settings (each person their own)
    case "/api/saves": {
      const f = path.join(userDir(u, "Saves"), "saves.json");
      let text = "";
      try {
        text = fs.readFileSync(f, "utf8");
      } catch {}
      const rev = revOf(text);
      if (M === "GET") return json(res, 200, text ? '{"rev":"' + rev + '","save":' + text + "}" : { rev: "", save: null });
      if (M === "PUT") {
        const b = await jsonBody(req, 100e6);
        if ((b.base || "") !== rev) return json(res, 409, text ? '{"rev":"' + rev + '","save":' + text + "}" : { rev: "", save: null });
        if (!b.save || typeof b.save.storage !== "object") return fail(res, 400, "That isn't a Workbench save.");
        // who saved it: the Workbench on the rig itself doesn't need telling that its own save "came from the rig"
        const nt = JSON.stringify(Object.assign({}, b.save, { savedAt: Date.now(), device: a.device.name, deviceId: a.device.id, fromRig: fromRig(req) }));
        fs.mkdirSync(path.dirname(f), { recursive: !0 });
        fs.writeFileSync(f + ".tmp", nt);
        fs.renameSync(f + ".tmp", f);
        return json(res, 200, { rev: revOf(nt) });
      }
      break;
    }
    // ---- music and videos
    case "/api/media": {
      const kind = url.searchParams.get("kind") === "video" ? "video" : "music";
      if (M === "GET") return json(res, 200, { items: await listMedia(u, kind), libraries: libsFor(u, kind).map((l) => ({ scope: l.scope, label: l.label })) });
      if (M === "DELETE") {
        const m = fromId(url.searchParams.get("id")),
          base = m && (m.scope === "u" || owner) ? libDir(u, m.scope, m.kind) : null,
          f = base && inside(base, m.rel);
        if (!f) return fail(res, 403, "You can only remove your own files.");
        await fsp.rm(f, { force: !0 });
        libCache.clear();
        return json(res, 200, { ok: !0 });
      }
      break;
    }
    case "/api/media/file": {
      const m = fromId(url.searchParams.get("id")),
        base = m && libDir(u, m.scope, m.kind),
        f = base && inside(base, m.rel);
      if (!f) return fail(res, 404, "That file isn't on the rig.");
      return sendFile(req, res, f, url.searchParams.has("download"));
    }
    case "/api/media/upload": {
      if (M !== "PUT" && M !== "POST") break;
      const kind = url.searchParams.get("kind") === "video" ? "video" : "music",
        shared = url.searchParams.get("to") === "shared" && owner,
        name = safeName(url.searchParams.get("name"));
      if (!name || !EXT[kind].test(name)) return fail(res, 400, kind === "music" ? "Send MP3, M4A, FLAC, WAV or OGG files." : "Send MP4, WEBM, MOV or MKV files.");
      const base = shared ? path.join(C.root, "Shared", FOLDER[kind]) : userDir(u, FOLDER[kind]);
      let dest = path.join(base, name),
        n = 2;
      while (fs.existsSync(dest)) dest = path.join(base, name.replace(/(\.[^.]+)$/, " (" + n++ + ")$1"));
      const size = await receive(req, dest);
      forget(u, kind);
      return json(res, 200, { size, id: mediaId(kind, shared ? "s" : "u", path.basename(dest)) });
    }
    case "/api/media/fetch": {
      if (M !== "POST") break;
      const b = await jsonBody(req, 2e4);
      let x;
      try {
        x = new URL(String(b.url || "").trim());
      } catch {
        return fail(res, 400, "Paste the whole link, starting with https://");
      }
      try {
        await safeHost(x);
      } catch (e) {
        return fail(res, 400, e.message);
      }
      const job = { id: id36(), user: u.id, url: x.toString(), to: b.to === "music" || b.to === "video" ? b.to : "", shared: b.to === "shared" && owner, name: "", kind: "", got: 0, total: 0, state: "queued", err: "", at: Date.now() };
      jobs.set(job.id, job);
      for (const [k, j] of jobs) if (j.user === u.id && j.state !== "queued" && j.state !== "downloading" && Date.now() - j.at > 6 * 3600000) jobs.delete(k);
      nextJob(u);
      return json(res, 200, { job: jobView(job) });
    }
    case "/api/media/jobs": {
      if (M === "DELETE") {
        const j = jobs.get(url.searchParams.get("id"));
        if (j && j.user === u.id) j.state === "downloading" ? ((j.cancelled = !0), j.cancel && j.cancel()) : jobs.delete(j.id);
        return json(res, 200, { ok: !0 });
      }
      return json(res, 200, { jobs: [...jobs.values()].filter((j) => j.user === u.id).sort((a, b) => b.at - a.at).slice(0, 30).map(jobView) });
    }
    // ---- folders on the rig (the owner adds them; nothing is moved or copied)
    case "/api/libraries": {
      if (!owner) return fail(res, 403, "Only the owner can choose the rig's folders.");
      if (M !== "GET" && !rigCtl(req, a)) return ctlNo(res);
      if (M === "POST") {
        const b = await jsonBody(req, 2e4),
          p = path.resolve(String(b.path || ""));
        let st = null;
        try {
          st = fs.statSync(p);
        } catch {}
        if (!b.path || !st || !st.isDirectory()) return fail(res, 400, "That folder isn't on the rig.");
        if (libraries().some((l) => path.resolve(l.path).toLowerCase() === p.toLowerCase())) return fail(res, 400, "That folder is already in the list.");
        C.libraries = libraries().concat([{ id: libId(p), path: p, kind: b.kind === "music" || b.kind === "video" ? b.kind : "auto", everyone: !!b.everyone, label: String(b.label || path.basename(p) || p).slice(0, 60) }]);
        writeJson(CONF, C);
        log("Added folder", p);
      } else if (M === "DELETE") {
        C.libraries = libraries().filter((l) => l.id !== url.searchParams.get("id"));
        writeJson(CONF, C);
        libCache.clear();
      } else if (M === "PATCH") {
        const b = await jsonBody(req, 2e4),
          l = libraries().find((x) => x.id === b.id);
        if (!l) return fail(res, 404, "No such folder.");
        "everyone" in b && (l.everyone = !!b.everyone);
        C.libraries = libraries().map((x) => (x.id === l.id ? l : x));
        writeJson(CONF, C);
      }
      const out = [];
      // a folder nobody has looked through yet is looked through now, in the background
      for (const L of libsFor(u, "music").concat(libsFor(u, "video"))) {
        if (!L.key.startsWith("l:") || libCache.has(L.key) || scanning.has(L.key)) continue;
        scanning.add(L.key);
        scanLib(L)
          .then((items) => libCache.set(L.key, { t: Date.now(), items }))
          .catch(() => {})
          .finally(() => scanning.delete(L.key));
      }
      for (const l of libraries()) {
        let exists = !1;
        try {
          exists = fs.statSync(l.path).isDirectory();
        } catch {}
        const c = libCache.get("l:" + l.id);
        out.push({ id: l.id, path: l.path, kind: l.kind || "auto", everyone: !!l.everyone, label: l.label || path.basename(l.path), exists, music: c ? c.items.music.length : null, video: c ? c.items.video.length : null });
      }
      return json(res, 200, { libraries: out });
    }
    case "/api/browse":
      if (!owner) return fail(res, 403, "Only the owner can look through the rig's folders.");
      if (!rigCtl(req, a)) return ctlNo(res);
      return json(res, 200, browse(url.searchParams.get("path") || ""));
    // ---- Rig Remote (a phone the owner pairs from the rig) and "use from anywhere" keys (1.5.0)
    case "/api/remote": {
      if (!rigAdmin(req, a)) return adminNo(res);
      return json(res, 200, remoteView());
    }
    case "/api/remote/key": {
      if (!rigAdmin(req, a)) return adminNo(res);
      const R = remLoad();
      if (M === "DELETE") {
        const k = R.keys.find((x) => x.id === url.searchParams.get("id"));
        R.keys = R.keys.filter((x) => x !== k);
        writeJson(hubf("remote.json"), R);
        k && log("Anywhere key removed:", k.name);
        return json(res, 200, remoteView());
      }
      if (M !== "POST") break;
      const b = await jsonBody(req, 1e4),
        name = clip(b.name, 40) || "A device";
      if (R.keys.length >= 20) return fail(res, 400, "That's a lot of keys. Remove one you don't use first.");
      const k = { id: id36(), name, key: "wbk_" + crypto.randomBytes(24).toString("base64url"), at: Date.now(), used: 0, full: b.full !== !1 };
      R.keys.push(k);
      writeJson(hubf("remote.json"), R);
      log("Anywhere key made:", name);
      pubEvent("remote", "Made a key: " + name, k.full ? "The AI, and sign-in with a name and PIN" : "The AI only");
      return json(res, 200, Object.assign(remoteView(), { made: k.id }));
    }
    case "/api/traffic": {
      // only the owner, on the rig or on a paired phone
      if (!rigCtl(req, a)) return ctlNo(res);
      const T = trfLoad(),
        S = pubLoad();
      return json(res, 200, { days: T.days, companies: S.companies.map((c) => ({ slug: c.slug, name: c.name })), forms: S.forms.map((f) => ({ slug: f.slug, title: f.title })) });
    }
    case "/api/pair/new": {
      if (!rigAdmin(req, a)) return adminNo(res);
      if (M !== "POST") break;
      return json(res, 200, pairNew(await jsonBody(req, 1000)));
    }
    case "/api/pub/post": {
      // a short update on a company's page (and deleting one)
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M !== "POST") break;
      const b = await jsonBody(req, 2000),
        S = pubLoad(),
        c = S.companies.find((x) => x.id === b.company);
      if (!c) return fail(res, 404, "No such company.");
      c.posts = c.posts || [];
      if (b.del) c.posts = c.posts.filter((x) => x.id !== b.del);
      else {
        const text = clip(b.text, 280);
        if (!text) return fail(res, 400, "Write the update first.");
        c.posts.unshift({ id: id36(), at: Date.now(), text });
        c.posts.length = Math.min(c.posts.length, 20);
      }
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/trail": {
      if (!rigCtl(req, a)) return ctlNo(res);
      const S = pubLoad();
      if (M === "DELETE") {
        S.trails = S.trails.filter((t) => t.id !== url.searchParams.get("id"));
        pubSave();
        return json(res, 200, pubView(u));
      }
      if (M !== "POST") break;
      const b = await jsonBody(req, 5000),
        old = b.id && S.trails.find((t) => t.id === b.id),
        t = old || { id: id36(), at: Date.now(), on: !0 },
        stops = [...new Set([].concat(b.stops || []).map((x) => String(x)).filter((x) => S.companies.some((c) => c.slug === x)))].slice(0, 6);
      if (!clip(b.title, 80)) return fail(res, 400, "Give the trail a name.");
      if (stops.length < 2) return fail(res, 400, "Pick at least two companies for the trail.");
      Object.assign(t, { title: clip(b.title, 80), desc: clip(b.desc, 300), reward: clip(b.reward, 200), stops, on: b.on !== !1 });
      old || S.trails.push(t);
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/pub/today": {
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M !== "POST") break;
      const b = await jsonBody(req, 500),
        S = pubLoad();
      S.dayCo = b.slug && S.companies.some((c) => c.slug === b.slug) ? { slug: b.slug, date: /^\d{4}-\d\d-\d\d$/.test(b.date || "") ? b.date : dayKey() } : null;
      pubSave();
      return json(res, 200, pubView(u));
    }
    case "/api/remote/pair": {
      if (!owner) return fail(res, 403, "Only the owner's phone can be a Rig Remote.");
      if (M !== "POST") break;
      if (a.device.remote) return json(res, 200, { remote: !0 });
      if (fromRig(req)) return fail(res, 400, "This is the rig itself. Pair your phone instead.");
      a.device.pairReq = Date.now();
      saveDevices();
      pubNotify("Rig Remote: allow " + a.device.name + "?", u.name + " asked from " + a.device.name + ". Allow it on the rig.", "remote", a.device.id);
      return json(res, 200, { remote: !1, pairReq: a.device.pairReq });
    }
    case "/api/remote/allow": {
      if (!rigAdmin(req, a)) return adminNo(res);
      if (M !== "POST") break;
      const b = await jsonBody(req, 1e4),
        d = DV.devices.find((x) => x.id === b.id);
      if (!d || !U.users.some((x) => x.id === d.user && x.role === "owner")) return fail(res, 404, "No such phone.");
      d.remote = b.on ? { at: Date.now() } : null;
      d.pairReq = 0;
      saveDevices();
      pubEvent("remote", (b.on ? "Rig Remote allowed: " : "Rig Remote removed: ") + d.name, "");
      broadcast({ type: "remote" }, (c) => c.device === d);
      log(b.on ? "Rig Remote allowed:" : "Rig Remote removed:", d.name);
      return json(res, 200, Object.assign(remoteView(), pubView(u)));
    }
    // ---- the rig's browser
    case "/api/browser/state":
      return json(res, 200, brState(u));
    case "/api/browser/config": {
      if (!rigCtl(req, a)) return ctlNo(res);
      if (M !== "POST") break;
      const b = await jsonBody(req, 2000);
      C.browser = Object.assign({ on: !1, exe: "" }, C.browser);
      "on" in b && (C.browser.on = !!b.on);
      "exe" in b && (C.browser.exe = clip(b.exe, 300));
      writeJson(CONF, C);
      !C.browser.on && BRW && BRW.stop("Switched off on the rig.");
      log("Rig browser", C.browser.on ? "on" : "off");
      return json(res, 200, Object.assign(brState(u), { visits: readJson(hubf("browser-log.json"), { visits: [] }).visits.slice(0, 40) }));
    }
    case "/api/browser/log": {
      if (!rigCtl(req, a)) return ctlNo(res);
      return json(res, 200, { visits: readJson(hubf("browser-log.json"), { visits: [] }).visits.slice(0, 60) });
    }
    case "/api/accounts": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const I = acctIndex();
      return json(res, 200, { clientId: (C.google && C.google.clientId) || "", count: I.list.length, bytes: I.list.reduce((a, x) => a + (x.size || 0), 0), limit: ACCT_MAX, list: I.list.slice().sort((a, b) => (b.seen || 0) - (a.seen || 0)).slice(0, 300) });
    }
    case "/api/accounts/config": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 2000),
        cid = String(b.clientId || "").trim();
      if (cid && !/^[0-9]+-[0-9a-z]+\.apps\.googleusercontent\.com$/.test(cid)) return fail(res, 400, "That doesn't look like a Google Client ID (it ends in .apps.googleusercontent.com).");
      C.google = Object.assign({}, C.google, { clientId: cid });
      writeJson(CONF, C);
      pubSave();
      return json(res, 200, { clientId: cid });
    }
    case "/api/accounts/del": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 500),
        id = String(b.id || "");
      if (!/^[0-9a-f]{32}$/.test(id)) return fail(res, 400, "Which account?");
      for (const f of [acctFile(id), acctFile(id, !0)]) await fsp.rm(f, { force: !0 });
      const I = acctIndex();
      I.list = I.list.filter((x) => x.id !== id);
      writeJson(hubf("accounts.json"), I);
      return json(res, 200, { ok: !0 });
    }
    case "/api/terms/accept": {
      if (M !== "POST") break;
      const b = await jsonBody(req, 2000),
        T = termsLoad(),
        terms = String(b.terms || "").replace(/[^0-9A-Za-z._-]/g, "").slice(0, 20),
        dev = (a.device && a.device.name) || "";
      if (!terms) return fail(res, 400, "Which terms?");
      const last = T.acc.find((x) => x.user === u.id && x.device === dev && x.terms === terms);
      if (!last) {
        T.acc.unshift({ id: id36(), at: Date.now(), user: u.id, name: u.name, device: dev, terms, app: String(b.app || "").replace(/[^0-9A-Za-z._-]/g, "").slice(0, 20), clientAt: +b.at || 0 });
        T.acc.length > 2000 && (T.acc.length = 2000);
        termsSave();
      }
      return json(res, 200, { ok: !0 });
    }
    case "/api/terms": {
      if (!owner) return fail(res, 403, "Only the owner.");
      const T = termsLoad(),
        seen = new Set(),
        latest = [];
      for (const x of T.acc) {
        const k = x.user + "|" + x.device;
        seen.has(k) || (seen.add(k), latest.push(x));
      }
      return json(res, 200, { acc: latest.slice(0, 100), log: T.log.slice(0, 200) });
    }
    case "/api/terms/note": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 4000),
        who = U.users.find((x) => x.id === b.user) || { id: "", name: clip(b.name, 60) };
      if (!clip(b.what, 400)) return fail(res, 400, "Write what happened.");
      ruleLog(who, b.what, b.action, !1);
      return json(res, 200, { log: termsLoad().log.slice(0, 200) });
    }
    case "/api/terms/note-del": {
      if (!owner) return fail(res, 403, "Only the owner.");
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      const b = await jsonBody(req, 500),
        T = termsLoad();
      T.log = T.log.filter((x) => x.id !== b.id);
      termsSave();
      return json(res, 200, { log: T.log.slice(0, 200) });
    }
    case "/api/browser/ack":
      if (M !== "POST") break;
      u.brAck = Date.now();
      saveUsers();
      return json(res, 200, brState(u));
    case "/api/browser/start": {
      if (M !== "POST") break;
      if (!BRW) return fail(res, 404, "The rig's browser needs the Hub's update.");
      if (!brOn()) return fail(res, 403, "The owner has the rig's browser switched off.");
      if (!canBrowse(u)) return fail(res, 403, "The owner hasn't turned the rig's browser on for you.");
      if (u.role !== "owner" && !u.brAck) return fail(res, 409, "Read the notice about the rig's browser first.");
      return json(res, 200, await BRW.start(u, C.browser));
    }
    case "/api/browser/stop":
      if (M !== "POST") break;
      if (BRW && BRW.active() && (BRW.active().user.id === u.id || owner)) BRW.stop(BRW.active().user.id === u.id ? "Closed." : "Closed by the owner.");
      return json(res, 200, brState(u));
    case "/api/browser/go":
    case "/api/browser/input":
    case "/api/browser/resize": {
      if (M !== "POST" || !BRW || !brOn() || !canBrowse(u)) return fail(res, 403, "The rig's browser isn't available.");
      const b = await jsonBody(req, 20000);
      if (p.endsWith("/go")) await BRW.go(u, b.url);
      else if (p.endsWith("/input")) await BRW.input(u, b.events);
      else await BRW.resize(u, b.w, b.h);
      return json(res, 200, { ok: !0 });
    }
    case "/api/browser/frame": {
      if (!BRW || !brOn() || !canBrowse(u)) return fail(res, 403, "The rig's browser isn't available.");
      const f = await BRW.frame(u, +url.searchParams.get("n") || 0, 20000),
        h = { "Cache-Control": "no-store", "X-Frame": String(f.n), "X-Url": encodeURIComponent(f.url), "X-Title": encodeURIComponent(f.title), "X-Size": f.w + "x" + f.h, "Access-Control-Expose-Headers": "X-Frame, X-Url, X-Title, X-Size" };
      if (!f.buf) return (res.writeHead(204, h), res.end());
      res.writeHead(200, Object.assign(h, { "Content-Type": "image/jpeg", "Content-Length": f.buf.length }));
      return res.end(f.buf);
    }
    // fetch the newest Hub now instead of at the next check (1.13.1): the owner, from any device
    case "/api/hub/update": {
      if (M !== "POST") break;
      if (!owner) return fail(res, 403, "Only the owner can update the Hub.");
      const r = await checkUpdate(!0);
      if (!r.ok) return fail(res, 502, "The Hub couldn't fetch its update: " + r.error);
      r.updating && log("Update asked by", u.name, "on", a.device.name);
      return json(res, 200, { ok: !0, version: VERSION, latest: r.latest, updating: !!r.updating });
    }
    case "/api/hub/restart":
      if (M !== "POST") break;
      if (!rigCtl(req, a)) return ctlNo(res);
      log("Restart asked by", u.name, "on", a.device.name);
      pubEvent("update", "Hub restarted", "from " + a.device.name);
      json(res, 200, { ok: !0 });
      // the icon by the clock starts it again in a few seconds
      setTimeout(() => process.exit(4), 600);
      return;
    // ---- notifications
    case "/api/push/key":
      return json(res, 200, { key: VAPID.pub });
    case "/api/push/subscribe": {
      const b = await jsonBody(req, 2e4);
      if (!b.sub || !b.sub.endpoint || !b.sub.keys) return fail(res, 400, "That isn't a push subscription.");
      a.device.push = { endpoint: b.sub.endpoint, keys: { p256dh: b.sub.keys.p256dh, auth: b.sub.keys.auth } };
      a.device.notify = b.notify !== !1;
      saveDevices();
      return json(res, 200, { ok: !0 });
    }
    case "/api/push/unsubscribe":
      a.device.push = null;
      saveDevices();
      return json(res, 200, { ok: !0 });
    case "/api/push/test": {
      const code = await pushTo(a.device, { title: "Workbench Hub", body: "Notifications work on this device.", tag: "wb-test", open: "bell" });
      return code >= 200 && code < 300 ? json(res, 200, { ok: !0 }) : fail(res, 502, "The phone's push service didn't take it" + (code ? " (" + code + ")" : "") + ". Check that the rig has internet.");
    }
    case "/api/digest": {
      if (!canWork(u)) return fail(res, 403, "Work is only for the people the owner allows.");
      if (M === "POST") {
        const b = await jsonBody(req, 1e4);
        if (b.lang && b.lang !== C.lang) ((C.lang = String(b.lang).slice(0, 30)), writeJson(CONF, C));
        return json(res, 200, (await makeDigest()) || {});
      }
      const dg = readJson(hubf("digest.json"), null);
      if (!dg || Date.now() - dg.at > 65 * 60000) makeDigest().catch(() => {});
      return json(res, 200, dg || {});
    }
  }
  return fail(res, 404, "Not found");
}

// ---- start -------------------------------------------------------------------------------------
function main() {
  const argv = process.argv.slice(2);
  setup();
  if (argv[0] === "--init-owner") {
    if (U.users.some((x) => x.role === "owner")) return console.log("The Hub already has an owner.");
    addUser(argv[1], argv[2], "owner");
    return console.log("Owner created: " + argv[1]);
  }
  if (argv[0] === "--reset-pin") {
    const x = U.users.find((y) => y.name.toLowerCase() === String(argv[1] || "").toLowerCase());
    if (!x) return (console.log("Nobody called " + argv[1]), process.exit(1));
    setPin(x, argv[2]);
    return console.log("New PIN set for " + x.name);
  }
  const srv = http.createServer((req, res) =>
    route(req, res).catch((e) => {
      if (e.code !== 400 && e.code !== 401 && e.code !== 429) log("Error", req.method, req.url.split("?")[0], e.stack || e.message);
      fail(res, typeof e.code === "number" ? e.code : 500, e.message || "Something went wrong on the Hub.");
    }),
  );
  srv.requestTimeout = 0;
  srv.headersTimeout = 60000;
  srv.on("error", (e) => {
    log("Can't start:", e.message);
    process.exit(e.code === "EADDRINUSE" ? 2 : 1);
  });
  srv.listen(C.port, C.host, () => log("Workbench Hub", VERSION, "on http://" + C.host + ":" + C.port, "· folder", C.root));
  // the public inbox: only company applications and messages (shared to the internet by Tailscale Funnel)
  const ib = http.createServer((req, res) => inboxRoute(req, res).catch((e) => fail(res, typeof e.code === "number" ? e.code : 500, e.message || "Something went wrong.")));
  // (long enough for an upload through the anywhere door; the inbox's own posts are small)
  ib.requestTimeout = 20 * 60000;
  ib.headersTimeout = 30000;
  ib.on("error", (e) => log("Inbox can't start:", e.message));
  ib.listen(C.inboxPort || 8771, "127.0.0.1");
  setTimeout(checkReminders, 20000);
  setInterval(() => checkReminders().catch((e) => log("reminders:", e.message)), 10 * 60000);
  setInterval(() => makeDigest().catch((e) => log("digest:", e.message)), 60 * 60000);
  setTimeout(() => makeDigest().catch(() => {}), 120000);
  // soon after it starts (so "Restart the Hub" is also "update the Hub"), then every hour
  setTimeout(checkUpdate, 30000);
  setTimeout(histSample, 45000);
  setInterval(histSample, 10 * 60000);
  setTimeout(() => inboxWatch().catch((e) => log("inbox:", e.message)), 90000);
  setInterval(() => inboxWatch().catch((e) => log("inbox:", e.message)), 10 * 60000);
  setInterval(checkUpdate, 3600000);
}
if (require.main === module) main();
module.exports = { route, setup, C, addUser, checkReminders, makeDigest, directLink, folderHint, autoKind, VERSION };
